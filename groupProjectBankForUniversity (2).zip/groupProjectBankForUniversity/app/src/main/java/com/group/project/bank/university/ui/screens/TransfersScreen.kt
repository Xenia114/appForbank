package com.group.project.bank.university.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.group.project.bank.university.service.ApiBalanceService
import com.group.project.bank.university.service.ApiTransactionService
import com.group.project.bank.university.ui.theme.BankGreen
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransfersScreen(
    onNavigateBack: () -> Unit,
    balanceService: ApiBalanceService
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val transactionService = remember { ApiTransactionService(context) }
    var recipientCardTextFieldValue by remember { mutableStateOf(TextFieldValue("")) }
    var amount by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }
    
    var recipientError by remember { mutableStateOf("") }
    var amountError by remember { mutableStateOf("") }
    
    // Получаем текущую дату из системы
    val currentDate = remember {
        val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        dateFormat.format(Date())
    }

    fun validateCard(card: String): String {
        val cleaned = card.replace(" ", "")
        return when {
            cleaned.isEmpty() -> "Введите номер карты"
            cleaned.length < 16 -> "Номер карты должен содержать 16 цифр"
            !cleaned.all { it.isDigit() } -> "Номер карты должен содержать только цифры"
            else -> ""
        }
    }
    
    val recipientCard = recipientCardTextFieldValue.text

    fun validateAmount(amount: String): String {
        return when {
            amount.isEmpty() -> "Введите сумму"
            amount.toDoubleOrNull() == null -> "Сумма должна быть числом"
            amount.toDouble() <= 0 -> "Сумма должна быть больше нуля"
            amount.toDouble() > 1000000 -> "Максимальная сумма перевода: 1 000 000 ₽"
            else -> ""
        }
    }

    fun formatCardNumber(input: String): String {
        val cleaned = input.replace(" ", "").take(16)
        return cleaned.chunked(4).joinToString(" ")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Перевод",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Назад",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = MaterialTheme.colorScheme.onSurface
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Карточка получателя
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Получатель",
                            tint = BankGreen,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "Получатель",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    OutlinedTextField(
                        value = recipientCardTextFieldValue,
                        onValueChange = { newValue ->
                            val oldText = recipientCardTextFieldValue.text
                            val oldSelection = recipientCardTextFieldValue.selection
                            val oldCursorPos = oldSelection.start
                            val oldDigits = oldText.filter { it.isDigit() }
                            
                            // Удаляем все нецифровые символы
                            val cleaned = newValue.text.filter { it.isDigit() }.take(16)
                            
                            val formatted = formatCardNumber(cleaned)
                            
                            // Определяем новую позицию курсора
                            val newCursorPosition = when {
                                // Если текст не изменился (только перемещение курсора) - используем позицию из newValue
                                cleaned == oldDigits -> {
                                    // Позиция курсора относительно цифр
                                    val digitsBeforeCursor = newValue.text.substring(0, newValue.selection.start.coerceAtMost(newValue.text.length)).filter { it.isDigit() }.length
                                    var digitsCount = 0
                                    var newPos = formatted.length
                                    for (i in formatted.indices) {
                                        if (formatted[i].isDigit()) {
                                            digitsCount++
                                            if (digitsCount >= digitsBeforeCursor) {
                                                newPos = i + 1
                                                break
                                            }
                                        }
                                    }
                                    newPos.coerceIn(0, formatted.length)
                                }
                                // Если вводится новый символ (текст увеличился) и курсор был в конце
                                cleaned.length > oldDigits.length && oldCursorPos >= oldText.length -> {
                                    formatted.length
                                }
                                // Если удаляется символ или курсор был не в конце - сохраняем позицию
                                else -> {
                                    val oldDigitsBeforeCursor = oldText.substring(0, oldCursorPos.coerceAtMost(oldText.length)).filter { it.isDigit() }.length
                                    var digitsCount = 0
                                    var newPos = formatted.length
                                    for (i in formatted.indices) {
                                        if (formatted[i].isDigit()) {
                                            digitsCount++
                                            if (digitsCount >= oldDigitsBeforeCursor) {
                                                newPos = i + 1
                                                break
                                            }
                                        }
                                    }
                                    newPos.coerceIn(0, formatted.length)
                                }
                            }
                            
                            recipientCardTextFieldValue = TextFieldValue(
                                text = formatted,
                                selection = TextRange(newCursorPosition)
                            )
                            recipientError = validateCard(cleaned)
                        },
                        label = { Text("Номер карты получателя") },
                        placeholder = { Text("0000 0000 0000 0000") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.CreditCard,
                                contentDescription = null,
                                tint = BankGreen
                            )
                        },
                        isError = recipientError.isNotEmpty(),
                        supportingText = {
                            if (recipientError.isNotEmpty()) {
                                Text(recipientError, color = MaterialTheme.colorScheme.error)
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BankGreen,
                            focusedLabelColor = BankGreen
                        )
                    )
                }
            }

            // Карточка суммы
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AttachMoney,
                            contentDescription = "Сумма",
                            tint = BankGreen,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "Сумма перевода",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    OutlinedTextField(
                        value = amount,
                        onValueChange = { newValue ->
                            val filtered = newValue.filter { char -> char.isDigit() || char == '.' || char == ',' }
                            amount = filtered.replace(',', '.')
                            amountError = validateAmount(amount)
                        },
                        label = { Text("Сумма") },
                        placeholder = { Text("0.00") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        suffix = if (amount.isNotEmpty() && amount.toDoubleOrNull() != null) {
                            { Text("₽") }
                        } else null,
                        isError = amountError.isNotEmpty(),
                        supportingText = {
                            if (amountError.isNotEmpty()) {
                                Text(amountError, color = MaterialTheme.colorScheme.error)
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BankGreen,
                            focusedLabelColor = BankGreen
                        )
                    )
                }
            }

            // Информация о дате перевода
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = "Дата",
                        tint = BankGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Дата перевода",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Text(
                            text = currentDate,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Комментарий
            OutlinedTextField(
                value = comment,
                onValueChange = { comment = it },
                label = { Text("Комментарий (необязательно)") },
                placeholder = { Text("Введите комментарий к переводу") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BankGreen,
                    focusedLabelColor = BankGreen
                )
            )

            Spacer(modifier = Modifier.weight(1f))

            // Кнопка перевода
            Button(
                onClick = {
                    recipientError = validateCard(recipientCard)
                    amountError = validateAmount(amount)
                    
                    if (recipientError.isEmpty() && amountError.isEmpty()) {
                        val transferAmount = amount.toDoubleOrNull() ?: 0.0
                        if (transferAmount > 0) {
                            scope.launch {
                                val result = transactionService.addTransferTransaction(transferAmount, recipientCard)
                                result.onSuccess {
                                    onNavigateBack()
                                }.onFailure {
                                    // Обработка ошибки
                                }
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BankGreen,
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = "Перевести",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
