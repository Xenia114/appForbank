package com.group.project.bank.university.api.dto

data class DepositsResponse(
    val deposits: List<DepositResponse>
)

