package com.group.project.bank.university.api

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {
    // Для эмулятора Android используем 10.0.2.2 вместо localhost
    // Для реального устройства замените на IP адрес вашего компьютера
    private const val USER_SERVICE_BASE_URL = "http://10.0.2.2:8081/"
    private const val BANKING_SERVICE_BASE_URL = "http://10.0.2.2:8082/"
    
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }
    
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    
    val userApiService: UserApiService = Retrofit.Builder()
        .baseUrl(USER_SERVICE_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(UserApiService::class.java)
    
    val bankingApiService: BankingApiService = Retrofit.Builder()
        .baseUrl(BANKING_SERVICE_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(BankingApiService::class.java)
}

