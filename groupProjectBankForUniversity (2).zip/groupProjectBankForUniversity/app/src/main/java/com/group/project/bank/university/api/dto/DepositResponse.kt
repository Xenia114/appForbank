package com.group.project.bank.university.api.dto

data class DepositResponse(
    val id: Long,
    val name: String,
    val amount: String,
    val rate: String,
    val term: String
)

