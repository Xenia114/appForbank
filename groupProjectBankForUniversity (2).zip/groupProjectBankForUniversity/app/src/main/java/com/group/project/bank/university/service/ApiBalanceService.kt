package com.group.project.bank.university.service

import android.content.Context
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.data.TokenManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ApiBalanceService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val bankingApi = ApiClient.bankingApiService
    
    suspend fun getBalance(): Double = withContext(Dispatchers.IO) {
        val token = tokenManager.getBearerToken()
            ?: throw IllegalStateException("Not authenticated")
        val response = bankingApi.getBalance(token)
        response.balance
    }
    
    suspend fun formatBalance(): String = withContext(Dispatchers.IO) {
        val token = tokenManager.getBearerToken()
            ?: throw IllegalStateException("Not authenticated")
        val response = bankingApi.getBalance(token)
        response.formatted
    }
    
    suspend fun subtractAmount(amount: Double): Double = withContext(Dispatchers.IO) {
        val token = tokenManager.getBearerToken()
            ?: throw IllegalStateException("Not authenticated")
        val response = bankingApi.subtractBalance(token, mapOf("amount" to amount))
        response.newBalance
    }
    
    suspend fun addAmount(amount: Double): Double = withContext(Dispatchers.IO) {
        val token = tokenManager.getBearerToken()
            ?: throw IllegalStateException("Not authenticated")
        val response = bankingApi.addBalance(token, mapOf("amount" to amount))
        response.newBalance
    }
}

