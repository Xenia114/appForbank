package com.group.project.bank.university.service

import android.content.Context
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.api.dto.UpdateProfileRequest
import com.group.project.bank.university.data.TokenManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ApiUserService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val userApi = ApiClient.userApiService
    
    suspend fun getUserName(): String {
        return try {
            val profile = getProfile()
            profile.name
        } catch (e: Exception) {
            "Иван Иванов" // Fallback
        }
    }
    
    suspend fun getUserPhone(): String {
        return try {
            val profile = getProfile()
            profile.phone
        } catch (e: Exception) {
            "+7 999 123-45-67" // Fallback
        }
    }
    
    suspend fun getUserEmail(): String {
        return try {
            val profile = getProfile()
            profile.email
        } catch (e: Exception) {
            "ivan.ivanov@example.com" // Fallback
        }
    }
    
    suspend fun getProfile() = withContext(Dispatchers.IO) {
        val token = tokenManager.getBearerToken()
            ?: throw IllegalStateException("Not authenticated")
        userApi.getProfile(token)
    }
    
    suspend fun updateProfile(name: String, email: String) = withContext(Dispatchers.IO) {
        val token = tokenManager.getBearerToken()
            ?: throw IllegalStateException("Not authenticated")
        val request = UpdateProfileRequest(name = name, email = email)
        userApi.updateProfile(token, request)
    }
    
    suspend fun setUserPhone(phone: String) {
        // Телефон нельзя менять через API, только при входе
        // Сохраняем локально для совместимости
    }
}

