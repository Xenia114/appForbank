package com.group.project.bank.university.api.dto

data class CreateDepositRequest(
    val name: String,
    val amount: Double,
    val rate: Double,
    val term: String
)

