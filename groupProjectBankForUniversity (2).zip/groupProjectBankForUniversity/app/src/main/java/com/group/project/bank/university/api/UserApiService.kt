package com.group.project.bank.university.api

import com.group.project.bank.university.api.dto.*
import retrofit2.http.*

interface UserApiService {
    @POST("api/v1/auth/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse
    
    @POST("api/v1/auth/logout")
    suspend fun logout(@Header("Authorization") token: String): Map<String, String>
    
    @GET("api/v1/auth/status")
    suspend fun getAuthStatus(@Header("Authorization") token: String): AuthStatusResponse
    
    @GET("api/v1/users/profile")
    suspend fun getProfile(@Header("Authorization") token: String): UserProfileResponse
    
    @PUT("api/v1/users/profile")
    suspend fun updateProfile(
        @Header("Authorization") token: String,
        @Body request: UpdateProfileRequest
    ): UpdateProfileResponse
    
    @GET("api/v1/users/{userId}")
    suspend fun getUserById(
        @Header("Authorization") token: String,
        @Path("userId") userId: Long
    ): UserProfileResponse
}

