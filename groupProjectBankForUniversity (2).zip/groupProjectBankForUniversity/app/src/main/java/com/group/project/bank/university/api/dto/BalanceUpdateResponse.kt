package com.group.project.bank.university.api.dto

data class BalanceUpdateResponse(
    val success: Boolean,
    val newBalance: Double
)

