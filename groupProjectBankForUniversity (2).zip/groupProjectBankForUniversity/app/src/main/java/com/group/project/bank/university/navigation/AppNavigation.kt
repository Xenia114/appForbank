package com.group.project.bank.university.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.group.project.bank.university.service.ApiAuthService
import com.group.project.bank.university.service.ApiBalanceService
import com.group.project.bank.university.ui.screens.*
import kotlinx.coroutines.launch

sealed class Screen(val route: String) {
    object Splash : Screen(route = "SplashScreen")
    object Enter : Screen(route = "EnterScreen")
    object Main : Screen(route = "MainScreen")
    object Transfer : Screen(route = "TransfersScreen")
    object Profile : Screen(route = "ProfileScreen")
    object History : Screen(route = "HistoryScreen")
    object Deposits : Screen(route = "DepositsScreen")
    object OpenDeposit : Screen(route = "OpenDepositScreen")
}

@Composable
fun NavGraph(
    navController: NavHostController,
    authService: ApiAuthService,
    balanceService: ApiBalanceService
) {
    val scope = rememberCoroutineScope()
    var startDestination by remember { mutableStateOf(Screen.Splash.route) }
    
    LaunchedEffect(Unit) {
        startDestination = if (authService.isLoggedIn()) {
            Screen.Main.route
        } else {
            Screen.Splash.route
        }
    }
    
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onNavigateToEnter = {
                    navController.navigate(Screen.Enter.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                },
                onNavigateToMain = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                },
                authService = authService
            )
        }
        
        composable(Screen.Enter.route) {
            EnterScreen(
                onNavigateToMain = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Enter.route) { inclusive = true }
                    }
                },
                authManager = authService
            )
        }
        
        composable(Screen.Main.route) {
            MainScreen(
                onNavigateToTransfers = {
                    navController.navigate(Screen.Transfer.route) {
                        // Сохраняем MainScreen в стеке для возврата
                    }
                },
                onNavigateToProfile = {
                    navController.navigate(Screen.Profile.route) {
                        // Сохраняем MainScreen в стеке для возврата
                    }
                },
                onNavigateToHistory = {
                    navController.navigate(Screen.History.route) {
                        // Сохраняем MainScreen в стеке для возврата
                    }
                },
                onNavigateToDeposits = {
                    navController.navigate(Screen.Deposits.route) {
                        // Сохраняем MainScreen в стеке для возврата
                    }
                },
                balanceService = balanceService
            )
        }
        
        composable(Screen.History.route) {
            HistoryScreen(
                onNavigateBack = {
                    if (navController.previousBackStackEntry != null) {
                        navController.popBackStack()
                    } else {
                        navController.navigate(Screen.Main.route) {
                            popUpTo(Screen.Main.route) { inclusive = true }
                        }
                    }
                }
            )
        }
        
        composable(Screen.Deposits.route) {
            DepositsScreen(
                onNavigateBack = {
                    if (navController.previousBackStackEntry != null) {
                        navController.popBackStack()
                    } else {
                        navController.navigate(Screen.Main.route) {
                            popUpTo(Screen.Main.route) { inclusive = true }
                        }
                    }
                },
                onNavigateToOpenDeposit = {
                    navController.navigate(Screen.OpenDeposit.route) {
                        // Сохраняем DepositsScreen в стеке для возврата
                    }
                },
                balanceService = balanceService
            )
        }
        
        composable(Screen.OpenDeposit.route) {
            val context = androidx.compose.ui.platform.LocalContext.current
            val depositService = remember { 
                com.group.project.bank.university.service.ApiDepositService(context)
            }
            val transactionService = remember {
                com.group.project.bank.university.service.ApiTransactionService(context)
            }
            OpenDepositScreen(
                onNavigateBack = {
                    if (navController.previousBackStackEntry != null) {
                        navController.popBackStack()
                    } else {
                        navController.navigate(Screen.Deposits.route) {
                            popUpTo(Screen.Deposits.route) { inclusive = true }
                        }
                    }
                },
                balanceService = balanceService,
                depositService = depositService,
                transactionService = transactionService,
                onDepositOpened = {
                    // Вклад открыт, можно вернуться назад
                }
            )
        }
        
        composable(Screen.Transfer.route) {
            TransfersScreen(
                onNavigateBack = {
                    // Безопасная навигация назад с проверкой
                    if (navController.previousBackStackEntry != null) {
                        navController.popBackStack()
                    } else {
                        navController.navigate(Screen.Main.route) {
                            popUpTo(Screen.Main.route) { inclusive = true }
                        }
                    }
                },
                balanceService = balanceService
            )
        }
        
        composable(Screen.Profile.route) {
            ProfileScreen(
                onNavigateBack = {
                    // Безопасная навигация назад с проверкой
                    if (navController.previousBackStackEntry != null) {
                        navController.popBackStack()
                    } else {
                        navController.navigate(Screen.Main.route) {
                            popUpTo(Screen.Main.route) { inclusive = true }
                        }
                    }
                },
                onNavigateToEnter = {
                    scope.launch {
                        authService.logout()
                        navController.navigate(Screen.Enter.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                },
                authService = authService
            )
        }
    }
}
