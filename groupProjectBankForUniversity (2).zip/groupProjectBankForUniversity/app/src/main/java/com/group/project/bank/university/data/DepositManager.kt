package com.group.project.bank.university.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class DepositManager(private val context: Context) {
    private val prefs: SharedPreferences = 
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()
    
    companion object {
        private const val PREFS_NAME = "bank_app_prefs"
        private const val KEY_DEPOSITS = "deposits"
        
        private val DEFAULT_DEPOSITS = listOf(
            DepositItem(0L, "Накопительный вклад", "500000", "5.5%", "До 31.12.2024"),
            DepositItem(0L, "Срочный вклад", "300000", "7.0%", "До 30.06.2025"),
            DepositItem(0L, "Пенсионный вклад", "150000", "6.0%", "До 31.12.2024"),
            DepositItem(0L, "Сберегательный вклад", "200000", "4.5%", "До 31.03.2025")
        )
    }
    
    fun getDeposits(): List<DepositItem> {
        val json = prefs.getString(KEY_DEPOSITS, null)
        return if (json != null) {
            val type = object : TypeToken<List<DepositItem>>() {}.type
            gson.fromJson(json, type)
        } else {
            DEFAULT_DEPOSITS
        }
    }
    
    fun addToDeposit(depositIndex: Int, amount: Double) {
        val deposits = getDeposits().toMutableList()
        if (depositIndex in deposits.indices) {
            val deposit = deposits[depositIndex]
            val currentAmount = deposit.amount.replace(" ", "").toDoubleOrNull() ?: 0.0
            val newAmount = currentAmount + amount
            deposits[depositIndex] = DepositItem(
                deposit.id,
                deposit.name,
                newAmount.toInt().toString(),
                deposit.rate,
                deposit.term
            )
            val json = gson.toJson(deposits)
            prefs.edit().putString(KEY_DEPOSITS, json).apply()
        }
    }
    
    fun formatDepositAmount(amount: String): String {
        val numAmount = amount.replace(" ", "").toDoubleOrNull() ?: 0.0
        return String.format("%,.0f", numAmount).replace(",", " ") + " ₽"
    }
    
    fun createNewDeposit(name: String, amount: Double, rate: Double, term: String) {
        val deposits = getDeposits().toMutableList()
        val rateString = String.format("%.1f", rate) + "%"
        deposits.add(
            DepositItem(
                0L,
                name,
                amount.toInt().toString(),
                rateString,
                term
            )
        )
        val json = gson.toJson(deposits)
        prefs.edit().putString(KEY_DEPOSITS, json).apply()
    }
}

data class DepositItem(
    val id: Long = 0L, // ID из API, по умолчанию 0 для совместимости
    val name: String,
    val amount: String, // Хранится как число без форматирования
    val rate: String,
    val term: String
)

