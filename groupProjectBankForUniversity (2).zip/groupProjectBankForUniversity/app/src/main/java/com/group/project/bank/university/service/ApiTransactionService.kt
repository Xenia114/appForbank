package com.group.project.bank.university.service

import android.content.Context
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.api.dto.TransferRequest
import com.group.project.bank.university.data.TokenManager
import com.group.project.bank.university.data.TransactionItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ApiTransactionService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val bankingApi = ApiClient.bankingApiService
    
    suspend fun getTransactions(limit: Int = 100, offset: Int = 0): List<TransactionItem> = 
        withContext(Dispatchers.IO) {
            val token = tokenManager.getBearerToken()
                ?: throw IllegalStateException("Not authenticated")
            val response = bankingApi.getTransactions(token, limit, offset)
            response.transactions.map { apiTransaction ->
                TransactionItem(
                    title = apiTransaction.title,
                    date = apiTransaction.date,
                    amount = apiTransaction.amount,
                    isPositive = apiTransaction.isPositive,
                    iconName = apiTransaction.iconName
                )
            }
        }
    
    suspend fun addTransferTransaction(amount: Double, recipientCard: String): Result<Unit> {
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                val request = TransferRequest(amount = amount, recipientCard = recipientCard)
                bankingApi.transfer(token, request)
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun addDepositTransaction(amount: Double, depositName: String): Result<Unit> {
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                bankingApi.addDepositTransaction(
                    token,
                    mapOf("amount" to amount, "depositName" to depositName)
                )
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun addOpenDepositTransaction(amount: Double, depositName: String): Result<Unit> {
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                bankingApi.addDepositTransaction(
                    token,
                    mapOf("amount" to amount, "depositName" to depositName)
                )
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

