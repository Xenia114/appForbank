package com.group.project.bank.university.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.*

data class TransactionItem(
    val title: String,
    val date: String,
    val amount: String,
    val isPositive: Boolean,
    val iconName: String // Название иконки для сериализации
)

class TransactionManager(private val context: Context) {
    private val prefs: SharedPreferences = 
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()
    
    companion object {
        private const val PREFS_NAME = "bank_app_prefs"
        private const val KEY_TRANSACTIONS = "transactions"
    }
    
    fun getTransactions(): List<TransactionItem> {
        val json = prefs.getString(KEY_TRANSACTIONS, null)
        return if (json != null) {
            val type = object : TypeToken<List<TransactionItem>>() {}.type
            gson.fromJson(json, type)
        } else {
            // Начальные транзакции
            listOf(
                TransactionItem("Пополнение", "15 января 2024", "+5 000 ₽", true, "ArrowDownward"),
                TransactionItem("Перевод", "14 января 2024", "-2 500 ₽", false, "ArrowUpward"),
                TransactionItem("Покупка", "13 января 2024", "-1 200 ₽", false, "ShoppingCart"),
                TransactionItem("Зарплата", "10 января 2024", "+50 000 ₽", true, "AccountBalance")
            )
        }
    }
    
    fun addTransaction(
        title: String,
        amount: Double,
        isPositive: Boolean,
        iconName: String
    ) {
        val transactions = getTransactions().toMutableList()
        val dateFormat = SimpleDateFormat("d MMMM yyyy", Locale("ru", "RU"))
        val currentDate = try {
            dateFormat.format(Date())
        } catch (e: Exception) {
            // Fallback на английский формат, если русская локаль недоступна
            SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(Date())
        }
        val formattedAmount = String.format("%,.0f", amount).replace(",", " ") + " ₽"
        val amountWithSign = if (isPositive) "+$formattedAmount" else "-$formattedAmount"
        
        // Добавляем в начало списка (новые транзакции сверху)
        transactions.add(0, TransactionItem(
            title = title,
            date = currentDate,
            amount = amountWithSign,
            isPositive = isPositive,
            iconName = iconName
        ))
        
        val json = gson.toJson(transactions)
        prefs.edit().putString(KEY_TRANSACTIONS, json).apply()
    }
    
    fun addTransferTransaction(amount: Double, recipientCard: String) {
        addTransaction(
            title = "Перевод на карту ${recipientCard.takeLast(4)}",
            amount = amount,
            isPositive = false,
            iconName = "ArrowUpward"
        )
    }
    
    fun addDepositTransaction(amount: Double, depositName: String) {
        addTransaction(
            title = "Пополнение вклада: $depositName",
            amount = amount,
            isPositive = false,
            iconName = "AccountBalance"
        )
    }
    
    fun addOpenDepositTransaction(amount: Double, depositName: String) {
        addTransaction(
            title = "Открытие вклада: $depositName",
            amount = amount,
            isPositive = false,
            iconName = "AccountBalance"
        )
    }
}

