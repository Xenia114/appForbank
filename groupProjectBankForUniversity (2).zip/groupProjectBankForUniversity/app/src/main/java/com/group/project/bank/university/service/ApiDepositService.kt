package com.group.project.bank.university.service

import android.content.Context
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.api.dto.CreateDepositRequest
import com.group.project.bank.university.data.DepositItem
import com.group.project.bank.university.data.TokenManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ApiDepositService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val bankingApi = ApiClient.bankingApiService
    
    suspend fun getDeposits(): List<DepositItem> = withContext(Dispatchers.IO) {
        val token = tokenManager.getBearerToken()
            ?: throw IllegalStateException("Not authenticated")
        val response = bankingApi.getDeposits(token)
        response.deposits.map { apiDeposit ->
            DepositItem(
                id = apiDeposit.id,
                name = apiDeposit.name,
                amount = apiDeposit.amount,
                rate = apiDeposit.rate,
                term = apiDeposit.term
            )
        }
    }
    
    suspend fun addToDeposit(depositId: Long, amount: Double): Result<Unit> {
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                bankingApi.topUpDeposit(token, depositId, mapOf("amount" to amount))
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun formatDepositAmount(amount: String): String {
        val numAmount = amount.replace(" ", "").toDoubleOrNull() ?: 0.0
        return String.format("%,.0f", numAmount).replace(",", " ") + " ₽"
    }
    
    suspend fun createNewDeposit(
        name: String,
        amount: Double,
        rate: Double,
        term: String
    ): Result<DepositItem> {
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                val request = CreateDepositRequest(
                    name = name,
                    amount = amount,
                    rate = rate,
                    term = term
                )
                val response = bankingApi.createDeposit(token, request)
                Result.success(
                    DepositItem(
                        id = response.deposit.id,
                        name = response.deposit.name,
                        amount = response.deposit.amount,
                        rate = response.deposit.rate,
                        term = response.deposit.term
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

