package com.group.project.bank.university.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.group.project.bank.university.service.ApiBalanceService
import com.group.project.bank.university.service.ApiDepositService
import com.group.project.bank.university.service.ApiTransactionService
import com.group.project.bank.university.ui.theme.BankGreen
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

data class AvailableDeposit(
    val name: String,
    val rate: Double, // Процент годовых
    val minAmount: String,
    val term: String,
    val description: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OpenDepositScreen(
    onNavigateBack: () -> Unit,
    balanceService: ApiBalanceService,
    depositService: ApiDepositService,
    transactionService: ApiTransactionService,
    onDepositOpened: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // Доступные вклады для открытия
    val availableDeposits = remember {
        listOf(
            AvailableDeposit("Накопительный вклад", 5.5, "Минимальная сумма: 10 000 ₽", "До 31.12.2024", "Идеально для накоплений"),
            AvailableDeposit("Срочный вклад", 7.0, "Минимальная сумма: 50 000 ₽", "До 30.06.2025", "Максимальная доходность"),
            AvailableDeposit("Пенсионный вклад", 6.0, "Минимальная сумма: 5 000 ₽", "До 31.12.2024", "Специальные условия"),
            AvailableDeposit("Сберегательный вклад", 4.5, "Минимальная сумма: 1 000 ₽", "До 31.03.2025", "Гибкие условия"),
            AvailableDeposit("Премиум вклад", 8.5, "Минимальная сумма: 500 000 ₽", "До 31.12.2025", "Премиум условия")
        )
    }
    
    var selectedDepositIndex by remember { mutableStateOf(0) }
    var depositAmount by remember { mutableStateOf("") }
    var amountError by remember { mutableStateOf("") }
    
    val selectedDeposit = availableDeposits[selectedDepositIndex]
    val minAmountValue = selectedDeposit.minAmount
        .replace("Минимальная сумма: ", "")
        .replace(" ₽", "")
        .replace(" ", "")
        .toDoubleOrNull() ?: 0.0
    
    var currentBalance by remember { mutableStateOf(0.0) }
    var formattedBalance by remember { mutableStateOf("0 ₽") }
    
    // Загружаем баланс при первом запуске
    LaunchedEffect(Unit) {
        scope.launch {
            try {
                currentBalance = balanceService.getBalance()
                formattedBalance = balanceService.formatBalance()
            } catch (e: Exception) {
                // Обработка ошибок
            }
        }
    }
    
    fun validateAmount(amount: String): String {
        val amountValue = amount.toDoubleOrNull() ?: 0.0
        return when {
            amount.isEmpty() -> "Введите сумму"
            amountValue < minAmountValue -> "Минимальная сумма: ${selectedDeposit.minAmount}"
            amountValue > currentBalance -> "Недостаточно средств на счете"
            else -> ""
        }
    }
    
    // Расчет суммы через год
    val futureAmount = remember(depositAmount, selectedDeposit.rate) {
        val amount = depositAmount.toDoubleOrNull() ?: 0.0
        if (amount > 0) {
            val interest = amount * (selectedDeposit.rate / 100.0)
            amount + interest
        } else {
            0.0
        }
    }
    
    val profit = remember(futureAmount, depositAmount) {
        val amount = depositAmount.toDoubleOrNull() ?: 0.0
        if (futureAmount > amount) {
            futureAmount - amount
        } else {
            0.0
        }
    }
    
    val formattedAmount = remember(depositAmount) {
        if (depositAmount.isNotEmpty() && depositAmount.toDoubleOrNull() != null) {
            String.format("%,.0f", depositAmount.toDoubleOrNull() ?: 0.0).replace(",", " ") + " ₽"
        } else {
            "0 ₽"
        }
    }
    
    val formattedFutureAmount = remember(futureAmount) {
        if (futureAmount > 0) {
            String.format("%,.0f", futureAmount).replace(",", " ") + " ₽"
        } else {
            "0 ₽"
        }
    }
    
    val formattedProfit = remember(profit) {
        if (profit > 0) {
            String.format("%,.0f", profit).replace(",", " ") + " ₽"
        } else {
            "0 ₽"
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Открыть вклад",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Назад",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = MaterialTheme.colorScheme.onSurface
            )
        )
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Информация о балансе
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = BankGreen
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Доступно на счете",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = formattedBalance,
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            
            // Выбор типа вклада
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Выберите тип вклада",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    itemsIndexed(availableDeposits) { index, deposit ->
                        DepositTypeCard(
                            deposit = deposit,
                            isSelected = selectedDepositIndex == index,
                            onClick = {
                                selectedDepositIndex = index
                                amountError = validateAmount(depositAmount)
                            }
                        )
                    }
                }
            }
            
            // Информация о выбранном вкладе
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = BankGreen.copy(alpha = 0.1f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = selectedDeposit.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = selectedDeposit.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = BankGreen
                            )
                        ) {
                            Text(
                                text = "${selectedDeposit.rate}%",
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                    
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    )
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Минимальная сумма",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = selectedDeposit.minAmount.replace("Минимальная сумма: ", ""),
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Срок действия",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = selectedDeposit.term,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
            
            // Поле ввода суммы
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AttachMoney,
                            contentDescription = "Сумма",
                            tint = BankGreen,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "Сумма вклада",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    
                    OutlinedTextField(
                        value = depositAmount,
                        onValueChange = {
                            depositAmount = it.filter { char -> char.isDigit() || char == '.' || char == ',' }
                                .replace(',', '.')
                            amountError = validateAmount(depositAmount)
                        },
                        label = { Text("Введите сумму") },
                        placeholder = { Text("0.00") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        suffix = {
                            if (depositAmount.isNotEmpty() && depositAmount.toDoubleOrNull() != null) {
                                Text("₽")
                            }
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.CreditCard,
                                contentDescription = null,
                                tint = BankGreen
                            )
                        },
                        isError = amountError.isNotEmpty(),
                        supportingText = {
                            if (amountError.isNotEmpty()) {
                                Text(
                                    amountError,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            } else {
                                Text(
                                    "Доступно: $formattedBalance",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BankGreen,
                            focusedLabelColor = BankGreen,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                            unfocusedLabelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    )
                }
            }
            
            // Калькулятор доходности
            if (depositAmount.isNotEmpty() && depositAmount.toDoubleOrNull() != null && depositAmount.toDoubleOrNull()!! > 0) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Calculate,
                                contentDescription = "Калькулятор",
                                tint = BankGreen,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = "Расчет доходности",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                        )
                        
                        // Текущая сумма
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Сумма вклада:",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                            Text(
                                text = formattedAmount,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        
                        // Процентная ставка
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Процентная ставка:",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                            Text(
                                text = "${selectedDeposit.rate}% годовых",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = BankGreen
                            )
                        }
                        
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                        )
                        
                        // Сумма через год
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Сумма через 1 год:",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (profit > 0) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Доход за год: $formattedProfit",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = BankGreen
                                    )
                                }
                            }
                            Text(
                                text = formattedFutureAmount,
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = BankGreen
                            )
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Кнопка открытия вклада
            Button(
                onClick = {
                    amountError = validateAmount(depositAmount)
                    if (amountError.isEmpty() && depositAmount.isNotEmpty()) {
                        val amount = depositAmount.toDoubleOrNull() ?: 0.0
                        if (amount > 0) {
                            scope.launch {
                                try {
                                    // Создаем новый вклад
                                    val result = depositService.createNewDeposit(
                                        selectedDeposit.name,
                                        amount,
                                        selectedDeposit.rate,
                                        selectedDeposit.term
                                    )
                                    result.onSuccess {
                                        // Списываем с баланса
                                        balanceService.subtractAmount(amount)
                                        // Добавляем транзакцию
                                        transactionService.addOpenDepositTransaction(amount, selectedDeposit.name)
                                        // Обновляем баланс
                                        currentBalance = balanceService.getBalance()
                                        formattedBalance = balanceService.formatBalance()
                                        onDepositOpened()
                                        onNavigateBack()
                                    }.onFailure { error ->
                                        amountError = "Ошибка: ${error.message}"
                                    }
                                } catch (e: Exception) {
                                    amountError = "Ошибка при открытии вклада"
                                }
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BankGreen,
                    contentColor = Color.White
                ),
                enabled = depositAmount.isNotEmpty() && depositAmount.toDoubleOrNull() != null && depositAmount.toDoubleOrNull()!! >= minAmountValue
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Открыть вклад",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun DepositTypeCard(
    deposit: AvailableDeposit,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .height(120.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) BankGreen else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) BankGreen else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = deposit.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) Color.White.copy(alpha = 0.2f) else BankGreen.copy(alpha = 0.15f)
                )
            ) {
                Text(
                    text = "${deposit.rate}%",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else BankGreen
                )
            }
        }
    }
}

