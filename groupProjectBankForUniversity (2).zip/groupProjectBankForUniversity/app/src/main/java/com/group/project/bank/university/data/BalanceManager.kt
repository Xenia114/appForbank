package com.group.project.bank.university.data

import android.content.Context
import android.content.SharedPreferences

class BalanceManager(private val context: Context) {
    private val prefs: SharedPreferences = 
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    companion object {
        private const val PREFS_NAME = "bank_app_prefs"
        private const val KEY_BALANCE = "balance"
        private const val DEFAULT_BALANCE = 1234567.0 // Начальный баланс
    }
    
    fun getBalance(): Double {
        return prefs.getFloat(KEY_BALANCE, DEFAULT_BALANCE.toFloat()).toDouble()
    }
    
    fun formatBalance(): String {
        val balance = getBalance()
        return String.format("%,.0f", balance).replace(",", " ") + " ₽"
    }
    
    fun subtractAmount(amount: Double) {
        val currentBalance = getBalance()
        val newBalance = (currentBalance - amount).coerceAtLeast(0.0)
        prefs.edit().putFloat(KEY_BALANCE, newBalance.toFloat()).apply()
    }
    
    fun addAmount(amount: Double) {
        val currentBalance = getBalance()
        val newBalance = currentBalance + amount
        prefs.edit().putFloat(KEY_BALANCE, newBalance.toFloat()).apply()
    }
    
    fun resetBalance() {
        prefs.edit().putFloat(KEY_BALANCE, DEFAULT_BALANCE.toFloat()).apply()
    }
}





