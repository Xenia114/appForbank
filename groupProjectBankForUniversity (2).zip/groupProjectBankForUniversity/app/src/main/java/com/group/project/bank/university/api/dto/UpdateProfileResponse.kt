package com.group.project.bank.university.api.dto

data class UpdateProfileResponse(
    val success: Boolean,
    val user: UserProfileResponse
)

