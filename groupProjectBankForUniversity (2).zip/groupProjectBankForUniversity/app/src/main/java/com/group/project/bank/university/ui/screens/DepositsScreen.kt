package com.group.project.bank.university.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.group.project.bank.university.service.ApiBalanceService
import com.group.project.bank.university.service.ApiDepositService
import com.group.project.bank.university.service.ApiTransactionService
import com.group.project.bank.university.data.DepositItem
import com.group.project.bank.university.ui.theme.BankGreen
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DepositsScreen(
    onNavigateBack: () -> Unit,
    onNavigateToOpenDeposit: () -> Unit,
    balanceService: ApiBalanceService
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val depositService = remember { ApiDepositService(context) }
    val transactionService = remember { ApiTransactionService(context) }
    var deposits by remember { mutableStateOf<List<DepositItem>>(emptyList()) }
    var showTopUpDialog by remember { mutableStateOf<Long?>(null) }
    var topUpAmount by remember { mutableStateOf("") }
    var topUpError by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }
    var currentBalance by remember { mutableStateOf(0.0) }
    var formattedBalance by remember { mutableStateOf("0 ₽") }
    
    // Загружаем вклады и баланс при первом запуске
    LaunchedEffect(Unit) {
        scope.launch {
            try {
                isLoading = true
                deposits = depositService.getDeposits()
                currentBalance = balanceService.getBalance()
                formattedBalance = balanceService.formatBalance()
            } catch (e: Exception) {
                // Обработка ошибок
            } finally {
                isLoading = false
            }
        }
    }
    
    val totalAmount = remember(deposits) {
        deposits.sumOf { 
            it.amount.replace(" ", "").toDoubleOrNull() ?: 0.0 
        }
    }
    val formattedTotal = remember(totalAmount) {
        String.format("%,d", totalAmount.toInt()).replace(",", " ") + " ₽"
    }
    
    fun validateTopUpAmount(amount: String): String {
        return when {
            amount.isEmpty() -> "Введите сумму"
            amount.toDoubleOrNull() == null -> "Сумма должна быть числом"
            amount.toDouble() <= 0 -> "Сумма должна быть больше нуля"
            amount.toDouble() > currentBalance -> "Недостаточно средств на счете"
            else -> ""
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Мои вклады",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Назад",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = MaterialTheme.colorScheme.onSurface
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Итоговая сумма
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = BankGreen
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Общая сумма вкладов",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = formattedTotal,
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${deposits.size} активных вклада",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Активные вклады",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Button(
                    onClick = onNavigateToOpenDeposit,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BankGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Открыть вклад",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Список вкладов
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = BankGreen)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(deposits.size) { index ->
                        val deposit = deposits[index]
                        DepositCard(
                            deposit = deposit,
                            onTopUpClick = { 
                                showTopUpDialog = deposit.id 
                            }
                        )
                    }
                }
            }
        }
    }
    
    // Диалог пополнения вклада
    showTopUpDialog?.let { depositId ->
        val deposit = deposits.find { it.id == depositId }
        deposit?.let { currentDeposit ->
            AlertDialog(
                onDismissRequest = { 
                    showTopUpDialog = null
                    topUpAmount = ""
                    topUpError = ""
                },
                title = {
                    Text(
                        text = "Пополнить вклад",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = currentDeposit.name,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium
                        )
                        OutlinedTextField(
                            value = topUpAmount,
                            onValueChange = { 
                                topUpAmount = it.filter { char -> char.isDigit() || char == '.' || char == ',' }
                                    .replace(',', '.')
                                topUpError = validateTopUpAmount(topUpAmount)
                            },
                            label = { Text("Сумма пополнения") },
                            placeholder = { Text("0.00") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal
                            ),
                            singleLine = true,
                            suffix = {
                                if (topUpAmount.isNotEmpty() && topUpAmount.toDoubleOrNull() != null) {
                                    Text("₽")
                                }
                            },
                            isError = topUpError.isNotEmpty(),
                            supportingText = {
                                if (topUpError.isNotEmpty()) {
                                    Text(
                                        topUpError, 
                                        color = MaterialTheme.colorScheme.error,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                } else {
                                    Text(
                                        "Доступно: $formattedBalance",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BankGreen,
                                focusedLabelColor = BankGreen
                            )
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            topUpError = validateTopUpAmount(topUpAmount)
                            if (topUpError.isEmpty() && topUpAmount.isNotEmpty()) {
                                val amount = topUpAmount.toDoubleOrNull() ?: 0.0
                                if (amount > 0) {
                                    scope.launch {
                                        try {
                                            // Пополняем вклад
                                            val result = depositService.addToDeposit(depositId, amount)
                                            result.onSuccess {
                                                // Списываем с баланса
                                                balanceService.subtractAmount(amount)
                                                // Добавляем транзакцию
                                                transactionService.addDepositTransaction(amount, currentDeposit.name)
                                                // Обновляем данные
                                                deposits = depositService.getDeposits()
                                                currentBalance = balanceService.getBalance()
                                                formattedBalance = balanceService.formatBalance()
                                                showTopUpDialog = null
                                                topUpAmount = ""
                                                topUpError = ""
                                            }.onFailure { error ->
                                                topUpError = "Ошибка: ${error.message}"
                                            }
                                        } catch (e: Exception) {
                                            topUpError = "Ошибка при пополнении вклада"
                                        }
                                    }
                                }
                            }
                        }
                    ) {
                        Text("Пополнить", color = BankGreen)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { 
                            showTopUpDialog = null
                            topUpAmount = ""
                            topUpError = ""
                        }
                    ) {
                        Text("Отмена", color = MaterialTheme.colorScheme.onSurface)
                    }
                },
                containerColor = MaterialTheme.colorScheme.surface
            )
        }
    }
    
}

@Composable
fun DepositCard(
    deposit: DepositItem,
    onTopUpClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = deposit.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = deposit.term,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = BankGreen.copy(alpha = 0.15f)
                    )
                ) {
                    Text(
                        text = deposit.rate,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BankGreen
                    )
                }
            }
            
            HorizontalDivider(
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Сумма вклада",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = deposit.amount,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Icon(
                    imageVector = Icons.Default.AccountBalance,
                    contentDescription = null,
                    tint = BankGreen,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    }
}

