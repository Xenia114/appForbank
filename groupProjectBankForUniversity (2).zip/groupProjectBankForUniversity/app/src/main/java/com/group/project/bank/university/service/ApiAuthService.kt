package com.group.project.bank.university.service

import android.content.Context
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.api.dto.LoginRequest
import com.group.project.bank.university.data.TokenManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ApiAuthService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val userApi = ApiClient.userApiService
    
    suspend fun login(phone: String, password: String): Result<Unit> {
        return try {
            withContext(Dispatchers.IO) {
                val request = LoginRequest(phone = phone, password = password)
                val response = userApi.login(request)
                tokenManager.saveToken(response.token, response.userId)
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    fun isLoggedIn(): Boolean {
        return tokenManager.hasToken()
    }
    
    suspend fun logout(): Result<Unit> {
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                if (token != null) {
                    userApi.logout(token)
                }
                tokenManager.clearToken()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            // Даже если запрос не удался, очищаем токен локально
            tokenManager.clearToken()
            Result.success(Unit)
        }
    }
    
    fun getToken(): String? {
        return tokenManager.getBearerToken()
    }
}

