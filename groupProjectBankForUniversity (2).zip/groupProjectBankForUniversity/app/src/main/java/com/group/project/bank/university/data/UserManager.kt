package com.group.project.bank.university.data

import android.content.Context
import android.content.SharedPreferences

class UserManager(private val context: Context) {
    private val prefs: SharedPreferences = 
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    companion object {
        private const val PREFS_NAME = "bank_app_prefs"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_PHONE = "user_phone"
        private const val KEY_USER_EMAIL = "user_email"
        
        private const val DEFAULT_NAME = "Иван Иванов"
        private const val DEFAULT_PHONE = "+7 999 123-45-67"
        private const val DEFAULT_EMAIL = "ivan.ivanov@example.com"
    }
    
    fun getUserName(): String {
        return prefs.getString(KEY_USER_NAME, DEFAULT_NAME) ?: DEFAULT_NAME
    }
    
    fun getUserPhone(): String {
        return prefs.getString(KEY_USER_PHONE, DEFAULT_PHONE) ?: DEFAULT_PHONE
    }
    
    fun getUserEmail(): String {
        return prefs.getString(KEY_USER_EMAIL, DEFAULT_EMAIL) ?: DEFAULT_EMAIL
    }
    
    fun setUserName(name: String) {
        prefs.edit().putString(KEY_USER_NAME, name).apply()
    }
    
    fun setUserPhone(phone: String) {
        prefs.edit().putString(KEY_USER_PHONE, phone).apply()
    }
    
    fun setUserEmail(email: String) {
        prefs.edit().putString(KEY_USER_EMAIL, email).apply()
    }
}

