package com.group.project.bank.university.api.dto

data class TransactionsResponse(
    val transactions: List<TransactionResponse>,
    val total: Int
)

