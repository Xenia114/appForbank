package com.group.project.bank.university.data

import android.content.Context
import android.content.SharedPreferences
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import com.google.common.truth.Truth.assertThat

/**
 * Юнит-тесты для класса BalanceManager
 * 
 * Что тестируем:
 * - Получение начального баланса
 * - Форматирование баланса
 * - Вычитание суммы (subtractAmount)
 * - Добавление суммы (addAmount)
 * - Сброс баланса (resetBalance)
 * - Защиту от отрицательного баланса
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class BalanceManagerTest {

    private lateinit var context: Context
    private lateinit var balanceManager: BalanceManager
    private lateinit var sharedPreferences: SharedPreferences

    /**
     * Подготовка тестового окружения перед каждым тестом
     */
    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        balanceManager = BalanceManager(context)
        sharedPreferences = context.getSharedPreferences(
            "bank_app_prefs",
            Context.MODE_PRIVATE
        )
        // Очищаем данные перед каждым тестом
        sharedPreferences.edit().clear().apply()
    }

    /**
     * Тест 1: Проверка начального баланса
     * 
     * Что проверяем:
     * - По умолчанию баланс должен быть равен DEFAULT_BALANCE (1234567.0)
     */
    @Test
    fun `getBalance should return default balance initially`() {
        // Выполняем действие: получаем баланс
        val balance = balanceManager.getBalance()
        
        // Проверяем результат: должен быть начальный баланс
        assertThat(balance).isEqualTo(1234567.0)
    }

    /**
     * Тест 2: Форматирование баланса
     * 
     * Что проверяем:
     * - Метод formatBalance() должен возвращать строку с форматированием
     * - Формат: "1 234 567 ₽" (с пробелами и символом рубля)
     */
    @Test
    fun `formatBalance should return formatted string with spaces and ruble sign`() {
        // Выполняем действие: форматируем баланс
        val formatted = balanceManager.formatBalance()
        
        // Проверяем результат: должна быть строка с пробелами и символом рубля
        assertThat(formatted).contains("₽")
        assertThat(formatted).contains(" ")
        // Проверяем, что формат правильный (примерно)
        assertThat(formatted).matches(".*\\d+.*₽")
    }

    /**
     * Тест 3: Вычитание суммы из баланса
     * 
     * Что проверяем:
     * - После вычитания баланс должен уменьшиться
     * - Новый баланс должен сохраниться в SharedPreferences
     */
    @Test
    fun `subtractAmount should decrease balance`() {
        // Подготовка: получаем начальный баланс
        val initialBalance = balanceManager.getBalance()
        val amountToSubtract = 1000.0
        
        // Выполняем действие: вычитаем сумму
        balanceManager.subtractAmount(amountToSubtract)
        
        // Проверяем результат: баланс должен уменьшиться
        val newBalance = balanceManager.getBalance()
        assertThat(newBalance).isEqualTo(initialBalance - amountToSubtract)
        
        // Проверяем сохранение в SharedPreferences
        val savedBalance = sharedPreferences.getFloat("balance", 0f).toDouble()
        assertThat(savedBalance).isEqualTo(newBalance)
    }

    /**
     * Тест 4: Баланс не должен стать отрицательным
     * 
     * Что проверяем:
     * - При попытке вычесть больше, чем есть на балансе, баланс должен стать 0
     * - Не должно быть отрицательного баланса
     */
    @Test
    fun `subtractAmount should not allow negative balance`() {
        // Подготовка: устанавливаем небольшой баланс
        val currentBalance = 100.0
        // Устанавливаем баланс через SharedPreferences напрямую
        sharedPreferences.edit().putFloat("balance", currentBalance.toFloat()).apply()
        
        // Выполняем действие: пытаемся вычесть больше, чем есть
        val amountToSubtract = 1000.0 // Больше, чем текущий баланс
        balanceManager.subtractAmount(amountToSubtract)
        
        // Проверяем результат: баланс должен быть 0, а не отрицательным
        val newBalance = balanceManager.getBalance()
        assertThat(newBalance).isAtLeast(0.0) // Должен быть >= 0
        assertThat(newBalance).isEqualTo(0.0) // Должен быть ровно 0
    }

    /**
     * Тест 5: Добавление суммы к балансу
     * 
     * Что проверяем:
     * - После добавления баланс должен увеличиться
     */
    @Test
    fun `addAmount should increase balance`() {
        // Подготовка: получаем начальный баланс
        val initialBalance = balanceManager.getBalance()
        val amountToAdd = 5000.0
        
        // Выполняем действие: добавляем сумму
        balanceManager.addAmount(amountToAdd)
        
        // Проверяем результат: баланс должен увеличиться
        val newBalance = balanceManager.getBalance()
        assertThat(newBalance).isEqualTo(initialBalance + amountToAdd)
    }

    /**
     * Тест 6: Сброс баланса к начальному значению
     * 
     * Что проверяем:
     * - После вызова resetBalance() баланс должен вернуться к DEFAULT_BALANCE
     */
    @Test
    fun `resetBalance should restore default balance`() {
        // Подготовка: изменяем баланс
        balanceManager.subtractAmount(100000.0)
        assertThat(balanceManager.getBalance()).isNotEqualTo(1234567.0)
        
        // Выполняем действие: сбрасываем баланс
        balanceManager.resetBalance()
        
        // Проверяем результат: баланс должен вернуться к начальному
        assertThat(balanceManager.getBalance()).isEqualTo(1234567.0)
    }

    /**
     * Тест 7: Множественные операции с балансом
     * 
     * Что проверяем:
     * - Последовательность операций должна работать корректно
     * - Баланс должен правильно изменяться при нескольких операциях
     */
    @Test
    fun `multiple operations should work correctly`() {
        // Подготовка: получаем начальный баланс
        val initialBalance = balanceManager.getBalance()
        
        // Выполняем последовательность действий
        balanceManager.addAmount(1000.0)
        balanceManager.subtractAmount(500.0)
        balanceManager.addAmount(200.0)
        
        // Проверяем результат: баланс должен быть правильно рассчитан
        val expectedBalance = initialBalance + 1000.0 - 500.0 + 200.0
        assertThat(balanceManager.getBalance()).isEqualTo(expectedBalance)
    }
}





