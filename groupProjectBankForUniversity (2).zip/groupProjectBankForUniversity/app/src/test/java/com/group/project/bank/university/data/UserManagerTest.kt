package com.group.project.bank.university.data

import android.content.Context
import android.content.SharedPreferences
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import com.google.common.truth.Truth.assertThat

/**
 * Юнит-тесты для класса UserManager
 * 
 * Что тестируем:
 * - Получение данных пользователя по умолчанию
 * - Сохранение и получение имени пользователя
 * - Сохранение и получение телефона пользователя
 * - Сохранение и получение email пользователя
 * - Сохранение данных между экземплярами UserManager
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class UserManagerTest {

    private lateinit var context: Context
    private lateinit var userManager: UserManager
    private lateinit var sharedPreferences: SharedPreferences

    /**
     * Подготовка тестового окружения перед каждым тестом
     */
    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        userManager = UserManager(context)
        sharedPreferences = context.getSharedPreferences(
            "bank_app_prefs",
            Context.MODE_PRIVATE
        )
        // Очищаем данные перед каждым тестом
        sharedPreferences.edit().clear().apply()
    }

    /**
     * Тест 1: Проверка значений по умолчанию
     * 
     * Что проверяем:
     * - Если данные не сохранены, должны возвращаться значения по умолчанию
     */
    @Test
    fun `should return default values when no data is saved`() {
        // Выполняем действия: получаем данные пользователя
        val name = userManager.getUserName()
        val phone = userManager.getUserPhone()
        val email = userManager.getUserEmail()
        
        // Проверяем результаты: должны быть значения по умолчанию
        assertThat(name).isEqualTo("Иван Иванов")
        assertThat(phone).isEqualTo("+7 999 123-45-67")
        assertThat(email).isEqualTo("ivan.ivanov@example.com")
    }

    /**
     * Тест 2: Сохранение и получение имени пользователя
     * 
     * Что проверяем:
     * - После сохранения имени, оно должно корректно возвращаться
     */
    @Test
    fun `setUserName and getUserName should work correctly`() {
        // Подготовка: новое имя для сохранения
        val newName = "Петр Петров"
        
        // Выполняем действие: сохраняем имя
        userManager.setUserName(newName)
        
        // Проверяем результат: имя должно быть сохранено
        assertThat(userManager.getUserName()).isEqualTo(newName)
        
        // Проверяем сохранение в SharedPreferences
        val savedName = sharedPreferences.getString("user_name", null)
        assertThat(savedName).isEqualTo(newName)
    }

    /**
     * Тест 3: Сохранение и получение телефона пользователя
     * 
     * Что проверяем:
     * - После сохранения телефона, он должен корректно возвращаться
     */
    @Test
    fun `setUserPhone and getUserPhone should work correctly`() {
        // Подготовка: новый телефон для сохранения
        val newPhone = "+7 999 888-77-66"
        
        // Выполняем действие: сохраняем телефон
        userManager.setUserPhone(newPhone)
        
        // Проверяем результат: телефон должен быть сохранен
        assertThat(userManager.getUserPhone()).isEqualTo(newPhone)
        
        // Проверяем сохранение в SharedPreferences
        val savedPhone = sharedPreferences.getString("user_phone", null)
        assertThat(savedPhone).isEqualTo(newPhone)
    }

    /**
     * Тест 4: Сохранение и получение email пользователя
     * 
     * Что проверяем:
     * - После сохранения email, он должен корректно возвращаться
     */
    @Test
    fun `setUserEmail and getUserEmail should work correctly`() {
        // Подготовка: новый email для сохранения
        val newEmail = "petr.petrov@example.com"
        
        // Выполняем действие: сохраняем email
        userManager.setUserEmail(newEmail)
        
        // Проверяем результат: email должен быть сохранен
        assertThat(userManager.getUserEmail()).isEqualTo(newEmail)
        
        // Проверяем сохранение в SharedPreferences
        val savedEmail = sharedPreferences.getString("user_email", null)
        assertThat(savedEmail).isEqualTo(newEmail)
    }

    /**
     * Тест 5: Сохранение всех данных пользователя
     * 
     * Что проверяем:
     * - Можно сохранить все данные пользователя одновременно
     * - Все данные должны корректно сохраняться и возвращаться
     */
    @Test
    fun `should save and retrieve all user data correctly`() {
        // Подготовка: новые данные пользователя
        val newName = "Сидор Сидоров"
        val newPhone = "+7 999 111-22-33"
        val newEmail = "sidor.sidorov@example.com"
        
        // Выполняем действия: сохраняем все данные
        userManager.setUserName(newName)
        userManager.setUserPhone(newPhone)
        userManager.setUserEmail(newEmail)
        
        // Проверяем результаты: все данные должны быть сохранены
        assertThat(userManager.getUserName()).isEqualTo(newName)
        assertThat(userManager.getUserPhone()).isEqualTo(newPhone)
        assertThat(userManager.getUserEmail()).isEqualTo(newEmail)
    }

    /**
     * Тест 6: Данные должны сохраняться между экземплярами UserManager
     * 
     * Что проверяем:
     * - Если создать новый экземпляр UserManager, он должен видеть сохраненные данные
     * - Это имитирует ситуацию перезапуска приложения
     */
    @Test
    fun `user data should persist between UserManager instances`() {
        // Подготовка: сохраняем данные через первый экземпляр
        val testName = "Тестовый Пользователь"
        val testPhone = "+7 999 999-99-99"
        val testEmail = "test@test.com"
        
        userManager.setUserName(testName)
        userManager.setUserPhone(testPhone)
        userManager.setUserEmail(testEmail)
        
        // Выполняем действие: создаем новый экземпляр UserManager
        val newUserManager = UserManager(context)
        
        // Проверяем результат: новый экземпляр должен видеть сохраненные данные
        assertThat(newUserManager.getUserName()).isEqualTo(testName)
        assertThat(newUserManager.getUserPhone()).isEqualTo(testPhone)
        assertThat(newUserManager.getUserEmail()).isEqualTo(testEmail)
    }

    /**
     * Тест 7: Обновление данных пользователя
     * 
     * Что проверяем:
     * - Можно обновить данные пользователя несколько раз
     * - Последнее сохраненное значение должно быть актуальным
     */
    @Test
    fun `should update user data correctly`() {
        // Подготовка: сохраняем первые данные
        userManager.setUserName("Первое Имя")
        userManager.setUserPhone("+7 111 111-11-11")
        userManager.setUserEmail("first@example.com")
        
        // Выполняем действие: обновляем данные
        userManager.setUserName("Второе Имя")
        userManager.setUserPhone("+7 222 222-22-22")
        userManager.setUserEmail("second@example.com")
        
        // Проверяем результат: должны быть последние сохраненные значения
        assertThat(userManager.getUserName()).isEqualTo("Второе Имя")
        assertThat(userManager.getUserPhone()).isEqualTo("+7 222 222-22-22")
        assertThat(userManager.getUserEmail()).isEqualTo("second@example.com")
    }
}





