package com.group.project.bank.university.data

import android.content.Context
import android.content.SharedPreferences
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import com.google.common.truth.Truth.assertThat

/**
 * Юнит-тесты для класса TransactionManager
 * 
 * Что тестируем:
 * - Получение списка транзакций по умолчанию
 * - Добавление новой транзакции (addTransaction)
 * - Добавление транзакции перевода (addTransferTransaction)
 * - Добавление транзакции пополнения вклада (addDepositTransaction)
 * - Добавление транзакции открытия вклада (addOpenDepositTransaction)
 * - Сохранение и загрузку транзакций через Gson
 * - Форматирование даты и суммы
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class TransactionManagerTest {

    private lateinit var context: Context
    private lateinit var transactionManager: TransactionManager
    private lateinit var sharedPreferences: SharedPreferences

    /**
     * Подготовка тестового окружения перед каждым тестом
     */
    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        transactionManager = TransactionManager(context)
        sharedPreferences = context.getSharedPreferences(
            "bank_app_prefs",
            Context.MODE_PRIVATE
        )
        // Очищаем данные перед каждым тестом
        sharedPreferences.edit().clear().apply()
    }

    /**
     * Тест 1: Проверка транзакций по умолчанию
     * 
     * Что проверяем:
     * - Если транзакции не сохранены, должны возвращаться транзакции по умолчанию
     * - Должно быть 4 транзакции по умолчанию
     */
    @Test
    fun `getTransactions should return default transactions when no data is saved`() {
        // Выполняем действие: получаем список транзакций
        val transactions = transactionManager.getTransactions()
        
        // Проверяем результат: должно быть 4 транзакции по умолчанию
        assertThat(transactions).hasSize(4)
        
        // Проверяем, что первая транзакция имеет правильные данные
        val firstTransaction = transactions[0]
        assertThat(firstTransaction.title).isEqualTo("Пополнение")
        assertThat(firstTransaction.isPositive).isTrue()
    }

    /**
     * Тест 2: Добавление новой транзакции
     * 
     * Что проверяем:
     * - После добавления транзакции она должна появиться в списке
     * - Новая транзакция должна быть в начале списка (новые сверху)
     * - Транзакция должна иметь правильные данные
     */
    @Test
    fun `addTransaction should add new transaction to the beginning of list`() {
        // Подготовка: получаем начальное количество транзакций
        val initialCount = transactionManager.getTransactions().size
        
        // Подготовка: данные для новой транзакции
        val title = "Тестовая транзакция"
        val amount = 1000.0
        val isPositive = true
        val iconName = "ArrowDownward"
        
        // Выполняем действие: добавляем транзакцию
        transactionManager.addTransaction(title, amount, isPositive, iconName)
        
        // Проверяем результат: количество транзакций должно увеличиться
        val transactions = transactionManager.getTransactions()
        assertThat(transactions).hasSize(initialCount + 1)
        
        // Проверяем, что новая транзакция в начале списка
        val newTransaction = transactions[0]
        assertThat(newTransaction.title).isEqualTo(title)
        assertThat(newTransaction.isPositive).isEqualTo(isPositive)
        assertThat(newTransaction.iconName).isEqualTo(iconName)
        // Проверяем форматирование суммы
        assertThat(newTransaction.amount).contains("1 000")
        assertThat(newTransaction.amount).contains("₽")
    }

    /**
     * Тест 3: Добавление транзакции перевода
     * 
     * Что проверяем:
     * - Метод addTransferTransaction должен создавать транзакцию с правильными данными
     * - Транзакция должна быть отрицательной (isPositive = false)
     * - Название должно содержать последние 4 цифры карты
     */
    @Test
    fun `addTransferTransaction should create transfer transaction correctly`() {
        // Подготовка: данные для перевода
        val amount = 5000.0
        val recipientCard = "1234 5678 9012 3456"
        
        // Выполняем действие: добавляем транзакцию перевода
        transactionManager.addTransferTransaction(amount, recipientCard)
        
        // Проверяем результат: транзакция должна быть добавлена
        val transactions = transactionManager.getTransactions()
        val transferTransaction = transactions[0] // Новая транзакция в начале
        
        assertThat(transferTransaction.title).contains("Перевод на карту")
        assertThat(transferTransaction.title).contains("3456") // Последние 4 цифры
        assertThat(transferTransaction.isPositive).isFalse()
        assertThat(transferTransaction.iconName).isEqualTo("ArrowUpward")
        assertThat(transferTransaction.amount).contains("-")
    }

    /**
     * Тест 4: Добавление транзакции пополнения вклада
     * 
     * Что проверяем:
     * - Метод addDepositTransaction должен создавать транзакцию с правильными данными
     * - Транзакция должна быть отрицательной (деньги уходят со счета)
     * - Название должно содержать имя вклада
     */
    @Test
    fun `addDepositTransaction should create deposit transaction correctly`() {
        // Подготовка: данные для пополнения вклада
        val amount = 10000.0
        val depositName = "Накопительный вклад"
        
        // Выполняем действие: добавляем транзакцию пополнения вклада
        transactionManager.addDepositTransaction(amount, depositName)
        
        // Проверяем результат: транзакция должна быть добавлена
        val transactions = transactionManager.getTransactions()
        val depositTransaction = transactions[0]
        
        assertThat(depositTransaction.title).contains("Пополнение вклада")
        assertThat(depositTransaction.title).contains(depositName)
        assertThat(depositTransaction.isPositive).isFalse()
        assertThat(depositTransaction.iconName).isEqualTo("AccountBalance")
    }

    /**
     * Тест 5: Добавление транзакции открытия вклада
     * 
     * Что проверяем:
     * - Метод addOpenDepositTransaction должен создавать транзакцию с правильными данными
     * - Транзакция должна быть отрицательной (деньги уходят со счета)
     * - Название должно содержать имя вклада
     */
    @Test
    fun `addOpenDepositTransaction should create open deposit transaction correctly`() {
        // Подготовка: данные для открытия вклада
        val amount = 50000.0
        val depositName = "Срочный вклад"
        
        // Выполняем действие: добавляем транзакцию открытия вклада
        transactionManager.addOpenDepositTransaction(amount, depositName)
        
        // Проверяем результат: транзакция должна быть добавлена
        val transactions = transactionManager.getTransactions()
        val openDepositTransaction = transactions[0]
        
        assertThat(openDepositTransaction.title).contains("Открытие вклада")
        assertThat(openDepositTransaction.title).contains(depositName)
        assertThat(openDepositTransaction.isPositive).isFalse()
        assertThat(openDepositTransaction.iconName).isEqualTo("AccountBalance")
    }

    /**
     * Тест 6: Сохранение и загрузка транзакций
     * 
     * Что проверяем:
     * - Транзакции должны сохраняться в SharedPreferences через Gson
     * - При создании нового экземпляра TransactionManager транзакции должны загружаться
     */
    @Test
    fun `transactions should persist between TransactionManager instances`() {
        // Подготовка: добавляем транзакцию через первый экземпляр
        transactionManager.addTransaction(
            "Тестовая транзакция",
            1000.0,
            true,
            "ArrowDownward"
        )
        
        val initialCount = transactionManager.getTransactions().size
        
        // Выполняем действие: создаем новый экземпляр TransactionManager
        val newTransactionManager = TransactionManager(context)
        
        // Проверяем результат: новый экземпляр должен видеть сохраненные транзакции
        val transactions = newTransactionManager.getTransactions()
        assertThat(transactions).hasSize(initialCount)
        
        // Проверяем, что тестовая транзакция присутствует
        val testTransaction = transactions.find { it.title == "Тестовая транзакция" }
        assertThat(testTransaction).isNotNull()
    }

    /**
     * Тест 7: Форматирование суммы в транзакциях
     * 
     * Что проверяем:
     * - Положительные транзакции должны иметь знак "+"
     * - Отрицательные транзакции должны иметь знак "-"
     * - Сумма должна быть отформатирована с пробелами
     */
    @Test
    fun `transaction amount should be formatted correctly with sign`() {
        // Выполняем действия: добавляем положительную и отрицательную транзакции
        transactionManager.addTransaction("Пополнение", 1000.0, true, "ArrowDownward")
        transactionManager.addTransaction("Списание", 500.0, false, "ArrowUpward")
        
        // Проверяем результаты
        val transactions = transactionManager.getTransactions()
        
        // Положительная транзакция (вторая по счету, так как новые добавляются в начало)
        val positiveTransaction = transactions[1]
        assertThat(positiveTransaction.amount).startsWith("+")
        assertThat(positiveTransaction.amount).contains("1 000")
        
        // Отрицательная транзакция (первая в списке)
        val negativeTransaction = transactions[0]
        assertThat(negativeTransaction.amount).startsWith("-")
        assertThat(negativeTransaction.amount).contains("500")
    }

    /**
     * Тест 8: Множественные транзакции
     * 
     * Что проверяем:
     * - Можно добавить несколько транзакций подряд
     * - Все транзакции должны корректно сохраняться
     * - Новые транзакции должны быть в начале списка
     */
    @Test
    fun `multiple transactions should be added correctly`() {
        // Выполняем последовательность действий: добавляем несколько транзакций
        transactionManager.addTransaction("Транзакция 1", 100.0, true, "ArrowDownward")
        transactionManager.addTransaction("Транзакция 2", 200.0, false, "ArrowUpward")
        transactionManager.addTransaction("Транзакция 3", 300.0, true, "AccountBalance")
        
        // Проверяем результаты
        val transactions = transactionManager.getTransactions()
        
        // Проверяем, что все транзакции добавлены
        assertThat(transactions.size).isAtLeast(3)
        
        // Проверяем порядок: последняя добавленная должна быть первой
        assertThat(transactions[0].title).isEqualTo("Транзакция 3")
        assertThat(transactions[1].title).isEqualTo("Транзакция 2")
        assertThat(transactions[2].title).isEqualTo("Транзакция 1")
    }
}





