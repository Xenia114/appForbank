package com.group.project.bank.university.data

import android.content.Context
import android.content.SharedPreferences
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import com.google.common.truth.Truth.assertThat

/**
 * Юнит-тесты для класса AuthManager
 * 
 * Что тестируем:
 * - Сохранение и получение состояния авторизации
 * - Метод logout()
 * - Правильность работы с SharedPreferences
 * 
 * Robolectric позволяет запускать Android-тесты на JVM без эмулятора
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28]) // Указываем версию Android SDK для тестирования
class AuthManagerTest {

    // Контекст приложения (создается Robolectric)
    private lateinit var context: Context
    
    // Объект AuthManager, который будем тестировать
    private lateinit var authManager: AuthManager
    
    // SharedPreferences для проверки сохраненных данных
    private lateinit var sharedPreferences: SharedPreferences

    /**
     * Метод, который выполняется ПЕРЕД каждым тестом
     * Здесь мы подготавливаем тестовое окружение
     */
    @Before
    fun setUp() {
        // Robolectric создает тестовый контекст Android-приложения
        context = RuntimeEnvironment.getApplication()
        
        // Создаем экземпляр AuthManager для тестирования
        authManager = AuthManager(context)
        
        // Получаем доступ к SharedPreferences для проверки сохраненных данных
        sharedPreferences = context.getSharedPreferences(
            "bank_app_prefs",
            Context.MODE_PRIVATE
        )
        
        // Очищаем SharedPreferences перед каждым тестом
        // Это гарантирует, что тесты не зависят друг от друга
        sharedPreferences.edit().clear().apply()
    }

    /**
     * Тест 1: Проверка начального состояния (пользователь не авторизован)
     * 
     * Что проверяем:
     * - По умолчанию isLoggedIn() должен возвращать false
     */
    @Test
    fun `isLoggedIn should return false by default`() {
        // Выполняем действие: проверяем состояние авторизации
        val result = authManager.isLoggedIn()
        
        // Проверяем результат: должно быть false
        assertThat(result).isFalse()
    }

    /**
     * Тест 2: Установка состояния авторизации в true
     * 
     * Что проверяем:
     * - После вызова setLoggedIn(true) метод isLoggedIn() должен вернуть true
     * - Значение должно сохраниться в SharedPreferences
     */
    @Test
    fun `setLoggedIn true should make isLoggedIn return true`() {
        // Выполняем действие: устанавливаем авторизацию
        authManager.setLoggedIn(true)
        
        // Проверяем результат через метод AuthManager
        assertThat(authManager.isLoggedIn()).isTrue()
        
        // Проверяем результат напрямую в SharedPreferences
        // Это гарантирует, что данные действительно сохранились
        assertThat(sharedPreferences.getBoolean("is_logged_in", false)).isTrue()
    }

    /**
     * Тест 3: Установка состояния авторизации в false
     * 
     * Что проверяем:
     * - После вызова setLoggedIn(false) метод isLoggedIn() должен вернуть false
     */
    @Test
    fun `setLoggedIn false should make isLoggedIn return false`() {
        // Сначала устанавливаем true
        authManager.setLoggedIn(true)
        // Затем устанавливаем false
        authManager.setLoggedIn(false)
        
        // Проверяем результат
        assertThat(authManager.isLoggedIn()).isFalse()
        assertThat(sharedPreferences.getBoolean("is_logged_in", true)).isFalse()
    }

    /**
     * Тест 4: Метод logout() должен устанавливать авторизацию в false
     * 
     * Что проверяем:
     * - После вызова logout() пользователь должен быть разлогинен
     */
    @Test
    fun `logout should set isLoggedIn to false`() {
        // Сначала авторизуем пользователя
        authManager.setLoggedIn(true)
        assertThat(authManager.isLoggedIn()).isTrue()
        
        // Выполняем действие: выходим из системы
        authManager.logout()
        
        // Проверяем результат: пользователь должен быть разлогинен
        assertThat(authManager.isLoggedIn()).isFalse()
        assertThat(sharedPreferences.getBoolean("is_logged_in", true)).isFalse()
    }

    /**
     * Тест 5: Сохранение состояния между вызовами
     * 
     * Что проверяем:
     * - Состояние авторизации должно сохраняться между вызовами методов
     * - Новый экземпляр AuthManager должен читать сохраненные данные
     */
    @Test
    fun `auth state should persist between AuthManager instances`() {
        // Создаем первый экземпляр и устанавливаем авторизацию
        val authManager1 = AuthManager(context)
        authManager1.setLoggedIn(true)
        
        // Создаем второй экземпляр (как будто перезапустили приложение)
        val authManager2 = AuthManager(context)
        
        // Проверяем: второй экземпляр должен видеть сохраненное состояние
        assertThat(authManager2.isLoggedIn()).isTrue()
    }
}





