 # Инструкция по настройке микросервисов

## ✅ Что уже сделано в коде

Все изменения в Android приложении уже внесены:
- ✅ Добавлены зависимости Retrofit
- ✅ Созданы DTO классы для API
- ✅ Созданы Retrofit интерфейсы
- ✅ Созданы API сервисы (ApiAuthService, ApiUserService, ApiBalanceService, и т.д.)
- ✅ Обновлены все экраны для работы с API
- ✅ Добавлен TokenManager для хранения JWT токенов

## 📋 Что нужно сделать вам

### 1. Настроить базы данных PostgreSQL

#### User Service Database

```sql
-- Подключиться к PostgreSQL
psql -U postgres

-- Создать базу данных
CREATE DATABASE user_service_db;

-- Создать пользователя
CREATE USER user_service_user WITH PASSWORD 'user_service_password';

-- Выдать права
GRANT ALL PRIVILEGES ON DATABASE user_service_db TO user_service_user;

-- Подключиться к базе данных
\c user_service_db

-- Создать таблицы
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    phone VARCHAR(20) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_sessions (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token VARCHAR(500) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_sessions_user_id ON user_sessions(user_id);
CREATE INDEX idx_sessions_token ON user_sessions(token);
CREATE INDEX idx_sessions_expires_at ON user_sessions(expires_at);

-- Вставить тестового пользователя
-- Пароль: password123 (хеш bcrypt)
INSERT INTO users (phone, password_hash, name, email) 
VALUES ('+79991234567', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Иван Иванов', 'ivan.ivanov@example.com');
```

#### Banking Service Database

```sql
-- Создать базу данных
CREATE DATABASE banking_service_db;

-- Создать пользователя
CREATE USER banking_service_user WITH PASSWORD 'banking_service_password';

-- Выдать права
GRANT ALL PRIVILEGES ON DATABASE banking_service_db TO banking_service_user;

-- Подключиться к базе данных
\c banking_service_db

-- Создать таблицы
CREATE TABLE balances (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    balance DECIMAL(15, 2) NOT NULL DEFAULT 1234567.00,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transactions (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    title VARCHAR(255) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    is_positive BOOLEAN NOT NULL,
    icon_name VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE deposits (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    name VARCHAR(255) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    rate DECIMAL(5, 2) NOT NULL,
    term VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_balances_user_id ON balances(user_id);
CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_created_at ON transactions(created_at DESC);
CREATE INDEX idx_deposits_user_id ON deposits(user_id);

-- Вставить начальные данные для тестового пользователя (user_id = 1)
INSERT INTO balances (user_id, balance) VALUES (1, 1234567.00);

INSERT INTO transactions (user_id, title, amount, is_positive, icon_name) VALUES
(1, 'Пополнение', 5000.00, true, 'ArrowDownward'),
(1, 'Перевод', 2500.00, false, 'ArrowUpward'),
(1, 'Покупка', 1200.00, false, 'ShoppingCart'),
(1, 'Зарплата', 50000.00, true, 'AccountBalance');

INSERT INTO deposits (user_id, name, amount, rate, term) VALUES
(1, 'Накопительный вклад', 500000.00, 5.5, 'До 31.12.2024'),
(1, 'Срочный вклад', 300000.00, 7.0, 'До 30.06.2025'),
(1, 'Пенсионный вклад', 150000.00, 6.0, 'До 31.12.2024'),
(1, 'Сберегательный вклад', 200000.00, 4.5, 'До 31.03.2025');
```

### 2. Создать проекты микросервисов

#### User Service

1. Открыть https://start.spring.io/
2. Настроить:
   - **Project:** Gradle - Kotlin
   - **Language:** Kotlin
   - **Spring Boot:** 3.2.0
   - **Group:** `com.group.project.bank`
   - **Artifact:** `user-service`
   - **Java:** 17
   - **Dependencies:** 
     - Spring Web
     - Spring Data JPA
     - PostgreSQL Driver
     - Spring Security
     - Spring Boot Starter Data Redis
     - Validation
3. Скачать и распаковать
4. Скопировать код из `MICROSERVICES_IMPLEMENTATION_GUIDE.md` (раздел "Реализация User Service")

#### Banking Service

1. Открыть https://start.spring.io/
2. Настроить:
   - **Project:** Gradle - Kotlin
   - **Language:** Kotlin
   - **Spring Boot:** 3.2.0
   - **Group:** `com.group.project.bank`
   - **Artifact:** `banking-service`
   - **Java:** 17
   - **Dependencies:**
     - Spring Web
     - Spring Data JPA
     - PostgreSQL Driver
     - Spring Security
     - Validation
3. Скачать и распаковать
4. Скопировать код из `MICROSERVICES_IMPLEMENTATION_GUIDE.md` (раздел "Реализация Banking Service")

### 3. Настроить application.properties

#### User Service (user-service/src/main/resources/application.properties)

```properties
server.port=5432

spring.datasource.url=jdbc:postgresql://localhost:5432/user_service_db
spring.datasource.username=user_service_user
spring.datasource.password=user_service_password
spring.datasource.driver-class-name=org.postgresql.Driver

spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect
spring.jpa.properties.hibernate.format_sql=true

spring.data.redis.host=localhost
spring.data.redis.port=6379
spring.data.redis.timeout=2000ms

jwt.secret=your-secret-key-change-this-in-production-min-256-bits-very-long-secret-key-for-jwt-token-generation
jwt.expiration=3600000

logging.level.com.group.project.bank.userservice=DEBUG
```

#### Banking Service (banking-service/src/main/resources/application.properties)

```properties
server.port=8082

spring.datasource.url=jdbc:postgresql://localhost:5432/banking_service_db
spring.datasource.username=banking_service_user
spring.datasource.password=banking_service_password
spring.datasource.driver-class-name=org.postgresql.Driver

spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect

jwt.secret=your-secret-key-change-this-in-production-min-256-bits-very-long-secret-key-for-jwt-token-generation
jwt.expiration=3600000

logging.level.com.group.project.bank.bankingservice=DEBUG
```

**⚠️ ВАЖНО:** В обоих сервисах `jwt.secret` должен быть одинаковым!

### 4. Запустить Redis

**Windows:**
```bash
redis-server
```

**macOS:**
```bash
brew services start redis
```

**Linux:**
```bash
sudo systemctl start redis
```

### 5. Запустить микросервисы

#### User Service
```bash
cd user-service
./gradlew bootRun
```

#### Banking Service
```bash
cd banking-service
./gradlew bootRun
```

Или запустить из IntelliJ IDEA:
- Открыть проект
- Найти `UserServiceApplication.kt` и `BankingServiceApplication.kt`
- Правой кнопкой → Run

### 6. Настроить Android приложение

#### Для эмулятора Android

В файле `app/src/main/java/com/group/project/bank/university/api/ApiClient.kt` уже настроено:
```kotlin
private const val USER_SERVICE_BASE_URL = "http://10.0.2.2:8081/"
private const val BANKING_SERVICE_BASE_URL = "http://10.0.2.2:8082/"
```

Это правильно для эмулятора. Ничего менять не нужно.

#### Для реального устройства

1. Узнать IP адрес вашего компьютера:
   - **Windows:** `ipconfig` (IPv4 адрес)
   - **macOS/Linux:** `ifconfig` или `ip addr`
2. Заменить в `ApiClient.kt`:
```kotlin
private const val USER_SERVICE_BASE_URL = "http://ВАШ_IP:8081/"
private const val BANKING_SERVICE_BASE_URL = "http://ВАШ_IP:8082/"
```
3. Убедиться, что устройство и компьютер в одной Wi-Fi сети
4. Отключить файрвол или разрешить порты 8081 и 8082

### 7. Добавить разрешение на интернет в AndroidManifest.xml

Убедитесь, что в `app/src/main/AndroidManifest.xml` есть:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

### 8. Тестирование

1. Запустить оба микросервиса
2. Запустить Android приложение
3. Войти с тестовыми данными:
   - Телефон: `+79991234567`
   - Пароль: `password123`

## 🔧 Устранение проблем

### Ошибка подключения к базе данных
- Проверить, что PostgreSQL запущен
- Проверить правильность паролей в `application.properties`
- Проверить, что базы данных созданы

### Ошибка подключения к Redis
- Проверить, что Redis запущен: `redis-cli ping` (должен вернуть PONG)
- Проверить настройки в `application.properties`

### Ошибка 401 Unauthorized
- Проверить, что `jwt.secret` одинаковый в обоих сервисах
- Проверить, что токен передается в заголовке `Authorization: Bearer {token}`

### Ошибка сети в Android
- Проверить, что сервисы запущены
- Проверить правильность URL в `ApiClient.kt`
- Проверить разрешения в `AndroidManifest.xml`
- Для реального устройства: проверить, что устройство и компьютер в одной сети

## 📝 Чеклист

- [ ] PostgreSQL установлен и запущен
- [ ] Базы данных созданы (user_service_db, banking_service_db)
- [ ] Таблицы созданы и заполнены тестовыми данными
- [ ] Redis установлен и запущен
- [ ] User Service проект создан
- [ ] Banking Service проект создан
- [ ] Код скопирован из руководства
- [ ] application.properties настроены
- [ ] jwt.secret одинаковый в обоих сервисах
- [ ] User Service запущен на порту 8081
- [ ] Banking Service запущен на порту 8082
- [ ] Android приложение настроено (URL в ApiClient.kt)
- [ ] Разрешения на интернет добавлены в AndroidManifest.xml
- [ ] Приложение протестировано

## 🎉 Готово!

После выполнения всех шагов приложение должно работать с микросервисами!

