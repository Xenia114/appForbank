# Подробное руководство по реализации микросервисов

## 📋 Содержание
1. [Установка необходимого ПО](#установка-необходимого-по)
2. [Создание структуры проектов](#создание-структуры-проектов)
3. [Настройка баз данных](#настройка-баз-данных)
4. [Реализация User Service](#реализация-user-service)
5. [Реализация Banking Service](#реализация-banking-service)
6. [Тестирование сервисов](#тестирование-сервисов)
7. [Интеграция с Android приложением](#интеграция-с-android-приложением)

---

## 🛠️ Установка необходимого ПО

### 1. Java Development Kit (JDK) 17 или выше

**Windows:**
1. Скачать JDK 17 с официального сайта Oracle: https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html
   - Или использовать OpenJDK: https://adoptium.net/
   - Выбрать версию для Windows x64
2. Установить JDK (следовать инструкциям установщика)
3. Проверить установку:
   ```bash
   java -version
   javac -version
   ```
4. Настроить переменные окружения:
   - `JAVA_HOME` = путь к папке JDK (например, `C:\Program Files\Java\jdk-17`)
   - Добавить в `PATH`: `%JAVA_HOME%\bin`

**macOS:**
```bash
brew install openjdk@17
```

**Linux:**
```bash
sudo apt update
sudo apt install openjdk-17-jdk
```

---

### 2. IntelliJ IDEA Community Edition (или Ultimate)

**Скачать:**
- https://www.jetbrains.com/idea/download/
- Выбрать Community Edition (бесплатная)

**Установка:**
- Windows: запустить установщик и следовать инструкциям
- macOS: распаковать .dmg и перетащить в Applications
- Linux: распаковать .tar.gz и запустить `bin/idea.sh`

---

### 3. PostgreSQL 15 или выше

**Windows:**
1. Скачать: https://www.postgresql.org/download/windows/
2. Установить PostgreSQL (запомнить пароль для пользователя postgres!)
3. Проверить установку:
   ```bash
   psql --version
   ```

**macOS:**
```bash
brew install postgresql@15
brew services start postgresql@15
```

**Linux:**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

**Создать базы данных:**
```bash
# Войти в PostgreSQL
psql -U postgres

# Создать базы данных
CREATE DATABASE user_service_db;
CREATE DATABASE banking_service_db;

# Создать пользователей
CREATE USER user_service_user WITH PASSWORD 'user_service_password';
CREATE USER banking_service_user WITH PASSWORD 'banking_service_password';

# Выдать права
GRANT ALL PRIVILEGES ON DATABASE user_service_db TO user_service_user;
GRANT ALL PRIVILEGES ON DATABASE banking_service_db TO banking_service_user;

# Выйти
\q
```

---

### 4. Redis

**Windows:**
1. Скачать: https://github.com/microsoftarchive/redis/releases
   - Или использовать WSL2 с Redis
   - Или использовать Docker (рекомендуется)
2. Запустить Redis:
   ```bash
   redis-server
   ```

**macOS:**
```bash
brew install redis
brew services start redis
```

**Linux:**
```bash
sudo apt update
sudo apt install redis-server
sudo systemctl start redis
```

**Проверка:**
```bash
redis-cli ping
# Должен вернуть: PONG
```

---

### 5. Docker (опционально, но рекомендуется)

**Для упрощения запуска PostgreSQL и Redis:**

**Windows:**
1. Скачать Docker Desktop: https://www.docker.com/products/docker-desktop/
2. Установить и запустить Docker Desktop

**macOS:**
```bash
brew install --cask docker
```

**Linux:**
```bash
sudo apt update
sudo apt install docker.io
sudo systemctl start docker
```

**Docker Compose файл для быстрого запуска:**
Создать файл `docker-compose.yml` в корне проекта:
```yaml
version: '3.8'

services:
  postgres-user:
    image: postgres:15
    container_name: postgres-user
    environment:
      POSTGRES_DB: user_service_db
      POSTGRES_USER: user_service_user
      POSTGRES_PASSWORD: user_service_password
    ports:
      - "5432:5432"
    volumes:
      - postgres-user-data:/var/lib/postgresql/data

  postgres-banking:
    image: postgres:15
    container_name: postgres-banking
    environment:
      POSTGRES_DB: banking_service_db
      POSTGRES_USER: banking_service_user
      POSTGRES_PASSWORD: banking_service_password
    ports:
      - "5433:5432"
    volumes:
      - postgres-banking-data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    container_name: redis
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data

volumes:
  postgres-user-data:
  postgres-banking-data:
  redis-data:
```

**Запуск:**
```bash
docker-compose up -d
```

---

### 6. Postman (для тестирования API)

**Скачать:**
- https://www.postman.com/downloads/
- Установить и создать аккаунт (бесплатно)

---

## 📁 Создание структуры проектов

### Вариант 1: Использование Spring Initializr

1. Открыть https://start.spring.io/
2. Настроить проект для **User Service**:
   - **Project:** Gradle - Kotlin
   - **Language:** Kotlin
   - **Spring Boot:** 3.2.0
   - **Project Metadata:**
     - Group: `com.group.project.bank`
     - Artifact: `user-service`
     - Name: `user-service`
     - Package name: `com.group.project.bank.userservice`
     - Packaging: Jar
     - Java: 17
   - **Dependencies:** Добавить:
     - Spring Web
     - Spring Data JPA
     - PostgreSQL Driver
     - Spring Security
     - Spring Boot Starter Data Redis
     - JSON Web Token (JWT)
     - Validation
3. Нажать "Generate" и скачать ZIP
4. Повторить для **Banking Service**:
   - Artifact: `banking-service`
   - Name: `banking-service`
   - Package name: `com.group.project.bank.bankingservice`
   - **Dependencies:** Добавить:
     - Spring Web
     - Spring Data JPA
     - PostgreSQL Driver
     - Spring Security
     - JSON Web Token (JWT)
     - Validation
     - Spring Boot Starter Data Redis (опционально)

### Вариант 2: Создание вручную в IntelliJ IDEA

1. **File → New → Project**
2. Выбрать **Spring Initializr**
3. Настроить как описано выше
4. Нажать **Next** и выбрать зависимости
5. Нажать **Finish**

---

## 🗄️ Настройка баз данных

### User Service Database

**Создать файл миграции:** `user-service/src/main/resources/db/migration/V1__create_users_table.sql`

```sql
-- Таблица пользователей
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    phone VARCHAR(20) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица сессий (для Redis, но можно и в PostgreSQL)
CREATE TABLE user_sessions (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token VARCHAR(500) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Индексы
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_sessions_user_id ON user_sessions(user_id);
CREATE INDEX idx_sessions_token ON user_sessions(token);
CREATE INDEX idx_sessions_expires_at ON user_sessions(expires_at);

-- Вставка тестового пользователя (пароль: password123, хеш bcrypt)
INSERT INTO users (phone, password_hash, name, email) 
VALUES ('+79991234567', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Иван Иванов', 'ivan.ivanov@example.com');
```

### Banking Service Database

**Создать файл миграции:** `banking-service/src/main/resources/db/migration/V1__create_banking_tables.sql`

```sql
-- Таблица балансов
CREATE TABLE balances (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    balance DECIMAL(15, 2) NOT NULL DEFAULT 1234567.00,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица транзакций
CREATE TABLE transactions (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    title VARCHAR(255) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    is_positive BOOLEAN NOT NULL,
    icon_name VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица вкладов
CREATE TABLE deposits (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    name VARCHAR(255) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    rate DECIMAL(5, 2) NOT NULL,
    term VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Индексы
CREATE INDEX idx_balances_user_id ON balances(user_id);
CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_created_at ON transactions(created_at DESC);
CREATE INDEX idx_deposits_user_id ON deposits(user_id);

-- Вставка начального баланса для тестового пользователя (user_id = 1)
INSERT INTO balances (user_id, balance) VALUES (1, 1234567.00);

-- Вставка тестовых транзакций
INSERT INTO transactions (user_id, title, amount, is_positive, icon_name) VALUES
(1, 'Пополнение', 5000.00, true, 'ArrowDownward'),
(1, 'Перевод', 2500.00, false, 'ArrowUpward'),
(1, 'Покупка', 1200.00, false, 'ShoppingCart'),
(1, 'Зарплата', 50000.00, true, 'AccountBalance');

-- Вставка тестовых вкладов
INSERT INTO deposits (user_id, name, amount, rate, term) VALUES
(1, 'Накопительный вклад', 500000.00, 5.5, 'До 31.12.2024'),
(1, 'Срочный вклад', 300000.00, 7.0, 'До 30.06.2025'),
(1, 'Пенсионный вклад', 150000.00, 6.0, 'До 31.12.2024'),
(1, 'Сберегательный вклад', 200000.00, 4.5, 'До 31.03.2025');
```

---

## 🔧 Реализация User Service

### 1. Структура проекта

```
user-service/
├── src/
│   ├── main/
│   │   ├── kotlin/
│   │   │   └── com/group/project/bank/userservice/
│   │   │       ├── UserServiceApplication.kt
│   │   │       ├── config/
│   │   │       │   ├── SecurityConfig.kt
│   │   │       │   ├── JwtConfig.kt
│   │   │       │   └── RedisConfig.kt
│   │   │       ├── controller/
│   │   │       │   ├── AuthController.kt
│   │   │       │   └── UserController.kt
│   │   │       ├── service/
│   │   │       │   ├── AuthService.kt
│   │   │       │   ├── UserService.kt
│   │   │       │   └── JwtService.kt
│   │   │       ├── repository/
│   │   │       │   └── UserRepository.kt
│   │   │       ├── entity/
│   │   │       │   └── User.kt
│   │   │       ├── dto/
│   │   │       │   ├── LoginRequest.kt
│   │   │       │   ├── LoginResponse.kt
│   │   │       │   ├── UserProfileResponse.kt
│   │   │       │   └── UpdateProfileRequest.kt
│   │   │       └── exception/
│   │   │           └── GlobalExceptionHandler.kt
│   │   └── resources/
│   │       ├── application.properties
│   │       └── db/migration/
│   └── test/
└── build.gradle.kts
```

### 2. build.gradle.kts

```kotlin
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
    id("org.springframework.boot") version "3.2.0"
    id("io.spring.dependency-management") version "1.1.4"
    kotlin("jvm") version "1.9.20"
    kotlin("plugin.spring") version "1.9.20"
    kotlin("plugin.jpa") version "1.9.20"
}

group = "com.group.project.bank"
version = "0.0.1-SNAPSHOT"

java {
    sourceCompatibility = JavaVersion.VERSION_17
}

repositories {
    mavenCentral()
}

dependencies {
    // Spring Boot
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.boot:spring-boot-starter-data-jpa")
    implementation("org.springframework.boot:spring-boot-starter-security")
    implementation("org.springframework.boot:spring-boot-starter-data-redis")
    implementation("org.springframework.boot:spring-boot-starter-validation")
    
    // Kotlin
    implementation("org.jetbrains.kotlin:kotlin-reflect")
    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8")
    
    // Database
    implementation("org.postgresql:postgresql")
    
    // JWT
    implementation("io.jsonwebtoken:jjwt-api:0.12.3")
    implementation("io.jsonwebtoken:jjwt-impl:0.12.3")
    implementation("io.jsonwebtoken:jjwt-jackson:0.12.3")
    
    // Password hashing
    implementation("org.springframework.security:spring-security-crypto")
    
    // Testing
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.springframework.security:spring-security-test")
}

tasks.withType<KotlinCompile> {
    kotlinOptions {
        freeCompilerArgs += "-Xjsr305=strict"
        jvmTarget = "17"
    }
}

tasks.withType<Test> {
    useJUnitPlatform()
}
```

### 3. application.properties

```properties
# Server
server.port=8081

# Database
spring.datasource.url=jdbc:postgresql://localhost:5432/user_service_db
spring.datasource.username=user_service_user
spring.datasource.password=user_service_password
spring.datasource.driver-class-name=org.postgresql.Driver

# JPA
spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect
spring.jpa.properties.hibernate.format_sql=true

# Redis
spring.data.redis.host=localhost
spring.data.redis.port=6379
spring.data.redis.timeout=2000ms

# JWT
jwt.secret=your-secret-key-change-this-in-production-min-256-bits
jwt.expiration=3600000

# Logging
logging.level.com.group.project.bank.userservice=DEBUG
```

### 4. Entity: User.kt

```kotlin
package com.group.project.bank.userservice.entity

import jakarta.persistence.*
import java.time.LocalDateTime

@Entity
@Table(name = "users")
data class User(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,
    
    @Column(unique = true, nullable = false, length = 20)
    val phone: String,
    
    @Column(nullable = false)
    val passwordHash: String,
    
    @Column(nullable = false)
    var name: String,
    
    @Column(nullable = false)
    var email: String,
    
    @Column(name = "created_at")
    val createdAt: LocalDateTime = LocalDateTime.now(),
    
    @Column(name = "updated_at")
    var updatedAt: LocalDateTime = LocalDateTime.now()
)
```

### 5. Repository: UserRepository.kt

```kotlin
package com.group.project.bank.userservice.repository

import com.group.project.bank.userservice.entity.User
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository
import java.util.Optional

@Repository
interface UserRepository : JpaRepository<User, Long> {
    fun findByPhone(phone: String): Optional<User>
    fun existsByPhone(phone: String): Boolean
}
```

### 6. DTOs

**LoginRequest.kt:**
```kotlin
package com.group.project.bank.userservice.dto

import jakarta.validation.constraints.NotBlank

data class LoginRequest(
    @field:NotBlank(message = "Phone is required")
    val phone: String,
    
    @field:NotBlank(message = "Password is required")
    val password: String
)
```

**LoginResponse.kt:**
```kotlin
package com.group.project.bank.userservice.dto

data class LoginResponse(
    val token: String,
    val userId: Long,
    val expiresIn: Long
)
```

**UserProfileResponse.kt:**
```kotlin
package com.group.project.bank.userservice.dto

data class UserProfileResponse(
    val userId: Long,
    val name: String,
    val phone: String,
    val email: String
)
```

**UpdateProfileRequest.kt:**
```kotlin
package com.group.project.bank.userservice.dto

import jakarta.validation.constraints.Email
import jakarta.validation.constraints.NotBlank

data class UpdateProfileRequest(
    @field:NotBlank(message = "Name is required")
    val name: String,
    
    @field:Email(message = "Email must be valid")
    @field:NotBlank(message = "Email is required")
    val email: String
)
```

### 7. JwtService.kt

```kotlin
package com.group.project.bank.userservice.service

import io.jsonwebtoken.Jwts
import io.jsonwebtoken.security.Keys
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service
import java.util.*
import javax.crypto.SecretKey

@Service
class JwtService(
    @Value("\${jwt.secret}")
    private val secret: String,
    
    @Value("\${jwt.expiration}")
    private val expiration: Long
) {
    private val key: SecretKey = Keys.hmacShaKeyFor(secret.toByteArray())
    
    fun generateToken(userId: Long): String {
        val now = Date()
        val expiryDate = Date(now.time + expiration)
        
        return Jwts.builder()
            .subject(userId.toString())
            .issuedAt(now)
            .expiration(expiryDate)
            .signWith(key)
            .compact()
    }
    
    fun getUserIdFromToken(token: String): Long? {
        return try {
            val claims = Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .payload
            
            claims.subject.toLong()
        } catch (e: Exception) {
            null
        }
    }
    
    fun validateToken(token: String): Boolean {
        return try {
            Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
            true
        } catch (e: Exception) {
            false
        }
    }
}
```

### 8. AuthService.kt

```kotlin
package com.group.project.bank.userservice.service

import com.group.project.bank.userservice.dto.LoginRequest
import com.group.project.bank.userservice.dto.LoginResponse
import com.group.project.bank.userservice.repository.UserRepository
import org.springframework.security.crypto.password.PasswordEncoder
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
class AuthService(
    private val userRepository: UserRepository,
    private val passwordEncoder: PasswordEncoder,
    private val jwtService: JwtService
) {
    
    @Transactional
    fun login(request: LoginRequest): LoginResponse {
        val user = userRepository.findByPhone(request.phone)
            .orElseThrow { IllegalArgumentException("Invalid phone or password") }
        
        if (!passwordEncoder.matches(request.password, user.passwordHash)) {
            throw IllegalArgumentException("Invalid phone or password")
        }
        
        val token = jwtService.generateToken(user.id)
        
        return LoginResponse(
            token = token,
            userId = user.id,
            expiresIn = 3600 // 1 hour in seconds
        )
    }
    
    fun validateToken(token: String): Boolean {
        return jwtService.validateToken(token)
    }
    
    fun getUserIdFromToken(token: String): Long? {
        return jwtService.getUserIdFromToken(token)
    }
}
```

### 9. UserService.kt

```kotlin
package com.group.project.bank.userservice.service

import com.group.project.bank.userservice.dto.UpdateProfileRequest
import com.group.project.bank.userservice.dto.UserProfileResponse
import com.group.project.bank.userservice.entity.User
import com.group.project.bank.userservice.repository.UserRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
class UserService(
    private val userRepository: UserRepository
) {
    
    fun getProfile(userId: Long): UserProfileResponse {
        val user = userRepository.findById(userId)
            .orElseThrow { IllegalArgumentException("User not found") }
        
        return UserProfileResponse(
            userId = user.id,
            name = user.name,
            phone = user.phone,
            email = user.email
        )
    }
    
    @Transactional
    fun updateProfile(userId: Long, request: UpdateProfileRequest): UserProfileResponse {
        val user = userRepository.findById(userId)
            .orElseThrow { IllegalArgumentException("User not found") }
        
        user.name = request.name
        user.email = request.email
        user.updatedAt = java.time.LocalDateTime.now()
        
        val updatedUser = userRepository.save(user)
        
        return UserProfileResponse(
            userId = updatedUser.id,
            name = updatedUser.name,
            phone = updatedUser.phone,
            email = updatedUser.email
        )
    }
    
    fun getUserById(userId: Long): User? {
        return userRepository.findById(userId).orElse(null)
    }
}
```

### 10. Security Config: JwtAuthenticationFilter.kt

```kotlin
package com.group.project.bank.userservice.config

import com.group.project.bank.userservice.service.AuthService
import jakarta.servlet.FilterChain
import jakarta.servlet.http.HttpServletRequest
import jakarta.servlet.http.HttpServletResponse
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource
import org.springframework.stereotype.Component
import org.springframework.web.filter.OncePerRequestFilter

@Component
class JwtAuthenticationFilter(
    private val authService: AuthService
) : OncePerRequestFilter() {
    
    override fun doFilterInternal(
        request: HttpServletRequest,
        response: HttpServletResponse,
        filterChain: FilterChain
    ) {
        val authHeader = request.getHeader("Authorization")
        
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            val token = authHeader.substring(7)
            
            if (authService.validateToken(token)) {
                val userId = authService.getUserIdFromToken(token)
                if (userId != null) {
                    val authentication = UsernamePasswordAuthenticationToken(
                        userId,
                        null,
                        emptyList()
                    )
                    authentication.details = WebAuthenticationDetailsSource().buildDetails(request)
                    SecurityContextHolder.getContext().authentication = authentication
                }
            }
        }
        
        filterChain.doFilter(request, response)
    }
}
```

### 11. SecurityConfig.kt

```kotlin
package com.group.project.bank.userservice.config

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.http.SessionCreationPolicy
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.security.crypto.password.PasswordEncoder
import org.springframework.security.web.SecurityFilterChain
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter

@Configuration
@EnableWebSecurity
class SecurityConfig(
    private val jwtAuthenticationFilter: JwtAuthenticationFilter
) {
    
    @Bean
    fun passwordEncoder(): PasswordEncoder {
        return BCryptPasswordEncoder()
    }
    
    @Bean
    fun securityFilterChain(http: HttpSecurity): SecurityFilterChain {
        http
            .csrf { it.disable() }
            .sessionManagement { it.sessionCreationPolicy(SessionCreationPolicy.STATELESS) }
            .authorizeHttpRequests { auth ->
                auth
                    .requestMatchers("/api/v1/auth/**").permitAll()
                    .requestMatchers("/actuator/health").permitAll()
                    .anyRequest().authenticated()
            }
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter::class.java)
        
        return http.build()
    }
}
```

### 12. Controllers

**AuthController.kt:**
```kotlin
package com.group.project.bank.userservice.controller

import com.group.project.bank.userservice.dto.LoginRequest
import com.group.project.bank.userservice.dto.LoginResponse
import com.group.project.bank.userservice.service.AuthService
import jakarta.validation.Valid
import org.springframework.http.ResponseEntity
import org.springframework.security.core.Authentication
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/v1/auth")
class AuthController(
    private val authService: AuthService
) {
    
    @PostMapping("/login")
    fun login(@Valid @RequestBody request: LoginRequest): ResponseEntity<LoginResponse> {
        val response = authService.login(request)
        return ResponseEntity.ok(response)
    }
    
    @PostMapping("/logout")
    fun logout(): ResponseEntity<Map<String, String>> {
        // В реальном приложении можно добавить токен в blacklist
        return ResponseEntity.ok(mapOf("success" to "true"))
    }
    
    @GetMapping("/status")
    fun getStatus(authentication: Authentication): ResponseEntity<Map<String, Any>> {
        val userId = authentication.name.toLong()
        return ResponseEntity.ok(mapOf(
            "isLoggedIn" to true,
            "userId" to userId
        ))
    }
}
```

**UserController.kt:**
```kotlin
package com.group.project.bank.userservice.controller

import com.group.project.bank.userservice.dto.UpdateProfileRequest
import com.group.project.bank.userservice.dto.UserProfileResponse
import com.group.project.bank.userservice.service.UserService
import jakarta.validation.Valid
import org.springframework.http.ResponseEntity
import org.springframework.security.core.Authentication
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/v1/users")
class UserController(
    private val userService: UserService
) {
    
    @GetMapping("/profile")
    fun getProfile(authentication: Authentication): ResponseEntity<UserProfileResponse> {
        val userId = authentication.name.toLong()
        val profile = userService.getProfile(userId)
        return ResponseEntity.ok(profile)
    }
    
    @PutMapping("/profile")
    fun updateProfile(
        authentication: Authentication,
        @Valid @RequestBody request: UpdateProfileRequest
    ): ResponseEntity<Map<String, Any>> {
        val userId = authentication.name.toLong()
        val updatedProfile = userService.updateProfile(userId, request)
        return ResponseEntity.ok(mapOf(
            "success" to true,
            "user" to updatedProfile
        ))
    }
    
    @GetMapping("/{userId}")
    fun getUserById(@PathVariable userId: Long): ResponseEntity<UserProfileResponse> {
        val profile = userService.getProfile(userId)
        return ResponseEntity.ok(profile)
    }
}
```

### 13. GlobalExceptionHandler.kt

```kotlin
package com.group.project.bank.userservice.exception

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.RestControllerAdvice

@RestControllerAdvice
class GlobalExceptionHandler {
    
    @ExceptionHandler(IllegalArgumentException::class)
    fun handleIllegalArgumentException(e: IllegalArgumentException): ResponseEntity<Map<String, String>> {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
            .body(mapOf("error" to e.message ?: "Bad request"))
    }
    
    @ExceptionHandler(Exception::class)
    fun handleException(e: Exception): ResponseEntity<Map<String, String>> {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(mapOf("error" to "Internal server error"))
    }
}
```

### 14. UserServiceApplication.kt

```kotlin
package com.group.project.bank.userservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class UserServiceApplication

fun main(args: Array<String>) {
    runApplication<UserServiceApplication>(*args)
}
```

---

## 💰 Реализация Banking Service

### 1. Структура проекта

```
banking-service/
├── src/
│   ├── main/
│   │   ├── kotlin/
│   │   │   └── com/group/project/bank/bankingservice/
│   │   │       ├── BankingServiceApplication.kt
│   │   │       ├── config/
│   │   │       │   └── SecurityConfig.kt
│   │   │       ├── controller/
│   │   │       │   ├── BalanceController.kt
│   │   │       │   ├── TransactionController.kt
│   │   │       │   └── DepositController.kt
│   │   │       ├── service/
│   │   │       │   ├── BalanceService.kt
│   │   │       │   ├── TransactionService.kt
│   │   │       │   └── DepositService.kt
│   │   │       ├── repository/
│   │   │       │   ├── BalanceRepository.kt
│   │   │       │   ├── TransactionRepository.kt
│   │   │       │   └── DepositRepository.kt
│   │   │       ├── entity/
│   │   │       │   ├── Balance.kt
│   │   │       │   ├── Transaction.kt
│   │   │       │   └── Deposit.kt
│   │   │       ├── dto/
│   │   │       │   ├── BalanceResponse.kt
│   │   │       │   ├── TransactionResponse.kt
│   │   │       │   ├── DepositResponse.kt
│   │   │       │   └── TransferRequest.kt
│   │   │       └── exception/
│   │   │           └── GlobalExceptionHandler.kt
│   │   └── resources/
│   │       ├── application.properties
│   │       └── db/migration/
│   └── test/
└── build.gradle.kts
```

### 2. build.gradle.kts (аналогично User Service, но без Redis)

### 3. application.properties

```properties
# Server
server.port=8082

# Database
spring.datasource.url=jdbc:postgresql://localhost:5433/banking_service_db
spring.datasource.username=banking_service_user
spring.datasource.password=banking_service_password
spring.datasource.driver-class-name=org.postgresql.Driver

# JPA
spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect

# JWT (для валидации токенов от User Service)
jwt.secret=your-secret-key-change-this-in-production-min-256-bits

# Logging
logging.level.com.group.project.bank.bankingservice=DEBUG
```

### 4. Entities

**Balance.kt:**
```kotlin
package com.group.project.bank.bankingservice.entity

import jakarta.persistence.*
import java.math.BigDecimal
import java.time.LocalDateTime

@Entity
@Table(name = "balances")
data class Balance(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,
    
    @Column(name = "user_id", unique = true, nullable = false)
    val userId: Long,
    
    @Column(nullable = false, precision = 15, scale = 2)
    var balance: BigDecimal = BigDecimal("1234567.00"),
    
    @Column(name = "updated_at")
    var updatedAt: LocalDateTime = LocalDateTime.now()
)
```

**Transaction.kt:**
```kotlin
package com.group.project.bank.bankingservice.entity

import jakarta.persistence.*
import java.math.BigDecimal
import java.time.LocalDateTime

@Entity
@Table(name = "transactions")
data class Transaction(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,
    
    @Column(name = "user_id", nullable = false)
    val userId: Long,
    
    @Column(nullable = false)
    val title: String,
    
    @Column(nullable = false, precision = 15, scale = 2)
    val amount: BigDecimal,
    
    @Column(name = "is_positive", nullable = false)
    val isPositive: Boolean,
    
    @Column(name = "icon_name", nullable = false, length = 50)
    val iconName: String,
    
    @Column(name = "created_at")
    val createdAt: LocalDateTime = LocalDateTime.now()
)
```

**Deposit.kt:**
```kotlin
package com.group.project.bank.bankingservice.entity

import jakarta.persistence.*
import java.math.BigDecimal
import java.time.LocalDateTime

@Entity
@Table(name = "deposits")
data class Deposit(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,
    
    @Column(name = "user_id", nullable = false)
    val userId: Long,
    
    @Column(nullable = false)
    var name: String,
    
    @Column(nullable = false, precision = 15, scale = 2)
    var amount: BigDecimal,
    
    @Column(nullable = false, precision = 5, scale = 2)
    val rate: BigDecimal,
    
    @Column(nullable = false, length = 100)
    val term: String,
    
    @Column(name = "created_at")
    val createdAt: LocalDateTime = LocalDateTime.now(),
    
    @Column(name = "updated_at")
    var updatedAt: LocalDateTime = LocalDateTime.now()
)
```

### 5. Repositories

**BalanceRepository.kt:**
```kotlin
package com.group.project.bank.bankingservice.repository

import com.group.project.bank.bankingservice.entity.Balance
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository
import java.util.Optional

@Repository
interface BalanceRepository : JpaRepository<Balance, Long> {
    fun findByUserId(userId: Long): Optional<Balance>
}
```

**TransactionRepository.kt:**
```kotlin
package com.group.project.bank.bankingservice.repository

import com.group.project.bank.bankingservice.entity.Transaction
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface TransactionRepository : JpaRepository<Transaction, Long> {
    fun findByUserIdOrderByCreatedAtDesc(userId: Long, pageable: Pageable): Page<Transaction>
}
```

**DepositRepository.kt:**
```kotlin
package com.group.project.bank.bankingservice.repository

import com.group.project.bank.bankingservice.entity.Deposit
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface DepositRepository : JpaRepository<Deposit, Long> {
    fun findByUserId(userId: Long): List<Deposit>
}
```

### 6. Services

**BalanceService.kt:**
```kotlin
package com.group.project.bank.bankingservice.service

import com.group.project.bank.bankingservice.dto.BalanceResponse
import com.group.project.bank.bankingservice.entity.Balance
import com.group.project.bank.bankingservice.repository.BalanceRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

@Service
class BalanceService(
    private val balanceRepository: BalanceRepository
) {
    
    fun getBalance(userId: Long): BalanceResponse {
        val balance = balanceRepository.findByUserId(userId)
            .orElseGet {
                // Создать баланс по умолчанию, если не существует
                val defaultBalance = Balance(userId = userId)
                balanceRepository.save(defaultBalance)
            }
        
        return BalanceResponse(
            balance = balance.balance.toDouble(),
            formatted = formatBalance(balance.balance)
        )
    }
    
    @Transactional
    fun addAmount(userId: Long, amount: Double): BalanceResponse {
        val balance = balanceRepository.findByUserId(userId)
            .orElseGet {
                Balance(userId = userId)
            }
        
        balance.balance = balance.balance.add(BigDecimal.valueOf(amount))
        balance.updatedAt = java.time.LocalDateTime.now()
        
        val saved = balanceRepository.save(balance)
        
        return BalanceResponse(
            balance = saved.balance.toDouble(),
            formatted = formatBalance(saved.balance)
        )
    }
    
    @Transactional
    fun subtractAmount(userId: Long, amount: Double): BalanceResponse {
        val balance = balanceRepository.findByUserId(userId)
            .orElseThrow { IllegalArgumentException("Balance not found") }
        
        val newBalance = balance.balance.subtract(BigDecimal.valueOf(amount))
        if (newBalance < BigDecimal.ZERO) {
            balance.balance = BigDecimal.ZERO
        } else {
            balance.balance = newBalance
        }
        
        balance.updatedAt = java.time.LocalDateTime.now()
        val saved = balanceRepository.save(balance)
        
        return BalanceResponse(
            balance = saved.balance.toDouble(),
            formatted = formatBalance(saved.balance)
        )
    }
    
    private fun formatBalance(balance: BigDecimal): String {
        val formatter = DecimalFormat("#,###", DecimalFormatSymbols(Locale.getDefault()))
        return formatter.format(balance.toDouble()).replace(",", " ") + " ₽"
    }
}
```

**TransactionService.kt:**
```kotlin
package com.group.project.bank.bankingservice.service

import com.group.project.bank.bankingservice.dto.TransactionResponse
import com.group.project.bank.bankingservice.entity.Transaction
import com.group.project.bank.bankingservice.repository.TransactionRepository
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Sort
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.*

@Service
class TransactionService(
    private val transactionRepository: TransactionRepository
) {
    
    fun getTransactions(userId: Long, limit: Int = 10, offset: Int = 0): List<TransactionResponse> {
        val pageable = PageRequest.of(offset / limit, limit, Sort.by("createdAt").descending())
        val transactions = transactionRepository.findByUserIdOrderByCreatedAtDesc(userId, pageable)
        
        return transactions.content.map { toResponse(it) }
    }
    
    @Transactional
    fun addTransaction(
        userId: Long,
        title: String,
        amount: Double,
        isPositive: Boolean,
        iconName: String
    ): TransactionResponse {
        val transaction = Transaction(
            userId = userId,
            title = title,
            amount = BigDecimal.valueOf(amount),
            isPositive = isPositive,
            iconName = iconName
        )
        
        val saved = transactionRepository.save(transaction)
        return toResponse(saved)
    }
    
    @Transactional
    fun addTransferTransaction(userId: Long, amount: Double, recipientCard: String): TransactionResponse {
        val last4Digits = recipientCard.takeLast(4)
        val title = "Перевод на карту $last4Digits"
        
        return addTransaction(userId, title, amount, false, "ArrowUpward")
    }
    
    @Transactional
    fun addDepositTransaction(userId: Long, amount: Double, depositName: String): TransactionResponse {
        val title = "Пополнение вклада: $depositName"
        return addTransaction(userId, title, amount, false, "AccountBalance")
    }
    
    @Transactional
    fun addOpenDepositTransaction(userId: Long, amount: Double, depositName: String): TransactionResponse {
        val title = "Открытие вклада: $depositName"
        return addTransaction(userId, title, amount, false, "AccountBalance")
    }
    
    private fun toResponse(transaction: Transaction): TransactionResponse {
        val dateFormat = SimpleDateFormat("d MMMM yyyy", Locale("ru", "RU"))
        val date = try {
            dateFormat.format(java.util.Date(transaction.createdAt.toEpochSecond(java.time.ZoneOffset.UTC) * 1000))
        } catch (e: Exception) {
            SimpleDateFormat("d MMMM yyyy", Locale.getDefault())
                .format(java.util.Date(transaction.createdAt.toEpochSecond(java.time.ZoneOffset.UTC) * 1000))
        }
        
        val formatter = DecimalFormat("#,###", DecimalFormatSymbols(Locale.getDefault()))
        val formattedAmount = formatter.format(transaction.amount.toDouble()).replace(",", " ") + " ₽"
        val amountWithSign = if (transaction.isPositive) "+$formattedAmount" else "-$formattedAmount"
        
        return TransactionResponse(
            id = transaction.id,
            title = transaction.title,
            date = date,
            amount = amountWithSign,
            isPositive = transaction.isPositive,
            iconName = transaction.iconName
        )
    }
}
```

**DepositService.kt:**
```kotlin
package com.group.project.bank.bankingservice.service

import com.group.project.bank.bankingservice.dto.DepositResponse
import com.group.project.bank.bankingservice.entity.Deposit
import com.group.project.bank.bankingservice.repository.DepositRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal

@Service
class DepositService(
    private val depositRepository: DepositRepository
) {
    
    fun getDeposits(userId: Long): List<DepositResponse> {
        val deposits = depositRepository.findByUserId(userId)
        return deposits.map { toResponse(it) }
    }
    
    @Transactional
    fun createDeposit(
        userId: Long,
        name: String,
        amount: Double,
        rate: Double,
        term: String
    ): DepositResponse {
        val deposit = Deposit(
            userId = userId,
            name = name,
            amount = BigDecimal.valueOf(amount),
            rate = BigDecimal.valueOf(rate),
            term = term
        )
        
        val saved = depositRepository.save(deposit)
        return toResponse(saved)
    }
    
    @Transactional
    fun topUpDeposit(depositId: Long, amount: Double): DepositResponse {
        val deposit = depositRepository.findById(depositId)
            .orElseThrow { IllegalArgumentException("Deposit not found") }
        
        deposit.amount = deposit.amount.add(BigDecimal.valueOf(amount))
        deposit.updatedAt = java.time.LocalDateTime.now()
        
        val saved = depositRepository.save(deposit)
        return toResponse(saved)
    }
    
    private fun toResponse(deposit: Deposit): DepositResponse {
        return DepositResponse(
            id = deposit.id,
            name = deposit.name,
            amount = deposit.amount.toInt().toString(),
            rate = "${deposit.rate}%",
            term = deposit.term
        )
    }
}
```

### 7. DTOs

**BalanceResponse.kt:**
```kotlin
package com.group.project.bank.bankingservice.dto

data class BalanceResponse(
    val balance: Double,
    val formatted: String
)
```

**TransactionResponse.kt:**
```kotlin
package com.group.project.bank.bankingservice.dto

data class TransactionResponse(
    val id: Long,
    val title: String,
    val date: String,
    val amount: String,
    val isPositive: Boolean,
    val iconName: String
)
```

**DepositResponse.kt:**
```kotlin
package com.group.project.bank.bankingservice.dto

data class DepositResponse(
    val id: Long,
    val name: String,
    val amount: String,
    val rate: String,
    val term: String
)
```

**TransferRequest.kt:**
```kotlin
package com.group.project.bank.bankingservice.dto

import jakarta.validation.constraints.Min
import jakarta.validation.constraints.NotBlank
import jakarta.validation.constraints.NotNull

data class TransferRequest(
    @field:NotNull(message = "Amount is required")
    @field:Min(value = 1, message = "Amount must be greater than 0")
    val amount: Double,
    
    @field:NotBlank(message = "Recipient card is required")
    val recipientCard: String
)
```

### 8. Controllers

**BalanceController.kt:**
```kotlin
package com.group.project.bank.bankingservice.controller

import com.group.project.bank.bankingservice.dto.BalanceResponse
import com.group.project.bank.bankingservice.service.BalanceService
import org.springframework.http.ResponseEntity
import org.springframework.security.core.Authentication
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/v1/balance")
class BalanceController(
    private val balanceService: BalanceService
) {
    
    @GetMapping
    fun getBalance(authentication: Authentication): ResponseEntity<BalanceResponse> {
        val userId = authentication.name.toLong()
        val balance = balanceService.getBalance(userId)
        return ResponseEntity.ok(balance)
    }
    
    @PostMapping("/add")
    fun addAmount(
        authentication: Authentication,
        @RequestBody request: Map<String, Double>
    ): ResponseEntity<Map<String, Any>> {
        val userId = authentication.name.toLong()
        val amount = request["amount"] ?: throw IllegalArgumentException("Amount is required")
        val balance = balanceService.addAmount(userId, amount)
        return ResponseEntity.ok(mapOf(
            "success" to true,
            "newBalance" to balance.balance
        ))
    }
    
    @PostMapping("/subtract")
    fun subtractAmount(
        authentication: Authentication,
        @RequestBody request: Map<String, Double>
    ): ResponseEntity<Map<String, Any>> {
        val userId = authentication.name.toLong()
        val amount = request["amount"] ?: throw IllegalArgumentException("Amount is required")
        val balance = balanceService.subtractAmount(userId, amount)
        return ResponseEntity.ok(mapOf(
            "success" to true,
            "newBalance" to balance.balance
        ))
    }
}
```

**TransactionController.kt:**
```kotlin
package com.group.project.bank.bankingservice.controller

import com.group.project.bank.bankingservice.dto.TransferRequest
import com.group.project.bank.bankingservice.dto.TransactionResponse
import com.group.project.bank.bankingservice.service.BalanceService
import com.group.project.bank.bankingservice.service.TransactionService
import jakarta.validation.Valid
import org.springframework.http.ResponseEntity
import org.springframework.security.core.Authentication
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/v1/transactions")
class TransactionController(
    private val transactionService: TransactionService,
    private val balanceService: BalanceService
) {
    
    @GetMapping
    fun getTransactions(
        authentication: Authentication,
        @RequestParam(defaultValue = "10") limit: Int,
        @RequestParam(defaultValue = "0") offset: Int
    ): ResponseEntity<Map<String, Any>> {
        val userId = authentication.name.toLong()
        val transactions = transactionService.getTransactions(userId, limit, offset)
        return ResponseEntity.ok(mapOf(
            "transactions" to transactions,
            "total" to transactions.size
        ))
    }
    
    @PostMapping("/transfer")
    fun transfer(
        authentication: Authentication,
        @Valid @RequestBody request: TransferRequest
    ): ResponseEntity<Map<String, Any>> {
        val userId = authentication.name.toLong()
        
        // Списать с баланса
        val balance = balanceService.subtractAmount(userId, request.amount)
        
        // Создать транзакцию
        val transaction = transactionService.addTransferTransaction(
            userId,
            request.amount,
            request.recipientCard
        )
        
        return ResponseEntity.ok(mapOf(
            "success" to true,
            "transactionId" to transaction.id,
            "newBalance" to balance.balance
        ))
    }
    
    @PostMapping("/deposit")
    fun depositTransaction(
        authentication: Authentication,
        @RequestBody request: Map<String, Any>
    ): ResponseEntity<Map<String, Any>> {
        val userId = authentication.name.toLong()
        val amount = (request["amount"] as? Number)?.toDouble()
            ?: throw IllegalArgumentException("Amount is required")
        val depositName = request["depositName"] as? String
            ?: throw IllegalArgumentException("Deposit name is required")
        
        val transaction = transactionService.addDepositTransaction(userId, amount, depositName)
        
        return ResponseEntity.ok(mapOf(
            "success" to true,
            "transactionId" to transaction.id
        ))
    }
}
```

**DepositController.kt:**
```kotlin
package com.group.project.bank.bankingservice.controller

import com.group.project.bank.bankingservice.dto.DepositResponse
import com.group.project.bank.bankingservice.service.DepositService
import org.springframework.http.ResponseEntity
import org.springframework.security.core.Authentication
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/v1/deposits")
class DepositController(
    private val depositService: DepositService
) {
    
    @GetMapping
    fun getDeposits(authentication: Authentication): ResponseEntity<Map<String, List<DepositResponse>>> {
        val userId = authentication.name.toLong()
        val deposits = depositService.getDeposits(userId)
        return ResponseEntity.ok(mapOf("deposits" to deposits))
    }
    
    @PostMapping
    fun createDeposit(
        authentication: Authentication,
        @RequestBody request: Map<String, Any>
    ): ResponseEntity<Map<String, Any>> {
        val userId = authentication.name.toLong()
        val name = request["name"] as? String ?: throw IllegalArgumentException("Name is required")
        val amount = (request["amount"] as? Number)?.toDouble()
            ?: throw IllegalArgumentException("Amount is required")
        val rate = (request["rate"] as? Number)?.toDouble()
            ?: throw IllegalArgumentException("Rate is required")
        val term = request["term"] as? String ?: throw IllegalArgumentException("Term is required")
        
        val deposit = depositService.createDeposit(userId, name, amount, rate, term)
        
        return ResponseEntity.ok(mapOf(
            "success" to true,
            "depositId" to deposit.id,
            "deposit" to deposit
        ))
    }
    
    @PutMapping("/{depositId}/topup")
    fun topUpDeposit(
        authentication: Authentication,
        @PathVariable depositId: Long,
        @RequestBody request: Map<String, Double>
    ): ResponseEntity<Map<String, Any>> {
        val amount = request["amount"] ?: throw IllegalArgumentException("Amount is required")
        val deposit = depositService.topUpDeposit(depositId, amount)
        
        return ResponseEntity.ok(mapOf(
            "success" to true,
            "newAmount" to deposit.amount.toDouble()
        ))
    }
}
```

### 9. Security Config (аналогично User Service, но для валидации JWT)

---

## 🧪 Тестирование сервисов

### 1. Запуск сервисов

**User Service:**
```bash
cd user-service
./gradlew bootRun
# Или в IntelliJ: Run → UserServiceApplication
```

**Banking Service:**
```bash
cd banking-service
./gradlew bootRun
# Или в IntelliJ: Run → BankingServiceApplication
```

### 2. Тестирование в Postman

**1. Login (User Service):**
```
POST http://localhost:8081/api/v1/auth/login
Content-Type: application/json

{
  "phone": "+79991234567",
  "password": "password123"
}
```

**2. Get Profile (User Service):**
```
GET http://localhost:8081/api/v1/users/profile
Authorization: Bearer {token_from_login}
```

**3. Get Balance (Banking Service):**
```
GET http://localhost:8082/api/v1/balance
Authorization: Bearer {token_from_login}
```

**4. Transfer (Banking Service):**
```
POST http://localhost:8082/api/v1/transactions/transfer
Authorization: Bearer {token_from_login}
Content-Type: application/json

{
  "amount": 1000.0,
  "recipientCard": "1234 5678 9012 3456"
}
```

---

## 📱 Интеграция с Android приложением

### 1. Добавить зависимости в build.gradle.kts (app)

```kotlin
dependencies {
    // Retrofit для HTTP запросов
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    
    // Gson для JSON
    implementation("com.google.code.gson:gson:2.10.1")
}
```

### 2. Создать API клиенты

**ApiService.kt:**
```kotlin
package com.group.project.bank.university.api

import retrofit2.http.*

interface UserApiService {
    @POST("api/v1/auth/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse
    
    @GET("api/v1/users/profile")
    suspend fun getProfile(@Header("Authorization") token: String): UserProfileResponse
    
    @PUT("api/v1/users/profile")
    suspend fun updateProfile(
        @Header("Authorization") token: String,
        @Body request: UpdateProfileRequest
    ): UpdateProfileResponse
}

interface BankingApiService {
    @GET("api/v1/balance")
    suspend fun getBalance(@Header("Authorization") token: String): BalanceResponse
    
    @POST("api/v1/balance/add")
    suspend fun addBalance(
        @Header("Authorization") token: String,
        @Body request: Map<String, Double>
    ): BalanceUpdateResponse
    
    @GET("api/v1/transactions")
    suspend fun getTransactions(
        @Header("Authorization") token: String,
        @Query("limit") limit: Int,
        @Query("offset") offset: Int
    ): TransactionsResponse
    
    @POST("api/v1/transactions/transfer")
    suspend fun transfer(
        @Header("Authorization") token: String,
        @Body request: TransferRequest
    ): TransferResponse
    
    @GET("api/v1/deposits")
    suspend fun getDeposits(@Header("Authorization") token: String): DepositsResponse
}
```

### 3. Retrofit клиент

**ApiClient.kt:**
```kotlin
package com.group.project.bank.university.api

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {
    private const val USER_SERVICE_BASE_URL = "http://10.0.2.2:8081/" // Для эмулятора
    private const val BANKING_SERVICE_BASE_URL = "http://10.0.2.2:8082/"
    
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }
    
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    
    val userApiService: UserApiService = Retrofit.Builder()
        .baseUrl(USER_SERVICE_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(UserApiService::class.java)
    
    val bankingApiService: BankingApiService = Retrofit.Builder()
        .baseUrl(BANKING_SERVICE_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(BankingApiService::class.java)
}
```

---

## ✅ Чеклист реализации

- [ ] Установлен JDK 17+
- [ ] Установлен IntelliJ IDEA
- [ ] Установлен PostgreSQL
- [ ] Установлен Redis
- [ ] Созданы базы данных
- [ ] Создан User Service проект
- [ ] Создан Banking Service проект
- [ ] Настроены application.properties
- [ ] Реализованы все entities
- [ ] Реализованы все repositories
- [ ] Реализованы все services
- [ ] Реализованы все controllers
- [ ] Настроен JWT
- [ ] Настроен Security
- [ ] Протестированы API в Postman
- [ ] Интегрировано с Android приложением

---

## 🚀 Следующие шаги

1. Запустить оба сервиса
2. Протестировать все endpoints в Postman
3. Обновить Android приложение для работы с API
4. Добавить обработку ошибок
5. Добавить логирование
6. Настроить мониторинг

---

## 📝 Примечания

- Для Android эмулятора использовать `10.0.2.2` вместо `localhost`
- Для реального устройства использовать IP адрес компьютера
- JWT secret должен быть минимум 256 бит (32 символа)
- В production использовать HTTPS
- Настроить CORS для Android приложения

