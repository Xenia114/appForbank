# Архитектура микросервисов для банковского приложения

## Текущая архитектура

Приложение использует 5 менеджеров данных:
- **AuthManager** - авторизация пользователей
- **UserManager** - профиль пользователя (имя, телефон, email)
- **BalanceManager** - управление балансом счета
- **TransactionManager** - история транзакций
- **DepositManager** - управление вкладами

---

## Рекомендуемые варианты разделения

### 🎯 ВАРИАНТ 1: Разделение по доменам (РЕКОМЕНДУЕТСЯ)

#### **User Service** (Сервис пользователей)
**Ответственность:** Управление пользователями и авторизация

**Включает:**
- `AuthManager` - авторизация, аутентификация, сессии
- `UserManager` - профиль пользователя (имя, телефон, email)

**API Endpoints:**
```
POST   /api/v1/auth/login          - Вход в систему
POST   /api/v1/auth/logout         - Выход из системы
GET    /api/v1/auth/status         - Проверка статуса авторизации
GET    /api/v1/users/profile       - Получить профиль пользователя
PUT    /api/v1/users/profile       - Обновить профиль пользователя
GET    /api/v1/users/{userId}       - Получить данные пользователя по ID
```

**Технологии:**
- Spring Boot / Ktor (Kotlin)
- JWT для токенов авторизации
- PostgreSQL для хранения пользователей
- Redis для сессий

---

#### **Banking Service** (Банковский сервис)
**Ответственность:** Все финансовые операции

**Включает:**
- `BalanceManager` - управление балансом
- `TransactionManager` - история транзакций
- `DepositManager` - управление вкладами

**API Endpoints:**
```
GET    /api/v1/balance             - Получить баланс пользователя
POST   /api/v1/balance/add         - Пополнить баланс
POST   /api/v1/balance/subtract    - Списать с баланса
GET    /api/v1/transactions         - Получить историю транзакций
POST   /api/v1/transactions/transfer - Создать транзакцию перевода
POST   /api/v1/transactions/deposit - Создать транзакцию вклада
GET    /api/v1/deposits             - Получить список вкладов
POST   /api/v1/deposits             - Создать новый вклад
PUT    /api/v1/deposits/{id}/topup  - Пополнить вклад
```

**Технологии:**
- Spring Boot / Ktor (Kotlin)
- PostgreSQL для финансовых данных
- Kafka/RabbitMQ для асинхронных операций
- Транзакции для финансовой целостности

**Преимущества:**
- ✅ Логичное разделение по доменам
- ✅ User Service можно масштабировать отдельно
- ✅ Banking Service изолирован для финансовых операций
- ✅ Простота реализации (2 сервиса)

---

### 🔄 ВАРИАНТ 2: Разделение по ответственности

#### **Auth Service** (Сервис авторизации)
**Ответственность:** Только авторизация и аутентификация

**Включает:**
- `AuthManager` - авторизация, токены, сессии

**API Endpoints:**
```
POST   /api/v1/auth/login          - Вход в систему
POST   /api/v1/auth/logout         - Выход из системы
POST   /api/v1/auth/refresh         - Обновить токен
GET    /api/v1/auth/validate       - Валидация токена
```

---

#### **Banking Service** (Банковский сервис)
**Ответственность:** Все остальное

**Включает:**
- `UserManager` - профиль пользователя
- `BalanceManager` - баланс
- `TransactionManager` - транзакции
- `DepositManager` - вклады

**API Endpoints:**
```
# Профиль
GET    /api/v1/users/profile       - Получить профиль
PUT    /api/v1/users/profile        - Обновить профиль

# Баланс
GET    /api/v1/balance              - Получить баланс
POST   /api/v1/balance/add          - Пополнить
POST   /api/v1/balance/subtract     - Списать

# Транзакции
GET    /api/v1/transactions         - История
POST   /api/v1/transactions/transfer - Перевод

# Вклады
GET    /api/v1/deposits             - Список вкладов
POST   /api/v1/deposits             - Создать вклад
PUT    /api/v1/deposits/{id}/topup  - Пополнить
```

**Преимущества:**
- ✅ Четкое разделение авторизации и бизнес-логики
- ✅ Auth Service можно использовать для других приложений
- ⚠️ Banking Service получается большим (но все еще управляемым)

---

### 🏗️ ВАРИАНТ 3: Расширенное разделение (для будущего масштабирования)

#### **User Service**
- `AuthManager` + `UserManager`

#### **Account Service**
- `BalanceManager` - управление счетами и балансом

#### **Transaction Service**
- `TransactionManager` - история и операции

#### **Deposit Service**
- `DepositManager` - управление вкладами

**Преимущества:**
- ✅ Максимальная изоляция сервисов
- ✅ Независимое масштабирование каждого сервиса
- ⚠️ Сложнее в реализации (4 сервиса)
- ⚠️ Больше межсервисного взаимодействия

---

## 🎯 РЕКОМЕНДАЦИЯ: Вариант 1

### Почему Вариант 1 лучше всего:

1. **Логичное разделение:**
   - User Service отвечает за пользователей
   - Banking Service отвечает за финансы

2. **Независимость:**
   - Можно обновлять профиль без влияния на финансовые операции
   - Финансовые операции изолированы

3. **Масштабируемость:**
   - User Service можно масштабировать для большого количества пользователей
   - Banking Service можно оптимизировать для финансовых операций

4. **Безопасность:**
   - Финансовые данные изолированы в отдельном сервисе
   - Авторизация отделена от бизнес-логики

5. **Простота:**
   - Минимум 2 сервиса (требование выполнено)
   - Легко реализовать и поддерживать

---

## Архитектура взаимодействия

```
  ┌─────────────────┐
  │  Android App    │
  │  (Kotlin)       │
  └────────┬────────┘
           │
           │ HTTP/REST
           │
     ┌─────┴─────┐
     │           │
     ▼           ▼
┌─────────┐ ┌──────────────┐
│  User   │ │   Banking    │
│ Service │ │   Service    │
└─────────┘ └──────────────┘
    │              │
    │              │
    ▼              ▼
 ┌──────────┐  ┌──────────────┐
 │PostgreSQL│  │  PostgreSQL  │
 │ (Users)  │  │  (Banking)   │
 └──────────┘  └──────────────┘
```

---

## Детальная спецификация API

### User Service API

#### 1. Авторизация
```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "phone": "+7 999 123-45-67",
  "password": "password123"
}

Response:
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": "user-123",
  "expiresIn": 3600
}
```

```http
POST /api/v1/auth/logout
Authorization: Bearer {token}

Response:
{
  "success": true
}
```

```http
GET /api/v1/auth/status
Authorization: Bearer {token}

Response:
{
  "isLoggedIn": true,
  "userId": "user-123"
}
```

#### 2. Профиль пользователя
```http
GET /api/v1/users/profile
Authorization: Bearer {token}

Response:
{
  "userId": "user-123",
  "name": "Иван Иванов",
  "phone": "+7 999 123-45-67",
  "email": "ivan.ivanov@example.com"
}
```

```http
PUT /api/v1/users/profile
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Петр Петров",
  "email": "petr.petrov@example.com"
}

Response:
{
  "success": true,
  "user": {
    "userId": "user-123",
    "name": "Петр Петров",
    "phone": "+7 999 123-45-67",
    "email": "petr.petrov@example.com"
  }
}
```

---

### Banking Service API

#### 1. Баланс
```http
GET /api/v1/balance
Authorization: Bearer {token}

Response:
{
  "balance": 1234567.0,
  "formatted": "1 234 567 ₽"
}
```

```http
POST /api/v1/balance/add
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 5000.0
}

Response:
{
  "success": true,
  "newBalance": 1239567.0
}
```

```http
POST /api/v1/balance/subtract
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 1000.0
}

Response:
{
  "success": true,
  "newBalance": 1233567.0
}
```

#### 2. Транзакции
```http
GET /api/v1/transactions
Authorization: Bearer {token}
Query params: ?limit=10&offset=0

Response:
{
  "transactions": [
    {
      "id": "txn-1",
      "title": "Пополнение",
      "date": "15 января 2024",
      "amount": "+5 000 ₽",
      "isPositive": true,
      "iconName": "ArrowDownward"
    },
    ...
  ],
  "total": 25
}
```

```http
POST /api/v1/transactions/transfer
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 5000.0,
  "recipientCard": "1234 5678 9012 3456"
}

Response:
{
  "success": true,
  "transactionId": "txn-123",
  "newBalance": 1229567.0
}
```

```http
POST /api/v1/transactions/deposit
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 10000.0,
  "depositName": "Накопительный вклад"
}

Response:
{
  "success": true,
  "transactionId": "txn-124"
}
```

#### 3. Вклады
```http
GET /api/v1/deposits
Authorization: Bearer {token}

Response:
{
  "deposits": [
    {
      "id": "dep-1",
      "name": "Накопительный вклад",
      "amount": "500000",
      "rate": "5.5%",
      "term": "До 31.12.2024"
    },
    ...
  ]
}
```

```http
POST /api/v1/deposits
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Срочный вклад",
  "amount": 100000.0,
  "rate": 7.0,
  "term": "До 30.06.2025"
}

Response:
{
  "success": true,
  "depositId": "dep-5",
  "deposit": {
    "id": "dep-5",
    "name": "Срочный вклад",
    "amount": "100000",
    "rate": "7.0%",
    "term": "До 30.06.2025"
  }
}
```

```http
PUT /api/v1/deposits/{depositId}/topup
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 50000.0
}

Response:
{
  "success": true,
  "newAmount": 150000.0
}
```

---

## Технологический стек

### User Service
- **Framework:** Spring Boot 3.x или Ktor 2.x (Kotlin)
- **Database:** PostgreSQL
- **Cache:** Redis (для сессий)
- **Security:** JWT, Spring Security
- **API:** REST API

### Banking Service
- **Framework:** Spring Boot 3.x или Ktor 2.x (Kotlin)
- **Database:** PostgreSQL (с транзакциями)
- **Message Queue:** RabbitMQ или Kafka (для асинхронных операций)
- **Security:** JWT валидация
- **API:** REST API

### Общие компоненты
- **API Gateway:** Spring Cloud Gateway или Kong
- **Service Discovery:** Consul или Eureka
- **Monitoring:** Prometheus + Grafana
- **Logging:** ELK Stack (Elasticsearch, Logstash, Kibana)

---

## Миграция с текущей архитектуры

### Этап 1: Подготовка
1. Создать структуру проектов для микросервисов
2. Настроить базы данных
3. Реализовать базовую инфраструктуру (API Gateway, Service Discovery)

### Этап 2: User Service
1. Мигрировать `AuthManager` → REST API
2. Мигрировать `UserManager` → REST API
3. Реализовать JWT авторизацию
4. Написать тесты

### Этап 3: Banking Service
1. Мигрировать `BalanceManager` → REST API
2. Мигрировать `TransactionManager` → REST API
3. Мигрировать `DepositManager` → REST API
4. Реализовать транзакции для финансовой целостности
5. Написать тесты

### Этап 4: Android App
1. Создать Retrofit/OkHttp клиенты для каждого сервиса
2. Заменить прямые вызовы менеджеров на API вызовы
3. Реализовать кэширование данных
4. Обработка ошибок и retry логика

---

## Преимущества микросервисной архитектуры

1. **Независимое развертывание:** Каждый сервис можно обновлять отдельно
2. **Масштабируемость:** Можно масштабировать только нужные сервисы
3. **Технологическая гибкость:** Можно использовать разные технологии для разных сервисов
4. **Изоляция ошибок:** Проблема в одном сервисе не влияет на другие
5. **Командная работа:** Разные команды могут работать над разными сервисами

---

## Следующие шаги

1. ✅ Выбрать вариант архитектуры (рекомендуется Вариант 1)
2. ✅ Определить технологический стек
3. ✅ Спроектировать API endpoints
4. ✅ Создать структуру проектов
5. ✅ Реализовать User Service
6. ✅ Реализовать Banking Service
7. ✅ Обновить Android приложение для работы с API

---

## Дополнительные рекомендации

### Безопасность
- Использовать HTTPS для всех API вызовов
- JWT токены с коротким временем жизни
- Refresh tokens для обновления сессий
- Rate limiting для защиты от DDoS

### Производительность
- Кэширование часто запрашиваемых данных (Redis)
- Пагинация для больших списков
- Асинхронная обработка тяжелых операций

### Мониторинг
- Логирование всех операций
- Метрики производительности
- Алерты при ошибках
- Трассировка запросов между сервисами


