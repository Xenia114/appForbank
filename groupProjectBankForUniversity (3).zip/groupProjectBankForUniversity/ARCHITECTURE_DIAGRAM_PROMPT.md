# Промпт для генерации диаграммы архитектуры микросервисов

## ПРОМПТ ДЛЯ CHATGPT (DALL-E / Midjourney / диаграммы):

```
Создай детальную архитектурную диаграмму микросервисной системы мобильного банковского приложения в стиле схемы/графика.

АРХИТЕКТУРА СИСТЕМЫ:

1. КЛИЕНТСКОЕ ПРИЛОЖЕНИЕ (Android):
   - Мобильное приложение на Kotlin/Android
   - Использует Retrofit для HTTP запросов
   - Расположено в левой части диаграммы

2. МИКРОСЕРВИСЫ (в центре диаграммы):

   A. USER SERVICE (порт 8081):
   - Отвечает за авторизацию и профиль пользователя
   - Endpoints:
     * POST /api/v1/auth/login - вход в систему
     * POST /api/v1/auth/logout - выход
     * GET /api/v1/auth/status - проверка статуса
     * GET /api/v1/users/profile - получить профиль
     * PUT /api/v1/users/profile - обновить профиль
   - Использует PostgreSQL для хранения пользователей
   - Использует Redis для сессий
   - Генерирует JWT токены

   B. BANKING SERVICE (порт 8082):
   - Отвечает за все финансовые операции
   - Endpoints:
     * GET /api/v1/balance - получить баланс
     * POST /api/v1/balance/add - пополнить баланс
     * POST /api/v1/balance/subtract - списать с баланса
     * GET /api/v1/transactions - история транзакций
     * POST /api/v1/transactions/transfer - перевод
     * POST /api/v1/transactions/deposit - транзакция вклада
     * GET /api/v1/deposits - список вкладов
     * POST /api/v1/deposits - создать вклад
     * PUT /api/v1/deposits/{id}/topup - пополнить вклад
   - Использует PostgreSQL для финансовых данных
   - Валидирует JWT токены от User Service

3. БАЗЫ ДАННЫХ (в правой части):
   - PostgreSQL User DB (user_service_db) - для User Service
   - PostgreSQL Banking DB (banking_service_db) - для Banking Service
   - Redis - для кэширования сессий

ПОТОКИ ДАННЫХ:

1. АВТОРИЗАЦИЯ:
   Android App → HTTP POST → User Service (/api/v1/auth/login)
   User Service → PostgreSQL (проверка пользователя)
   User Service → Redis (сохранение сессии)
   User Service → Android App (JWT токен)

2. РАБОТА С ПРОФИЛЕМ:
   Android App → HTTP GET → User Service (/api/v1/users/profile) [с JWT токеном]
   User Service → PostgreSQL (получение данных)
   User Service → Android App (данные профиля)

3. ФИНАНСОВЫЕ ОПЕРАЦИИ:
   Android App → HTTP GET → Banking Service (/api/v1/balance) [с JWT токеном]
   Banking Service → PostgreSQL (получение баланса)
   Banking Service → Android App (баланс)

   Android App → HTTP POST → Banking Service (/api/v1/transactions/transfer) [с JWT токеном]
   Banking Service → PostgreSQL (обновление баланса, создание транзакции)
   Banking Service → Android App (результат операции)

4. РАБОТА С ВКЛАДАМИ:
   Android App → HTTP GET → Banking Service (/api/v1/deposits) [с JWT токеном]
   Banking Service → PostgreSQL (получение вкладов)
   Banking Service → Android App (список вкладов)

   Android App → HTTP POST → Banking Service (/api/v1/deposits) [с JWT токеном]
   Banking Service → PostgreSQL (создание вклада, обновление баланса, транзакция)
   Banking Service → Android App (результат)

ТРЕБОВАНИЯ К ДИАГРАММЕ:

1. ВИЗУАЛЬНОЕ ПРЕДСТАВЛЕНИЕ:
   - Android приложение слева (зеленый цвет, иконка телефона)
   - Микросервисы в центре (два прямоугольника, синий и оранжевый)
   - Базы данных справа (серые прямоугольники)
   - Стрелки показывают направление запросов
   - Разные цвета для разных типов операций:
     * Зеленые стрелки - авторизация
     * Синие стрелки - чтение данных
     * Красные стрелки - запись/обновление данных
     * Оранжевые стрелки - финансовые операции

2. КОМПОНЕНТЫ:
   - Android App (слева, большой блок)
   - User Service (центр-слева, блок с портом 8081)
   - Banking Service (центр-справа, блок с портом 8082)
   - PostgreSQL User DB (справа-сверху)
   - PostgreSQL Banking DB (справа-снизу)
   - Redis (справа, между базами)

3. СВЯЗИ И СТРЕЛКИ:
   - Android App → User Service (HTTP запросы, JWT токены)
   - Android App → Banking Service (HTTP запросы, JWT токены)
   - User Service → PostgreSQL User DB (SQL запросы)
   - User Service → Redis (кэширование)
   - Banking Service → PostgreSQL Banking DB (SQL запросы)
   - Показать, что Banking Service валидирует JWT токены (можно пунктирной линией к User Service)

4. ПОДПИСИ:
   - Названия компонентов
   - Порты сервисов (8081, 8082)
   - Основные endpoints на стрелках
   - Типы операций (GET, POST, PUT)

5. ЦВЕТОВАЯ СХЕМА:
   - Android App: зеленый (#00A86B - цвет приложения)
   - User Service: синий (#1E88E5)
   - Banking Service: оранжевый (#FF6B35)
   - PostgreSQL: серый (#6B7280)
   - Redis: красный (#E53935)
   - Стрелки: соответствуют типу операции

6. ДОПОЛНИТЕЛЬНО:
   - Показать, что JWT токен передается в заголовке Authorization: Bearer {token}
   - Показать, что все запросы идут через HTTP/REST API
   - Показать, что данные хранятся в разных базах для изоляции

СТИЛЬ:
- Современная архитектурная диаграмма
- Четкие блоки и стрелки
- Легко читаемые подписи
- Профессиональный вид
- Можно использовать стиль AWS/Azure архитектурных диаграмм или UML

ФОРМАТ:
- Горизонтальная ориентация (Android слева, сервисы в центре, БД справа)
- Все компоненты на одном уровне для читаемости
- Стрелки с подписями показывают тип операции

Создай диаграмму, которая сразу показывает всю архитектуру, потоки данных и взаимодействие компонентов.
```

---

## АЛЬТЕРНАТИВНЫЙ ПРОМПТ (более краткий):

```
Создай архитектурную диаграмму микросервисов банковского приложения:

КОМПОНЕНТЫ:
- Android App (слева, зеленый)
- User Service :8081 (центр, синий) - авторизация, профиль
- Banking Service :8082 (центр, оранжевый) - баланс, транзакции, вклады
- PostgreSQL User DB (справа-сверху, серый)
- PostgreSQL Banking DB (справа-снизу, серый)
- Redis (справа, красный)

СВЯЗИ:
1. Android → User Service (POST /auth/login, GET /users/profile) → PostgreSQL User DB
2. Android → Banking Service (GET /balance, POST /transactions/transfer, GET /deposits) → PostgreSQL Banking DB
3. User Service → Redis (сессии)
4. Banking Service валидирует JWT от User Service

СТРЕЛКИ:
- Зеленые: авторизация
- Синие: чтение
- Красные: запись/обновление

Стиль: современная архитектурная диаграмма с четкими блоками и подписями.
```

---

## ПРОМПТ ДЛЯ Mermaid/PlantUML (текстовые диаграммы):

```
Создай Mermaid диаграмму следующей архитектуры:

```mermaid
graph LR
    A[Android App] -->|HTTP POST /auth/login| B[User Service :8081]
    A -->|HTTP GET /users/profile<br/>JWT Token| B
    A -->|HTTP GET /balance<br/>JWT Token| C[Banking Service :8082]
    A -->|HTTP POST /transactions/transfer<br/>JWT Token| C
    A -->|HTTP GET /deposits<br/>JWT Token| C
    A -->|HTTP POST /deposits<br/>JWT Token| C
    
    B -->|SQL| D[(PostgreSQL<br/>User DB)]
    B -->|Cache| E[(Redis<br/>Sessions)]
    C -->|SQL| F[(PostgreSQL<br/>Banking DB)]
    C -.->|Validate JWT| B
    
    style A fill:#00A86B,stroke:#008A5A,color:#fff
    style B fill:#1E88E5,stroke:#1565C0,color:#fff
    style C fill:#FF6B35,stroke:#E53935,color:#fff
    style D fill:#6B7280,stroke:#4B5563,color:#fff
    style E fill:#E53935,stroke:#C62828,color:#fff
    style F fill:#6B7280,stroke:#4B5563,color:#fff
```
```

---

## ПРОМПТ ДЛЯ Draw.io / Lucidchart:

```
Создай архитектурную диаграмму в Draw.io/Lucidchart:

РАСПОЛОЖЕНИЕ:
- Слева: Android App (большой прямоугольник, зеленый #00A86B)
- Центр: два сервиса вертикально
  * User Service (синий #1E88E5, порт 8081)
  * Banking Service (оранжевый #FF6B35, порт 8082)
- Справа: три базы данных вертикально
  * PostgreSQL User DB (серый)
  * Redis (красный)
  * PostgreSQL Banking DB (серый)

СТРЕЛКИ:
1. Android → User Service (POST /auth/login) - зеленая
2. Android → User Service (GET /users/profile, JWT) - синяя
3. Android → Banking Service (GET /balance, JWT) - синяя
4. Android → Banking Service (POST /transactions/transfer, JWT) - красная
5. Android → Banking Service (GET /deposits, JWT) - синяя
6. Android → Banking Service (POST /deposits, JWT) - красная
7. User Service → PostgreSQL User DB - серая
8. User Service → Redis - красная пунктирная
9. Banking Service → PostgreSQL Banking DB - серая
10. Banking Service -.-> User Service (Validate JWT) - пунктирная серая

ПОДПИСИ:
- На каждой стрелке указать метод (GET/POST) и endpoint
- Указать, что передается JWT токен
- Указать порты сервисов
```

---

## РЕКОМЕНДАЦИИ ПО ИСПОЛЬЗОВАНИЮ:

1. **Для ChatGPT с DALL-E:**
   - Используй первый подробный промпт
   - Можешь добавить: "в стиле AWS архитектурных диаграмм"

2. **Для ChatGPT с кодом диаграмм:**
   - Используй Mermaid промпт
   - Можно попросить создать PlantUML код

3. **Для ручного создания в Draw.io:**
   - Используй третий промпт как инструкцию
   - Или скопируй Mermaid код в Draw.io (поддерживает импорт)

4. **Для документации:**
   - Mermaid диаграмму можно вставить в Markdown
   - GitHub и многие платформы поддерживают Mermaid

---

## БЫСТРЫЙ ПРОМПТ (для быстрой генерации):

```
Диаграмма архитектуры: Android App → User Service (8081) → PostgreSQL + Redis | Android App → Banking Service (8082) → PostgreSQL. Показать JWT токены, HTTP запросы, потоки данных. Стиль: современная архитектурная схема с цветными блоками и стрелками.
```

