package com.group.project.bank.university.service

import android.content.Context
import android.util.Log
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.api.dto.UpdateProfileRequest
import com.group.project.bank.university.data.TokenManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ApiUserService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val userApi = ApiClient.userApiService
    
    companion object {
        private const val TAG = "ApiUserService"
    }
    
    suspend fun getUserName(): String {
        return try {
            val profile = getProfile()
            profile.name
        } catch (e: Exception) {
            Log.w(TAG, "Ошибка получения имени, используется fallback", e)
            "Иван Иванов" // Fallback
        }
    }
    
    suspend fun getUserPhone(): String {
        return try {
            val profile = getProfile()
            profile.phone
        } catch (e: Exception) {
            Log.w(TAG, "Ошибка получения телефона, используется fallback", e)
            "+7 999 123-45-67" // Fallback
        }
    }
    
    suspend fun getUserEmail(): String {
        return try {
            val profile = getProfile()
            profile.email
        } catch (e: Exception) {
            Log.w(TAG, "Ошибка получения email, используется fallback", e)
            "ivan.ivanov@example.com" // Fallback
        }
    }
    
    suspend fun getProfile() = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== ЗАПРОС ПРОФИЛЯ ПОЛЬЗОВАТЕЛЯ ===")
        Log.d(TAG, "URL: ${ApiClient.USER_SERVICE_BASE_URL}api/v1/users/profile")
        
        try {
            val token = tokenManager.getBearerToken()
                ?: throw IllegalStateException("Not authenticated")
            Log.d(TAG, "Токен: ${token.take(20)}... (обрезан)")
            
            val response = userApi.getProfile(token)
            val duration = System.currentTimeMillis() - startTime
            
            Log.d(TAG, "✅ ПРОФИЛЬ ПОЛУЧЕН УСПЕШНО (${duration}ms)")
            Log.d(TAG, "  Имя: ${response.name}")
            Log.d(TAG, "  Телефон: ${response.phone}")
            Log.d(TAG, "  Email: ${response.email}")
            
            response
        } catch (e: ConnectException) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОДКЛЮЧЕНИЯ (${duration}ms)", e)
            throw e
        } catch (e: SocketTimeoutException) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ТАЙМАУТ (${duration}ms)", e)
            throw e
        } catch (e: UnknownHostException) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ НЕИЗВЕСТНЫЙ ХОСТ (${duration}ms)", e)
            throw e
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОЛУЧЕНИЯ ПРОФИЛЯ (${duration}ms)", e)
            throw e
        }
    }
    
    suspend fun updateProfile(name: String, email: String) = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== ОБНОВЛЕНИЕ ПРОФИЛЯ ===")
        Log.d(TAG, "URL: ${ApiClient.USER_SERVICE_BASE_URL}api/v1/users/profile")
        Log.d(TAG, "Новые данные: name=$name, email=$email")
        
        try {
            val token = tokenManager.getBearerToken()
                ?: throw IllegalStateException("Not authenticated")
            val request = UpdateProfileRequest(name = name, email = email)
            
            val response = userApi.updateProfile(token, request)
            val duration = System.currentTimeMillis() - startTime
            
            Log.d(TAG, "✅ ПРОФИЛЬ ОБНОВЛЕН УСПЕШНО (${duration}ms)")
            Log.d(TAG, "  Успешно: ${response.success}")
            Log.d(TAG, "  Обновленное имя: ${response.user.name}")
            Log.d(TAG, "  Обновленный email: ${response.user.email}")
            
            response
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ОБНОВЛЕНИЯ ПРОФИЛЯ (${duration}ms)", e)
            throw e
        }
    }
    
    suspend fun setUserPhone(phone: String) {
        // Телефон нельзя менять через API, только при входе
        // Сохраняем локально для совместимости
    }
}

