package com.group.project.bank.university.api.dto

data class TransferRequest(
    val amount: Double,
    val recipientCard: String
)

