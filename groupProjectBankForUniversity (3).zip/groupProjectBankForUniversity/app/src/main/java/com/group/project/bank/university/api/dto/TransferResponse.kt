package com.group.project.bank.university.api.dto

data class TransferResponse(
    val success: Boolean,
    val transactionId: Long,
    val newBalance: Double
)

