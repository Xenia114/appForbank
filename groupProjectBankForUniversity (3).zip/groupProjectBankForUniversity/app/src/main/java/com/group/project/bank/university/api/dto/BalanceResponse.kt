package com.group.project.bank.university.api.dto

data class BalanceResponse(
    val balance: Double,
    val formatted: String
)

