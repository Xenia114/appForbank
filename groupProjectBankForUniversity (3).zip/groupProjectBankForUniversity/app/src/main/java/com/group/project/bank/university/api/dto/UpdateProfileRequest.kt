package com.group.project.bank.university.api.dto

data class UpdateProfileRequest(
    val name: String,
    val email: String
)

