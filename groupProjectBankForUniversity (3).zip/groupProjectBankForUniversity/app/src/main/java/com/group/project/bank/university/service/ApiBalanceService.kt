package com.group.project.bank.university.service

import android.content.Context
import android.util.Log
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.data.TokenManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ApiBalanceService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val bankingApi = ApiClient.bankingApiService
    
    companion object {
        private const val TAG = "ApiBalanceService"
    }
    
    suspend fun getBalance(): Double = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== ЗАПРОС БАЛАНСА ===")
        Log.d(TAG, "URL: ${ApiClient.BANKING_SERVICE_BASE_URL}api/v1/balance")
        
        try {
            val token = tokenManager.getBearerToken()
                ?: throw IllegalStateException("Not authenticated")
            val response = bankingApi.getBalance(token)
            val duration = System.currentTimeMillis() - startTime
            
            Log.d(TAG, "✅ БАЛАНС ПОЛУЧЕН (${duration}ms)")
            Log.d(TAG, "  Баланс: ${response.balance} ₽")
            Log.d(TAG, "  Отформатированный: ${response.formatted}")
            
            response.balance
        } catch (e: ConnectException) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОДКЛЮЧЕНИЯ К БД (${duration}ms)", e)
            throw e
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОЛУЧЕНИЯ БАЛАНСА (${duration}ms)", e)
            throw e
        }
    }
    
    suspend fun formatBalance(): String = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== ЗАПРОС ОТФОРМАТИРОВАННОГО БАЛАНСА ===")
        
        try {
            val token = tokenManager.getBearerToken()
                ?: throw IllegalStateException("Not authenticated")
            val response = bankingApi.getBalance(token)
            val duration = System.currentTimeMillis() - startTime
            
            Log.d(TAG, "✅ БАЛАНС ПОЛУЧЕН (${duration}ms): ${response.formatted}")
            
            response.formatted
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА (${duration}ms)", e)
            throw e
        }
    }
    
    suspend fun subtractAmount(amount: Double): Double = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== ВЫЧИТАНИЕ СУММЫ ===")
        Log.d(TAG, "Сумма: $amount ₽")
        Log.d(TAG, "URL: ${ApiClient.BANKING_SERVICE_BASE_URL}api/v1/balance/subtract")
        
        try {
            val token = tokenManager.getBearerToken()
                ?: throw IllegalStateException("Not authenticated")
            val response = bankingApi.subtractBalance(token, mapOf("amount" to amount))
            val duration = System.currentTimeMillis() - startTime
            
            Log.d(TAG, "✅ СУММА ВЫЧТЕНА (${duration}ms)")
            Log.d(TAG, "  Новый баланс: ${response.newBalance} ₽")
            Log.d(TAG, "  Успешно: ${response.success}")
            
            response.newBalance
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ВЫЧИТАНИЯ (${duration}ms)", e)
            throw e
        }
    }
    
    suspend fun addAmount(amount: Double): Double = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== ДОБАВЛЕНИЕ СУММЫ ===")
        Log.d(TAG, "Сумма: $amount ₽")
        Log.d(TAG, "URL: ${ApiClient.BANKING_SERVICE_BASE_URL}api/v1/balance/add")
        
        try {
            val token = tokenManager.getBearerToken()
                ?: throw IllegalStateException("Not authenticated")
            val response = bankingApi.addBalance(token, mapOf("amount" to amount))
            val duration = System.currentTimeMillis() - startTime
            
            Log.d(TAG, "✅ СУММА ДОБАВЛЕНА (${duration}ms)")
            Log.d(TAG, "  Новый баланс: ${response.newBalance} ₽")
            Log.d(TAG, "  Успешно: ${response.success}")
            
            response.newBalance
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ДОБАВЛЕНИЯ (${duration}ms)", e)
            throw e
        }
    }
}

