package com.group.project.bank.university.api.dto

data class TransactionResponse(
    val id: Long,
    val title: String,
    val date: String,
    val amount: String,
    val isPositive: Boolean,
    val iconName: String
)

