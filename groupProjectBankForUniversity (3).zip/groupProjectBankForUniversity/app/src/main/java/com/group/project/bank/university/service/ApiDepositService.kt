package com.group.project.bank.university.service

import android.content.Context
import android.util.Log
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.api.dto.CreateDepositRequest
import com.group.project.bank.university.data.DepositItem
import com.group.project.bank.university.data.TokenManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ApiDepositService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val bankingApi = ApiClient.bankingApiService
    
    companion object {
        private const val TAG = "ApiDepositService"
    }
    
    suspend fun getDeposits(): List<DepositItem> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== ЗАПРОС ВКЛАДОВ ===")
        Log.d(TAG, "URL: ${ApiClient.BANKING_SERVICE_BASE_URL}api/v1/deposits")
        
        try {
            val token = tokenManager.getBearerToken()
                ?: throw IllegalStateException("Not authenticated")
            val response = bankingApi.getDeposits(token)
            val duration = System.currentTimeMillis() - startTime
            
            Log.d(TAG, "✅ ВКЛАДЫ ПОЛУЧЕНЫ (${duration}ms)")
            Log.d(TAG, "  Количество вкладов: ${response.deposits.size}")
            response.deposits.forEachIndexed { index, deposit ->
                Log.d(TAG, "  Вклад ${index + 1}: ${deposit.name}, ${deposit.amount} ₽, ${deposit.rate}%, срок: ${deposit.term}")
            }
            
            response.deposits.map { apiDeposit ->
                DepositItem(
                    id = apiDeposit.id,
                    name = apiDeposit.name,
                    amount = apiDeposit.amount,
                    rate = apiDeposit.rate,
                    term = apiDeposit.term
                )
            }
        } catch (e: ConnectException) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОДКЛЮЧЕНИЯ К БД (${duration}ms)", e)
            throw e
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОЛУЧЕНИЯ ВКЛАДОВ (${duration}ms)", e)
            throw e
        }
    }
    
    suspend fun addToDeposit(depositId: Long, amount: Double): Result<Unit> {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== ПОПОЛНЕНИЕ ВКЛАДА ===")
        Log.d(TAG, "URL: ${ApiClient.BANKING_SERVICE_BASE_URL}api/v1/deposits/$depositId/topup")
        Log.d(TAG, "ID вклада: $depositId")
        Log.d(TAG, "Сумма пополнения: $amount ₽")
        
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                val response = bankingApi.topUpDeposit(token, depositId, mapOf("amount" to amount))
                val duration = System.currentTimeMillis() - startTime
                
                Log.d(TAG, "✅ ВКЛАД ПОПОЛНЕН УСПЕШНО (${duration}ms)")
                Log.d(TAG, "  Ответ сервера: $response")
                
                Result.success(Unit)
            }
        } catch (e: ConnectException) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОДКЛЮЧЕНИЯ К БД (${duration}ms)", e)
            Result.failure(e)
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОПОЛНЕНИЯ ВКЛАДА (${duration}ms)", e)
            Result.failure(e)
        }
    }
    
    fun formatDepositAmount(amount: String): String {
        val numAmount = amount.replace(" ", "").toDoubleOrNull() ?: 0.0
        return String.format("%,.0f", numAmount).replace(",", " ") + " ₽"
    }
    
    suspend fun createNewDeposit(
        name: String,
        amount: Double,
        rate: Double,
        term: String
    ): Result<DepositItem> {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== СОЗДАНИЕ НОВОГО ВКЛАДА ===")
        Log.d(TAG, "URL: ${ApiClient.BANKING_SERVICE_BASE_URL}api/v1/deposits")
        Log.d(TAG, "Данные вклада:")
        Log.d(TAG, "  Название: $name")
        Log.d(TAG, "  Сумма: $amount ₽")
        Log.d(TAG, "  Ставка: $rate%")
        Log.d(TAG, "  Срок: $term")
        
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                val request = CreateDepositRequest(
                    name = name,
                    amount = amount,
                    rate = rate,
                    term = term
                )
                val response = bankingApi.createDeposit(token, request)
                val duration = System.currentTimeMillis() - startTime
                
                Log.d(TAG, "✅ ВКЛАД СОЗДАН УСПЕШНО (${duration}ms)")
                Log.d(TAG, "  ID вклада: ${response.deposit.id}")
                Log.d(TAG, "  Название: ${response.deposit.name}")
                Log.d(TAG, "  Сумма: ${response.deposit.amount} ₽")
                Log.d(TAG, "  Ставка: ${response.deposit.rate}%")
                Log.d(TAG, "  Срок: ${response.deposit.term}")
                
                Result.success(
                    DepositItem(
                        id = response.deposit.id,
                        name = response.deposit.name,
                        amount = response.deposit.amount,
                        rate = response.deposit.rate,
                        term = response.deposit.term
                    )
                )
            }
        } catch (e: ConnectException) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОДКЛЮЧЕНИЯ К БД (${duration}ms)", e)
            Result.failure(e)
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА СОЗДАНИЯ ВКЛАДА (${duration}ms)", e)
            Result.failure(e)
        }
    }
}

