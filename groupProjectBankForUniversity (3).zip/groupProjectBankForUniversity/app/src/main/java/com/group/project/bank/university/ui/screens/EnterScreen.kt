package com.group.project.bank.university.ui.screens

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.group.project.bank.university.service.ApiAuthService
import com.group.project.bank.university.ui.theme.BankGreen
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@Composable
fun EnterScreen(
    onNavigateToMain: () -> Unit,
    authManager: ApiAuthService
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var showPasswordRecoveryDialog by remember { mutableStateOf(false) }
    var phoneTextFieldValue by remember { mutableStateOf(TextFieldValue("")) }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var phoneError by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf("") }

    fun formatPhoneDigits(digits: String): String {
        val cleaned = digits.take(10) // Максимум 10 цифр после +7
        return when {
            cleaned.isEmpty() -> ""
            cleaned.length <= 3 -> cleaned
            cleaned.length <= 6 -> "${cleaned.substring(0, 3)} ${cleaned.substring(3)}"
            cleaned.length <= 8 -> "${cleaned.substring(0, 3)} ${cleaned.substring(3, 6)}-${cleaned.substring(6)}"
            else -> "${cleaned.substring(0, 3)} ${cleaned.substring(3, 6)}-${cleaned.substring(6, 8)}-${cleaned.substring(8)}"
        }
    }
    
    val phoneDigits = phoneTextFieldValue.text.filter { it.isDigit() }

    fun validatePhone(digits: String): String {
        return when {
            digits.isEmpty() -> "Введите номер телефона"
            digits.length < 10 -> "Номер должен содержать 11 цифр"
            digits.length > 10 -> "Номер слишком длинный"
            else -> ""
        }
    }
    
    val formattedPhoneDigits = formatPhoneDigits(phoneDigits)

    fun validatePassword(password: String): String {
        return when {
            password.isEmpty() -> "Введите пароль"
            password.length < 6 -> "Пароль должен содержать минимум 6 символов"
            else -> ""
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Вход в банк",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.height(48.dp))

            OutlinedTextField(
                value = phoneTextFieldValue,
                onValueChange = { newValue ->
                    val oldText = phoneTextFieldValue.text
                    val oldSelection = phoneTextFieldValue.selection
                    val oldCursorPos = oldSelection.start
                    val oldDigits = oldText.filter { it.isDigit() }
                    
                    // Удаляем все нецифровые символы
                    val cleaned = newValue.text.filter { it.isDigit() }
                    
                    if (cleaned.length <= 10) {
                        val formatted = formatPhoneDigits(cleaned)
                        
                        // Определяем новую позицию курсора
                        val newCursorPosition = when {
                            // Если текст не изменился (только перемещение курсора) - используем позицию из newValue
                            cleaned == oldDigits -> {
                                // Позиция курсора относительно цифр
                                val digitsBeforeCursor = newValue.text.substring(0, newValue.selection.start.coerceAtMost(newValue.text.length)).filter { it.isDigit() }.length
                                var digitsCount = 0
                                var newPos = formatted.length
                                for (i in formatted.indices) {
                                    if (formatted[i].isDigit()) {
                                        digitsCount++
                                        if (digitsCount >= digitsBeforeCursor) {
                                            newPos = i + 1
                                            break
                                        }
                                    }
                                }
                                newPos.coerceIn(0, formatted.length)
                            }
                            // Если вводится новый символ (текст увеличился) и курсор был в конце
                            cleaned.length > oldDigits.length && oldCursorPos >= oldText.length -> {
                                formatted.length
                            }
                            // Если удаляется символ или курсор был не в конце - сохраняем позицию
                            else -> {
                                val oldDigitsBeforeCursor = oldText.substring(0, oldCursorPos.coerceAtMost(oldText.length)).filter { it.isDigit() }.length
                                var digitsCount = 0
                                var newPos = formatted.length
                                for (i in formatted.indices) {
                                    if (formatted[i].isDigit()) {
                                        digitsCount++
                                        if (digitsCount >= oldDigitsBeforeCursor) {
                                            newPos = i + 1
                                            break
                                        }
                                    }
                                }
                                newPos.coerceIn(0, formatted.length)
                            }
                        }
                        
                        phoneTextFieldValue = TextFieldValue(
                            text = formatted,
                            selection = androidx.compose.ui.text.TextRange(newCursorPosition)
                        )
                        phoneError = validatePhone(cleaned)
                    } else {
                        // Если превышен лимит, сохраняем старое значение, но обновляем позицию курсора из newValue
                        phoneTextFieldValue = TextFieldValue(
                            text = oldText,
                            selection = newValue.selection
                        )
                    }
                },
                label = { 
                    Text(
                        "Номер телефона",
                        style = MaterialTheme.typography.bodyMedium
                    ) 
                },
                placeholder = { 
                    Text(
                        "(999) 123-45-67",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth(),
                textStyle = MaterialTheme.typography.bodyLarge,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                maxLines = 1,
                prefix = {
                    Text(
                        "+7 ",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                isError = phoneError.isNotEmpty(),
                supportingText = {
                    if (phoneError.isNotEmpty()) {
                        Text(
                            phoneError, 
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BankGreen,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                    focusedLabelColor = BankGreen,
                    unfocusedLabelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { 
                    password = it
                    passwordError = validatePassword(password)
                },
                label = { 
                    Text(
                        "Пароль",
                        style = MaterialTheme.typography.bodyMedium
                    ) 
                },
                placeholder = { 
                    Text(
                        "Введите пароль",
                        style = MaterialTheme.typography.bodyLarge
                    ) 
                },
                modifier = Modifier
                    .fillMaxWidth(),
                textStyle = MaterialTheme.typography.bodyLarge,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                maxLines = 1,
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = if (passwordVisible) "Скрыть пароль" else "Показать пароль",
                            tint = if (passwordVisible) BankGreen else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                },
                isError = passwordError.isNotEmpty(),
                supportingText = {
                    if (passwordError.isNotEmpty()) {
                        Text(
                            passwordError, 
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BankGreen,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                    focusedLabelColor = BankGreen,
                    unfocusedLabelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.height(32.dp))

            Spacer(modifier = Modifier.height(32.dp))

            if (loginError.isNotEmpty()) {
                Text(
                    text = loginError,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
            
            Button(
                onClick = {
                    val digits = phoneTextFieldValue.text.filter { it.isDigit() }
                    phoneError = validatePhone(digits)
                    passwordError = validatePassword(password)
                    loginError = ""
                    
                    if (phoneError.isEmpty() && passwordError.isEmpty() && digits.length == 10 && password.isNotEmpty()) {
                        isLoading = true
                        val formattedPhone = "+7 ${formatPhoneDigits(digits)}"
                        
                        scope.launch {
                            Log.d("EnterScreen", "=== ПОПЫТКА ВХОДА ===")
                            Log.d("EnterScreen", "Введенные данные:")
                            Log.d("EnterScreen", "  Телефон: $formattedPhone")
                            Log.d("EnterScreen", "  Пароль: ${password.take(2)}*** (скрыт)")
                            
                            val result = authManager.login(formattedPhone, password)
                            isLoading = false
                            
                            result.onSuccess {
                                Log.d("EnterScreen", "✅ Вход успешен, переход на главный экран")
                                onNavigateToMain()
                            }.onFailure { error ->
                                Log.e("EnterScreen", "❌ ОШИБКА ВХОДА")
                                Log.e("EnterScreen", "  Тип ошибки: ${error.javaClass.simpleName}")
                                Log.e("EnterScreen", "  Сообщение: ${error.message}")
                                
                                loginError = when {
                                    error.message?.contains("Invalid", ignoreCase = true) == true -> 
                                        "Неверный номер телефона или пароль"
                                    error.message?.contains("network", ignoreCase = true) == true -> 
                                        "Ошибка сети. Проверьте подключение к интернету"
                                    error is java.net.ConnectException -> 
                                        "Ошибка сети. Проверьте подключение к интернету"
                                    error is java.net.SocketTimeoutException -> 
                                        "Ошибка сети. Превышено время ожидания"
                                    error is java.net.UnknownHostException -> 
                                        "Ошибка сети. Не удалось найти сервер"
                                    else -> "Ошибка входа. Попробуйте снова"
                                }
                                
                                Log.e("EnterScreen", "  Показано пользователю: $loginError")
                            }
                        }
                    }
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BankGreen,
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 0.dp,
                    pressedElevation = 2.dp
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(
                        text = "Войти",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            TextButton(
                onClick = { showPasswordRecoveryDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Забыли пароль?",
                    color = BankGreen,
                    fontSize = 14.sp
                )
            }
        }
    }
    
    // Диалог восстановления пароля
    if (showPasswordRecoveryDialog) {
        AlertDialog(
            onDismissRequest = { showPasswordRecoveryDialog = false },
            title = {
                Text(
                    text = "Восстановление пароля",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Для восстановления пароля обратитесь в службу поддержки по телефону 8-800-555-35-35 или воспользуйтесь функцией восстановления на сайте банка.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(onClick = { showPasswordRecoveryDialog = false }) {
                    Text("ОК", color = BankGreen)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}
