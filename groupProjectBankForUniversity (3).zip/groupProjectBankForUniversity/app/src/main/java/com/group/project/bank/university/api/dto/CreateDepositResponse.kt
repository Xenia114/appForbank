package com.group.project.bank.university.api.dto

data class CreateDepositResponse(
    val success: Boolean,
    val depositId: Long,
    val deposit: DepositResponse
)

