package com.group.project.bank.university.service

import android.content.Context
import android.util.Log
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.api.dto.TransferRequest
import com.group.project.bank.university.data.TokenManager
import com.group.project.bank.university.data.TransactionItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ApiTransactionService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val bankingApi = ApiClient.bankingApiService
    
    companion object {
        private const val TAG = "ApiTransactionService"
    }
    
    suspend fun getTransactions(limit: Int = 100, offset: Int = 0): List<TransactionItem> = 
        withContext(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            Log.d(TAG, "=== ЗАПРОС ТРАНЗАКЦИЙ ===")
            Log.d(TAG, "URL: ${ApiClient.BANKING_SERVICE_BASE_URL}api/v1/transactions")
            Log.d(TAG, "Параметры: limit=$limit, offset=$offset")
            
            try {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                val response = bankingApi.getTransactions(token, limit, offset)
                val duration = System.currentTimeMillis() - startTime
                
                Log.d(TAG, "✅ ТРАНЗАКЦИИ ПОЛУЧЕНЫ (${duration}ms)")
                Log.d(TAG, "  Количество: ${response.transactions.size}")
                response.transactions.take(3).forEachIndexed { index, tx ->
                    Log.d(TAG, "  Транзакция ${index + 1}: ${tx.title}, ${tx.amount} ₽, ${tx.date}")
                }
                if (response.transactions.size > 3) {
                    Log.d(TAG, "  ... и еще ${response.transactions.size - 3} транзакций")
                }
                
                response.transactions.map { apiTransaction ->
                    TransactionItem(
                        title = apiTransaction.title,
                        date = apiTransaction.date,
                        amount = apiTransaction.amount,
                        isPositive = apiTransaction.isPositive,
                        iconName = apiTransaction.iconName
                    )
                }
            } catch (e: ConnectException) {
                val duration = System.currentTimeMillis() - startTime
                Log.e(TAG, "❌ ОШИБКА ПОДКЛЮЧЕНИЯ К БД (${duration}ms)", e)
                throw e
            } catch (e: Exception) {
                val duration = System.currentTimeMillis() - startTime
                Log.e(TAG, "❌ ОШИБКА ПОЛУЧЕНИЯ ТРАНЗАКЦИЙ (${duration}ms)", e)
                throw e
            }
        }
    
    suspend fun addTransferTransaction(amount: Double, recipientCard: String): Result<Unit> {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== СОЗДАНИЕ ПЕРЕВОДА ===")
        Log.d(TAG, "URL: ${ApiClient.BANKING_SERVICE_BASE_URL}api/v1/transactions/transfer")
        Log.d(TAG, "Данные перевода:")
        Log.d(TAG, "  Сумма: $amount ₽")
        Log.d(TAG, "  Получатель: $recipientCard")
        
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                val request = TransferRequest(amount = amount, recipientCard = recipientCard)
                
                val response = bankingApi.transfer(token, request)
                val duration = System.currentTimeMillis() - startTime
                
                Log.d(TAG, "✅ ПЕРЕВОД ВЫПОЛНЕН УСПЕШНО (${duration}ms)")
                Log.d(TAG, "  Новый баланс: ${response.newBalance} ₽")
                Log.d(TAG, "  ID транзакции: ${response.transactionId}")
                
                Result.success(Unit)
            }
        } catch (e: ConnectException) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПОДКЛЮЧЕНИЯ К БД (${duration}ms)", e)
            Result.failure(e)
        } catch (e: SocketTimeoutException) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ТАЙМАУТ ПРИ ПЕРЕВОДЕ (${duration}ms)", e)
            Result.failure(e)
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА ПЕРЕВОДА (${duration}ms)", e)
            Result.failure(e)
        }
    }
    
    suspend fun addDepositTransaction(amount: Double, depositName: String): Result<Unit> {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== СОЗДАНИЕ ТРАНЗАКЦИИ ВКЛАДА ===")
        Log.d(TAG, "Сумма: $amount ₽, Вклад: $depositName")
        
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                bankingApi.addDepositTransaction(
                    token,
                    mapOf("amount" to amount, "depositName" to depositName)
                )
                val duration = System.currentTimeMillis() - startTime
                Log.d(TAG, "✅ ТРАНЗАКЦИЯ ВКЛАДА СОЗДАНА (${duration}ms)")
                Result.success(Unit)
            }
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА СОЗДАНИЯ ТРАНЗАКЦИИ (${duration}ms)", e)
            Result.failure(e)
        }
    }
    
    suspend fun addOpenDepositTransaction(amount: Double, depositName: String): Result<Unit> {
        val startTime = System.currentTimeMillis()
        Log.d(TAG, "=== СОЗДАНИЕ ТРАНЗАКЦИИ ОТКРЫТИЯ ВКЛАДА ===")
        Log.d(TAG, "Сумма: $amount ₽, Вклад: $depositName")
        
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                    ?: throw IllegalStateException("Not authenticated")
                bankingApi.addDepositTransaction(
                    token,
                    mapOf("amount" to amount, "depositName" to depositName)
                )
                val duration = System.currentTimeMillis() - startTime
                Log.d(TAG, "✅ ТРАНЗАКЦИЯ ОТКРЫТИЯ ВКЛАДА СОЗДАНА (${duration}ms)")
                Result.success(Unit)
            }
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            Log.e(TAG, "❌ ОШИБКА СОЗДАНИЯ ТРАНЗАКЦИИ (${duration}ms)", e)
            Result.failure(e)
        }
    }
}

