package com.group.project.bank.university.api.dto

data class LoginRequest(
    val phone: String,
    val password: String
)

