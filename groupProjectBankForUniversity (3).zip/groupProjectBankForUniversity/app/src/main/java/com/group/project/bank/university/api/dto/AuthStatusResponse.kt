package com.group.project.bank.university.api.dto

data class AuthStatusResponse(
    val isLoggedIn: Boolean,
    val userId: Long
)

