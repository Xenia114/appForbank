package com.group.project.bank.university.api

import com.group.project.bank.university.api.dto.*
import retrofit2.http.*

interface BankingApiService {
    @GET("api/v1/balance")
    suspend fun getBalance(@Header("Authorization") token: String): BalanceResponse
    
    @POST("api/v1/balance/add")
    suspend fun addBalance(
        @Header("Authorization") token: String,
        @Body request: Map<String, Double>
    ): BalanceUpdateResponse
    
    @POST("api/v1/balance/subtract")
    suspend fun subtractBalance(
        @Header("Authorization") token: String,
        @Body request: Map<String, Double>
    ): BalanceUpdateResponse
    
    @GET("api/v1/transactions")
    suspend fun getTransactions(
        @Header("Authorization") token: String,
        @Query("limit") limit: Int = 10,
        @Query("offset") offset: Int = 0
    ): TransactionsResponse
    
    @POST("api/v1/transactions/transfer")
    suspend fun transfer(
        @Header("Authorization") token: String,
        @Body request: TransferRequest
    ): TransferResponse
    
    @POST("api/v1/transactions/deposit")
    suspend fun addDepositTransaction(
        @Header("Authorization") token: String,
        @Body request: Map<String, Any>
    ): Map<String, Any>
    
    @GET("api/v1/deposits")
    suspend fun getDeposits(@Header("Authorization") token: String): DepositsResponse
    
    @POST("api/v1/deposits")
    suspend fun createDeposit(
        @Header("Authorization") token: String,
        @Body request: CreateDepositRequest
    ): CreateDepositResponse
    
    @PUT("api/v1/deposits/{depositId}/topup")
    suspend fun topUpDeposit(
        @Header("Authorization") token: String,
        @Path("depositId") depositId: Long,
        @Body request: Map<String, Double>
    ): Map<String, Any>
}

