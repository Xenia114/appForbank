package com.group.project.bank.university.ui.theme

import androidx.compose.ui.graphics.Color

// Основные цвета банка (зеленые тона как у Сбербанка)
val BankGreen = Color(0xFF00A86B)
val BankGreenDark = Color(0xFF008A5A)
val BankGreenLight = Color(0xFF00C97F)

// Дополнительные цвета
val BankBlue = Color(0xFF1E88E5)
val BankBlueDark = Color(0xFF1565C0)
val BankBlueLight = Color(0xFF42A5F5)

// Фоновые цвета
val BackgroundLight = Color(0xFFF5F7FA)
val BackgroundDark = Color(0xFF1A1D29)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF252836)

// Текстовые цвета
val TextPrimary = Color(0xFF1A1D29)
val TextSecondary = Color(0xFF6B7280)
val TextOnPrimary = Color(0xFFFFFFFF)

// Акцентные цвета
val AccentOrange = Color(0xFFFF6B35)
val AccentRed = Color(0xFFE53935)
val AccentYellow = Color(0xFFFFC107)

// Статусные цвета
val Success = Color(0xFF4CAF50)
val Warning = Color(0xFFFF9800)
val Error = Color(0xFFE53935)
val Info = Color(0xFF2196F3)