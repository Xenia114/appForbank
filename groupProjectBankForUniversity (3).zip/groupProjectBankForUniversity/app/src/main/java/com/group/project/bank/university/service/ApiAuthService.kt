package com.group.project.bank.university.service

import android.content.Context
import android.util.Log
import com.group.project.bank.university.api.ApiClient
import com.group.project.bank.university.api.dto.LoginRequest
import com.group.project.bank.university.data.TokenManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ApiAuthService(private val context: Context) {
    private val tokenManager = TokenManager(context)
    private val userApi = ApiClient.userApiService
    
    companion object {
        private const val TAG = "ApiAuthService"
    }
    
    suspend fun login(phone: String, password: String): Result<Unit> {
        return try {
            Log.d(TAG, "=== НАЧАЛО АВТОРИЗАЦИИ ===")
            Log.d(TAG, "Введенный телефон: $phone")
            Log.d(TAG, "Введенный пароль: ${password.take(2)}*** (скрыт)")
            Log.d(TAG, "URL сервиса: ${ApiClient.USER_SERVICE_BASE_URL}")
            Log.d(TAG, "Попытка подключения к микросервису...")
            
            withContext(Dispatchers.IO) {
                val request = LoginRequest(phone = phone, password = password)
                Log.d(TAG, "Отправка запроса: POST /api/v1/auth/login")
                Log.d(TAG, "Тело запроса - phone: $phone, password: [скрыт]")
                
                try {
                    val response = userApi.login(request)
                    Log.d(TAG, "✅ УСПЕШНОЕ ПОДКЛЮЧЕНИЕ К БД!")
                    Log.d(TAG, "Получен ответ от сервера:")
                    Log.d(TAG, "  - Token: ${response.token.take(20)}... (обрезан)")
                    Log.d(TAG, "  - UserId: ${response.userId}")
                    Log.d(TAG, "Сохранение токена...")
                    
                    tokenManager.saveToken(response.token, response.userId)
                    Log.d(TAG, "✅ Токен успешно сохранен")
                    Log.d(TAG, "=== АВТОРИЗАЦИЯ ЗАВЕРШЕНА УСПЕШНО ===")
                    Result.success(Unit)
                } catch (e: ConnectException) {
                    Log.e(TAG, "❌ ОШИБКА ПОДКЛЮЧЕНИЯ: Не удалось подключиться к серверу")
                    Log.e(TAG, "  Тип ошибки: ConnectException")
                    Log.e(TAG, "  Сообщение: ${e.message}")
                    Log.e(TAG, "  URL: ${ApiClient.USER_SERVICE_BASE_URL}")
                    Log.e(TAG, "  Проверьте: запущен ли микросервис на порту 8081?")
                    Result.failure(e)
                } catch (e: SocketTimeoutException) {
                    Log.e(TAG, "❌ ОШИБКА ТАЙМАУТА: Превышено время ожидания ответа")
                    Log.e(TAG, "  Тип ошибки: SocketTimeoutException")
                    Log.e(TAG, "  Сообщение: ${e.message}")
                    Log.e(TAG, "  Сервер не отвечает в течение 30 секунд")
                    Result.failure(e)
                } catch (e: UnknownHostException) {
                    Log.e(TAG, "❌ ОШИБКА ХОСТА: Не удалось найти сервер")
                    Log.e(TAG, "  Тип ошибки: UnknownHostException")
                    Log.e(TAG, "  Сообщение: ${e.message}")
                    Log.e(TAG, "  URL: ${ApiClient.USER_SERVICE_BASE_URL}")
                    Log.e(TAG, "  Проверьте: правильный ли адрес для эмулятора (10.0.2.2)?")
                    Result.failure(e)
                } catch (e: retrofit2.HttpException) {
                    Log.e(TAG, "❌ HTTP ОШИБКА: Сервер вернул ошибку")
                    Log.e(TAG, "  Тип ошибки: HttpException")
                    Log.e(TAG, "  Код ответа: ${e.code()}")
                    Log.e(TAG, "  Сообщение: ${e.message()}")
                    try {
                        val errorBody = e.response()?.errorBody()?.string()
                        Log.e(TAG, "  Тело ошибки: $errorBody")
                    } catch (ex: Exception) {
                        Log.e(TAG, "  Не удалось прочитать тело ошибки")
                    }
                    Log.e(TAG, "  Возможно: неверный телефон или пароль")
                    Result.failure(e)
                } catch (e: Exception) {
                    Log.e(TAG, "❌ НЕИЗВЕСТНАЯ ОШИБКА")
                    Log.e(TAG, "  Тип ошибки: ${e.javaClass.simpleName}")
                    Log.e(TAG, "  Сообщение: ${e.message}")
                    Log.e(TAG, "  Stack trace:", e)
                    Result.failure(e)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ КРИТИЧЕСКАЯ ОШИБКА В БЛОКЕ withContext")
            Log.e(TAG, "  Тип ошибки: ${e.javaClass.simpleName}")
            Log.e(TAG, "  Сообщение: ${e.message}")
            Log.e(TAG, "  Stack trace:", e)
            Result.failure(e)
        }
    }
    
    fun isLoggedIn(): Boolean {
        return tokenManager.hasToken()
    }
    
    suspend fun logout(): Result<Unit> {
        return try {
            withContext(Dispatchers.IO) {
                val token = tokenManager.getBearerToken()
                if (token != null) {
                    userApi.logout(token)
                }
                tokenManager.clearToken()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            // Даже если запрос не удался, очищаем токен локально
            tokenManager.clearToken()
            Result.success(Unit)
        }
    }
    
    fun getToken(): String? {
        return tokenManager.getBearerToken()
    }
}

