package com.group.project.bank.university.api

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {
    // Для эмулятора Android используем 10.0.2.2 вместо localhost
    // Для реального устройства замените на IP адрес вашего компьютера
    const val USER_SERVICE_BASE_URL = "http://10.0.2.2:8081/"
    const val BANKING_SERVICE_BASE_URL = "http://10.0.2.2:8082/"
    
    private const val TAG = "ApiClient"
    
    init {
        Log.d(TAG, "=== ИНИЦИАЛИЗАЦИЯ API КЛИЕНТА ===")
        Log.d(TAG, "User Service URL: $USER_SERVICE_BASE_URL")
        Log.d(TAG, "Banking Service URL: $BANKING_SERVICE_BASE_URL")
        Log.d(TAG, "Таймауты: connect=30s, read=30s, write=30s")
    }
    
    private val loggingInterceptor = HttpLoggingInterceptor(object : HttpLoggingInterceptor.Logger {
        override fun log(message: String) {
            Log.d(TAG, message)
        }
    }).apply {
        level = HttpLoggingInterceptor.Level.BODY
    }
    
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .addInterceptor { chain ->
            val request = chain.request()
            val startTime = System.currentTimeMillis()
            
            Log.d(TAG, "→ HTTP ${request.method} ${request.url}")
            Log.d(TAG, "  Headers: ${request.headers}")
            
            try {
                val response = chain.proceed(request)
                val duration = System.currentTimeMillis() - startTime
                
                Log.d(TAG, "← HTTP ${response.code} ${response.message} (${duration}ms)")
                Log.d(TAG, "  Response headers: ${response.headers}")
                
                if (response.code >= 400) {
                    Log.e(TAG, "  ⚠️ ОШИБКА HTTP: код ${response.code}")
                }
                
                response
            } catch (e: java.net.ConnectException) {
                val duration = System.currentTimeMillis() - startTime
                Log.e(TAG, "❌ ОШИБКА ПОДКЛЮЧЕНИЯ (${duration}ms): ${e.message}")
                Log.e(TAG, "  URL: ${request.url}")
                Log.e(TAG, "  Проверьте: запущен ли микросервис?")
                throw e
            } catch (e: java.net.SocketTimeoutException) {
                val duration = System.currentTimeMillis() - startTime
                Log.e(TAG, "❌ ТАЙМАУТ (${duration}ms): ${e.message}")
                Log.e(TAG, "  URL: ${request.url}")
                throw e
            } catch (e: java.net.UnknownHostException) {
                val duration = System.currentTimeMillis() - startTime
                Log.e(TAG, "❌ НЕИЗВЕСТНЫЙ ХОСТ (${duration}ms): ${e.message}")
                Log.e(TAG, "  URL: ${request.url}")
                throw e
            } catch (e: Exception) {
                val duration = System.currentTimeMillis() - startTime
                Log.e(TAG, "❌ ОШИБКА ПРИ ВЫПОЛНЕНИИ ЗАПРОСА (${duration}ms)", e)
                throw e
            }
        }
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    
    val userApiService: UserApiService = Retrofit.Builder()
        .baseUrl(USER_SERVICE_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(UserApiService::class.java)
    
    val bankingApiService: BankingApiService = Retrofit.Builder()
        .baseUrl(BANKING_SERVICE_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(BankingApiService::class.java)
}

