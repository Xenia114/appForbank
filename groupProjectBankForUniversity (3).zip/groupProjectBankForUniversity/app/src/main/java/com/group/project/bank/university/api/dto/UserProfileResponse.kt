package com.group.project.bank.university.api.dto

data class UserProfileResponse(
    val userId: Long,
    val name: String,
    val phone: String,
    val email: String
)

