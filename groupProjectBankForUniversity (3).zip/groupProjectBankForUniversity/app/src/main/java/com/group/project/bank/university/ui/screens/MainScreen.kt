package com.group.project.bank.university.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.group.project.bank.university.service.ApiBalanceService
import com.group.project.bank.university.service.ApiTransactionService
import com.group.project.bank.university.service.ApiUserService
import com.group.project.bank.university.data.TransactionItem
import com.group.project.bank.university.ui.theme.BankGreen
import com.group.project.bank.university.ui.theme.BankBlue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

data class TransactionData(
    val title: String,
    val date: String,
    val amount: String,
    val isPositive: Boolean,
    val icon: ImageVector
)

data class DepositData(
    val name: String,
    val amount: String,
    val rate: String,
    val term: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    onNavigateToTransfers: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToDeposits: () -> Unit,
    balanceService: ApiBalanceService
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val transactionService = remember { ApiTransactionService(context) }
    val userService = remember { ApiUserService(context) }
    
    var balance by remember { mutableStateOf("0 ₽") }
    var userName by remember { mutableStateOf("Иван Иванов") }
    var isCardDataVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }
    
    val cardNumber = if (isCardDataVisible) "1234 5678 9012 1234" else "**** **** **** 1234"
    val cardExpiry = if (isCardDataVisible) "12/25" else "**/**"
    val cardCVV = if (isCardDataVisible) "123" else "***"
    
    // Получаем последние 3 транзакции
    var recentTransactions by remember { mutableStateOf<List<TransactionItem>>(emptyList()) }
    
    // Загружаем данные при первом запуске и при возврате на экран
    LaunchedEffect(Unit) {
        scope.launch {
            try {
                isLoading = true
                balance = balanceService.formatBalance()
                userName = userService.getUserName()
                recentTransactions = transactionService.getTransactions(limit = 3, offset = 0)
            } catch (e: Exception) {
                // Обработка ошибок
            } finally {
                isLoading = false
            }
        }
    }
    
    // Функция для получения иконки по имени
    fun getIconByName(iconName: String): ImageVector {
        return when (iconName) {
            "ArrowDownward" -> Icons.Default.ArrowDownward
            "ArrowUpward" -> Icons.Default.Send
            "ShoppingCart" -> Icons.Default.ShoppingCart
            "AccountBalance" -> Icons.Default.AccountBalance
            "Payment" -> Icons.Default.Payment
            else -> Icons.Default.Info
        }
    }
    
    // Преобразуем TransactionItem в TransactionData для отображения
    val recentTransactionsData = remember(recentTransactions) {
        recentTransactions.map { item ->
            TransactionData(
                title = item.title,
                date = item.date,
                amount = item.amount,
                isPositive = item.isPositive,
                icon = getIconByName(item.iconName)
            )
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Верхняя панель
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "Добро пожаловать",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    Text(
                        text = userName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            },
            actions = {
                IconButton(onClick = onNavigateToProfile) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Профиль",
                        tint = BankGreen
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = MaterialTheme.colorScheme.onSurface
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Карточка баланса
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = BankGreen
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Баланс",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { isCardDataVisible = !isCardDataVisible },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = if (isCardDataVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (isCardDataVisible) "Скрыть данные карты" else "Показать данные карты",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.CreditCard,
                                contentDescription = "Карта",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                    
                    Text(
                        text = balance,
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = cardNumber,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White.copy(alpha = 0.9f),
                            fontWeight = FontWeight.Medium
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Срок действия",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = cardExpiry,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Column {
                                Text(
                                    text = "CVV",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = cardCVV,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // Быстрые действия
            Text(
                text = "Быстрые действия",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionButton(
                    icon = Icons.Default.ArrowUpward,
                    label = "Перевод",
                    onClick = onNavigateToTransfers,
                    modifier = Modifier.weight(1f)
                )
                QuickActionButton(
                    icon = Icons.Default.Receipt,
                    label = "История",
                    onClick = onNavigateToHistory,
                    modifier = Modifier.weight(1f)
                )
                QuickActionButton(
                    icon = Icons.Default.AccountBalance,
                    label = "Вклады",
                    onClick = onNavigateToDeposits,
                    modifier = Modifier.weight(1f)
                )
            }

            // Последние операции
            Text(
                text = "Последние операции",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
            )

            // Список операций
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (recentTransactionsData.isEmpty()) {
                        Text(
                            text = "Нет операций",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            modifier = Modifier.padding(vertical = 16.dp)
                        )
                    } else {
                        recentTransactionsData.forEach { transaction ->
                            TransactionItem(
                                icon = transaction.icon,
                                title = transaction.title,
                                subtitle = transaction.date,
                                amount = transaction.amount,
                                isPositive = transaction.isPositive
                            )
                            if (transaction != recentTransactionsData.last()) {
                                HorizontalDivider(
                                    modifier = Modifier.padding(vertical = 4.dp),
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    
}


@Composable
fun QuickActionButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = BankGreen,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun TransactionItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    amount: String,
    isPositive: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isPositive) BankGreen else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(24.dp)
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }
        Text(
            text = amount,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
            color = if (isPositive) BankGreen else MaterialTheme.colorScheme.onSurface
        )
    }
}

