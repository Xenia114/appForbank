package com.group.project.bank.university.data

import android.content.Context
import android.content.SharedPreferences
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import com.google.common.truth.Truth.assertThat

/**
 * Юнит-тесты для класса DepositManager
 * 
 * Что тестируем:
 * - Получение списка вкладов по умолчанию
 * - Форматирование суммы вклада
 * - Добавление средств на существующий вклад (addToDeposit)
 * - Создание нового вклада (createNewDeposit)
 * - Сохранение и загрузку вкладов через Gson
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class DepositManagerTest {

    private lateinit var context: Context
    private lateinit var depositManager: DepositManager
    private lateinit var sharedPreferences: SharedPreferences

    /**
     * Подготовка тестового окружения перед каждым тестом
     */
    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        depositManager = DepositManager(context)
        sharedPreferences = context.getSharedPreferences(
            "bank_app_prefs",
            Context.MODE_PRIVATE
        )
        // Очищаем данные перед каждым тестом
        sharedPreferences.edit().clear().apply()
    }

    /**
     * Тест 1: Проверка вкладов по умолчанию
     * 
     * Что проверяем:
     * - Если вклады не сохранены, должны возвращаться вклады по умолчанию
     * - Должно быть 4 вклада по умолчанию
     */
    @Test
    fun `getDeposits should return default deposits when no data is saved`() {
        // Выполняем действие: получаем список вкладов
        val deposits = depositManager.getDeposits()
        
        // Проверяем результат: должно быть 4 вклада по умолчанию
        assertThat(deposits).hasSize(4)
        
        // Проверяем, что первый вклад имеет правильные данные
        val firstDeposit = deposits[0]
        assertThat(firstDeposit.name).isEqualTo("Накопительный вклад")
        assertThat(firstDeposit.amount).isEqualTo("500000")
        assertThat(firstDeposit.rate).isEqualTo("5.5%")
    }

    /**
     * Тест 2: Форматирование суммы вклада
     * 
     * Что проверяем:
     * - Метод formatDepositAmount() должен форматировать сумму с пробелами и символом рубля
     * - Формат: "500 000 ₽"
     */
    @Test
    fun `formatDepositAmount should format amount with spaces and ruble sign`() {
        // Подготовка: сумма для форматирования
        val amount = "500000"
        
        // Выполняем действие: форматируем сумму
        val formatted = depositManager.formatDepositAmount(amount)
        
        // Проверяем результат: должна быть строка с пробелами и символом рубля
        assertThat(formatted).contains("₽")
        assertThat(formatted).contains(" ")
        // Проверяем, что число присутствует
        assertThat(formatted).matches(".*\\d+.*₽")
    }

    /**
     * Тест 3: Добавление средств на существующий вклад
     * 
     * Что проверяем:
     * - После добавления средств сумма вклада должна увеличиться
     * - Изменения должны сохраниться
     */
    @Test
    fun `addToDeposit should increase deposit amount`() {
        // Подготовка: получаем начальный список вкладов
        val initialDeposits = depositManager.getDeposits()
        val depositIndex = 0 // Первый вклад
        val initialAmount = initialDeposits[depositIndex].amount.replace(" ", "").toDouble()
        val amountToAdd = 10000.0
        
        // Выполняем действие: добавляем средства на вклад
        depositManager.addToDeposit(depositIndex, amountToAdd)
        
        // Проверяем результат: сумма вклада должна увеличиться
        val updatedDeposits = depositManager.getDeposits()
        val newAmount = updatedDeposits[depositIndex].amount.replace(" ", "").toDouble()
        assertThat(newAmount).isEqualTo(initialAmount + amountToAdd)
    }

    /**
     * Тест 4: Создание нового вклада
     * 
     * Что проверяем:
     * - После создания нового вклада он должен появиться в списке
     * - Новый вклад должен иметь правильные данные
     */
    @Test
    fun `createNewDeposit should add new deposit to list`() {
        // Подготовка: получаем начальное количество вкладов
        val initialCount = depositManager.getDeposits().size
        
        // Подготовка: данные для нового вклада
        val depositName = "Тестовый вклад"
        val depositAmount = 100000.0
        val depositRate = 6.5
        val depositTerm = "До 31.12.2025"
        
        // Выполняем действие: создаем новый вклад
        depositManager.createNewDeposit(
            depositName,
            depositAmount,
            depositRate,
            depositTerm
        )
        
        // Проверяем результат: количество вкладов должно увеличиться
        val deposits = depositManager.getDeposits()
        assertThat(deposits).hasSize(initialCount + 1)
        
        // Проверяем, что новый вклад добавлен с правильными данными
        val newDeposit = deposits.last()
        assertThat(newDeposit.name).isEqualTo(depositName)
        assertThat(newDeposit.amount).isEqualTo(depositAmount.toInt().toString())
        assertThat(newDeposit.rate).isEqualTo("6.5%")
        assertThat(newDeposit.term).isEqualTo(depositTerm)
    }

    /**
     * Тест 5: Сохранение и загрузка вкладов
     * 
     * Что проверяем:
     * - Вклады должны сохраняться в SharedPreferences через Gson
     * - При создании нового экземпляра DepositManager вклады должны загружаться
     */
    @Test
    fun `deposits should persist between DepositManager instances`() {
        // Подготовка: создаем новый вклад через первый экземпляр
        depositManager.createNewDeposit(
            "Тестовый вклад",
            50000.0,
            5.0,
            "До 31.12.2025"
        )
        
        val initialCount = depositManager.getDeposits().size
        
        // Выполняем действие: создаем новый экземпляр DepositManager
        val newDepositManager = DepositManager(context)
        
        // Проверяем результат: новый экземпляр должен видеть сохраненные вклады
        val deposits = newDepositManager.getDeposits()
        assertThat(deposits).hasSize(initialCount)
        
        // Проверяем, что тестовый вклад присутствует
        val testDeposit = deposits.find { it.name == "Тестовый вклад" }
        assertThat(testDeposit).isNotNull()
        assertThat(testDeposit!!.amount).isEqualTo("50000")
    }

    /**
     * Тест 6: Добавление средств на несуществующий вклад
     * 
     * Что проверяем:
     * - При попытке добавить средства на несуществующий индекс ничего не должно произойти
     * - Список вкладов не должен измениться
     */
    @Test
    fun `addToDeposit with invalid index should not change deposits`() {
        // Подготовка: получаем начальный список вкладов
        val initialDeposits = depositManager.getDeposits()
        val invalidIndex = 999 // Несуществующий индекс
        
        // Выполняем действие: пытаемся добавить средства на несуществующий вклад
        depositManager.addToDeposit(invalidIndex, 1000.0)
        
        // Проверяем результат: список вкладов не должен измениться
        val deposits = depositManager.getDeposits()
        assertThat(deposits).hasSize(initialDeposits.size)
        // Проверяем, что суммы вкладов не изменились
        for (i in deposits.indices) {
            assertThat(deposits[i].amount).isEqualTo(initialDeposits[i].amount)
        }
    }

    /**
     * Тест 7: Множественные операции с вкладами
     * 
     * Что проверяем:
     * - Можно выполнить несколько операций подряд
     * - Все операции должны корректно сохраняться
     */
    @Test
    fun `multiple deposit operations should work correctly`() {
        // Выполняем последовательность действий
        depositManager.createNewDeposit("Вклад 1", 10000.0, 5.0, "До 31.12.2025")
        depositManager.createNewDeposit("Вклад 2", 20000.0, 6.0, "До 31.12.2026")
        
        val deposits = depositManager.getDeposits()
        val deposit1Index = deposits.indexOfFirst { it.name == "Вклад 1" }
        val deposit2Index = deposits.indexOfFirst { it.name == "Вклад 2" }
        
        // Добавляем средства на вклады
        depositManager.addToDeposit(deposit1Index, 5000.0)
        depositManager.addToDeposit(deposit2Index, 10000.0)
        
        // Проверяем результаты
        val updatedDeposits = depositManager.getDeposits()
        assertThat(updatedDeposits[deposit1Index].amount.replace(" ", "").toDouble())
            .isEqualTo(15000.0)
        assertThat(updatedDeposits[deposit2Index].amount.replace(" ", "").toDouble())
            .isEqualTo(30000.0)
    }
}

