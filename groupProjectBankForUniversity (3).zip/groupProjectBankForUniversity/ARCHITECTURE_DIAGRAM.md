# Архитектурная диаграмма микросервисов

## Mermaid диаграмма (можно вставить в Markdown):

```mermaid
graph TB
    subgraph Client["📱 Клиентское приложение"]
        Android["Android App<br/>(Kotlin + Retrofit)"]
    end
    
    subgraph Services["🔧 Микросервисы"]
        UserService["User Service<br/>:8081<br/>Авторизация + Профиль"]
        BankingService["Banking Service<br/>:8082<br/>Финансовые операции"]
    end
    
    subgraph Databases["💾 Базы данных"]
        UserDB[("PostgreSQL<br/>user_service_db<br/>Пользователи")]
        BankingDB[("PostgreSQL<br/>banking_service_db<br/>Баланс, Транзакции, Вклады")]
        Redis[("Redis<br/>Сессии и кэш")]
    end
    
    %% Авторизация
    Android -->|"1. POST /auth/login<br/>phone + password"| UserService
    UserService -->|"Проверка пользователя"| UserDB
    UserService -->|"Сохранение сессии"| Redis
    UserService -->|"2. JWT Token + userId"| Android
    
    %% Профиль
    Android -->|"3. GET /users/profile<br/>Authorization: Bearer {token}"| UserService
    UserService -->|"Получение данных"| UserDB
    UserService -->|"4. Профиль пользователя"| Android
    
    %% Баланс
    Android -->|"5. GET /balance<br/>Authorization: Bearer {token}"| BankingService
    BankingService -.->|"Валидация JWT"| UserService
    BankingService -->|"Получение баланса"| BankingDB
    BankingService -->|"6. Баланс"| Android
    
    %% Переводы
    Android -->|"7. POST /transactions/transfer<br/>Authorization: Bearer {token}<br/>amount + recipientCard"| BankingService
    BankingService -.->|"Валидация JWT"| UserService
    BankingService -->|"Обновление баланса<br/>Создание транзакции"| BankingDB
    BankingService -->|"8. Результат перевода"| Android
    
    %% Вклады
    Android -->|"9. GET /deposits<br/>Authorization: Bearer {token}"| BankingService
    BankingService -->|"Получение вкладов"| BankingDB
    BankingService -->|"10. Список вкладов"| Android
    
    Android -->|"11. POST /deposits<br/>Authorization: Bearer {token}<br/>name + amount + rate"| BankingService
    BankingService -->|"Создание вклада<br/>Обновление баланса<br/>Транзакция"| BankingDB
    BankingService -->|"12. Результат"| Android
    
    style Android fill:#00A86B,stroke:#008A5A,stroke-width:3px,color:#fff
    style UserService fill:#1E88E5,stroke:#1565C0,stroke-width:2px,color:#fff
    style BankingService fill:#FF6B35,stroke:#E53935,stroke-width:2px,color:#fff
    style UserDB fill:#6B7280,stroke:#4B5563,stroke-width:2px,color:#fff
    style BankingDB fill:#6B7280,stroke:#4B5563,stroke-width:2px,color:#fff
    style Redis fill:#E53935,stroke:#C62828,stroke-width:2px,color:#fff
```

---

## Упрощенная диаграмма (для быстрого понимания):

```mermaid
graph LR
    A[📱 Android App] -->|HTTP + JWT| B[User Service<br/>:8081]
    A -->|HTTP + JWT| C[Banking Service<br/>:8082]
    
    B -->|SQL| D[(PostgreSQL<br/>Users)]
    B -->|Cache| E[(Redis)]
    C -->|SQL| F[(PostgreSQL<br/>Banking)]
    C -.->|Validate JWT| B
    
    style A fill:#00A86B,color:#fff
    style B fill:#1E88E5,color:#fff
    style C fill:#FF6B35,color:#fff
    style D fill:#6B7280,color:#fff
    style E fill:#E53935,color:#fff
    style F fill:#6B7280,color:#fff
```

---

## Последовательность операций (Sequence Diagram):

```mermaid
sequenceDiagram
    participant A as Android App
    participant US as User Service
    participant BS as Banking Service
    participant UDB as PostgreSQL User DB
    participant BDB as PostgreSQL Banking DB
    participant R as Redis
    
    Note over A,R: Авторизация
    A->>US: POST /auth/login (phone, password)
    US->>UDB: Проверка пользователя
    UDB-->>US: Данные пользователя
    US->>R: Сохранение сессии
    US-->>A: JWT Token
    
    Note over A,R: Получение баланса
    A->>BS: GET /balance (JWT Token)
    BS->>US: Валидация JWT
    US-->>BS: Token valid
    BS->>BDB: Получение баланса
    BDB-->>BS: Баланс
    BS-->>A: Balance Response
    
    Note over A,R: Перевод денег
    A->>BS: POST /transactions/transfer (JWT, amount, card)
    BS->>US: Валидация JWT
    US-->>BS: Token valid
    BS->>BDB: Обновление баланса + Транзакция
    BDB-->>BS: Success
    BS-->>A: Transfer Response
```

---

## Использование:

1. **Для GitHub/GitLab:** Скопируй Mermaid код в Markdown файл
2. **Для документации:** Вставь в любой редактор, поддерживающий Mermaid
3. **Для презентаций:** Используй https://mermaid.live/ для экспорта в PNG/SVG
4. **Для Draw.io:** Импортируй через Mermaid плагин

---

## Онлайн редакторы:

- **Mermaid Live Editor:** https://mermaid.live/
- **Draw.io:** https://app.diagrams.net/
- **Lucidchart:** https://www.lucidchart.com/

